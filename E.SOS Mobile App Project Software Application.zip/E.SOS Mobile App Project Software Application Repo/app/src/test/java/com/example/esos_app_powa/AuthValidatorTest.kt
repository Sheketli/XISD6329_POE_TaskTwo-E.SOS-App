package com.example.esos_app_powa

import com.example.esos_app_powa.utils.AuthValidator
import org.junit.Assert.*
import org.junit.Test

class AuthValidatorTest {

    @Test
    fun testValidEmailAddresses() {
        assertTrue(AuthValidator.isValidEmail("user@example.com"))
        assertTrue(AuthValidator.isValidEmail("test.user+123@powa.org.za"))
        assertTrue(AuthValidator.isValidEmail("emergency_contact@domain.co.za"))
        assertTrue(AuthValidator.isValidEmail("  valid@sub.domain.com  "))
    }

    @Test
    fun testInvalidEmailAddresses() {
        assertFalse(AuthValidator.isValidEmail(null))
        assertFalse(AuthValidator.isValidEmail(""))
        assertFalse(AuthValidator.isValidEmail("   "))
        assertFalse(AuthValidator.isValidEmail("plainaddress"))
        assertFalse(AuthValidator.isValidEmail("@missingusername.com"))
        assertFalse(AuthValidator.isValidEmail("username@.com"))
        assertFalse(AuthValidator.isValidEmail("username@domain"))
    }

    @Test
    fun testPasswordValidation() {
        assertTrue(AuthValidator.isValidPassword("12345678"))
        assertTrue(AuthValidator.isValidPassword("StrongP@ssw0rd2026"))
        
        assertFalse(AuthValidator.isValidPassword(null))
        assertFalse(AuthValidator.isValidPassword(""))
        assertFalse(AuthValidator.isValidPassword("1234567"))
    }

    @Test
    fun testPasswordMatching() {
        assertTrue(AuthValidator.doPasswordsMatch("SecurePass123", "SecurePass123"))
        
        assertFalse(AuthValidator.doPasswordsMatch("SecurePass123", "DifferentPass123"))
        assertFalse(AuthValidator.doPasswordsMatch("Pass", null))
        assertFalse(AuthValidator.doPasswordsMatch(null, "Pass"))
    }

    @Test
    fun testPhoneNumberValidation() {
        assertTrue(AuthValidator.isValidPhoneNumber("0821234567"))
        assertTrue(AuthValidator.isValidPhoneNumber("+27821234567"))
        assertTrue(AuthValidator.isValidPhoneNumber("082 123 4567"))
        assertTrue(AuthValidator.isValidPhoneNumber("+27-82-123-4567"))

        assertFalse(AuthValidator.isValidPhoneNumber(null))
        assertFalse(AuthValidator.isValidPhoneNumber(""))
        assertFalse(AuthValidator.isValidPhoneNumber("12345"))
        assertFalse(AuthValidator.isValidPhoneNumber("0821234567abc"))
        assertFalse(AuthValidator.isValidPhoneNumber("++27821234567"))
    }

    @Test
    fun testFullNameValidation() {
        assertTrue(AuthValidator.isValidFullName("Jane Doe"))
        assertTrue(AuthValidator.isValidFullName("Al"))

        assertFalse(AuthValidator.isValidFullName(null))
        assertFalse(AuthValidator.isValidFullName(""))
        assertFalse(AuthValidator.isValidFullName(" A "))
    }

    @Test
    fun testValidateLoginInputsSuccess() {
        val result = AuthValidator.validateLoginInputs("user@powa.org.za", "SecurePass123")
        assertTrue(result is AuthValidator.ValidationResult.Success)
    }

    @Test
    fun testValidateLoginInputsErrorCases() {
        val emptyEmailRes = AuthValidator.validateLoginInputs("", "Pass123456")
        assertTrue(emptyEmailRes is AuthValidator.ValidationResult.Error)
        assertEquals(AuthValidator.FieldType.EMAIL, (emptyEmailRes as AuthValidator.ValidationResult.Error).field)

        val invalidEmailRes = AuthValidator.validateLoginInputs("invalid-email", "Pass123456")
        assertTrue(invalidEmailRes is AuthValidator.ValidationResult.Error)

        val shortPassRes = AuthValidator.validateLoginInputs("user@powa.org.za", "123")
        assertTrue(shortPassRes is AuthValidator.ValidationResult.Error)
        assertEquals(AuthValidator.FieldType.PASSWORD, (shortPassRes as AuthValidator.ValidationResult.Error).field)
    }

    @Test
    fun testValidateRegistrationInputsSuccess() {
        val result = AuthValidator.validateRegistrationInputs(
            fullName = "Jane Doe",
            email = "jane@powa.org.za",
            phone = "+27821234567",
            password = "Password2026!",
            confirmPassword = "Password2026!",
            popiaAccepted = true
        )
        assertTrue(result is AuthValidator.ValidationResult.Success)
    }

    @Test
    fun testValidateRegistrationInputsErrorCases() {
        val popiaError = AuthValidator.validateRegistrationInputs(
            fullName = "Jane Doe",
            email = "jane@powa.org.za",
            phone = "+27821234567",
            password = "Password2026!",
            confirmPassword = "Password2026!",
            popiaAccepted = false
        )
        assertTrue(popiaError is AuthValidator.ValidationResult.Error)
        assertEquals(AuthValidator.FieldType.POPIA, (popiaError as AuthValidator.ValidationResult.Error).field)

        val mismatchError = AuthValidator.validateRegistrationInputs(
            fullName = "Jane Doe",
            email = "jane@powa.org.za",
            phone = "+27821234567",
            password = "Password2026!",
            confirmPassword = "DifferentPassword",
            popiaAccepted = true
        )
        assertTrue(mismatchError is AuthValidator.ValidationResult.Error)
        assertEquals(AuthValidator.FieldType.CONFIRM_PASSWORD, (mismatchError as AuthValidator.ValidationResult.Error).field)
    }
}
