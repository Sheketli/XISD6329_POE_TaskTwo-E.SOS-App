package com.example.esos_app_powa

import com.example.esos_app_powa.security.AuthSession
import com.example.esos_app_powa.security.SecurityManager
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class SecurityManagerTest {

    private lateinit var securityManager: SecurityManager

    @Before
    fun setUp() {
        // Instantiate SecurityManager with mock/null Context to verify resilience and fallback mechanisms
        securityManager = SecurityManager(context = DummyContext())
    }

    @Test
    fun testPasswordHashingAndVerification() {
        val rawPassword = "UserSecurePassword2026!"
        val salt = "custom_test_salt_123"

        val hash1 = securityManager.hashPassword(rawPassword, salt)
        val hash2 = securityManager.hashPassword(rawPassword, salt)

        assertNotNull(hash1)
        assertTrue(hash1.isNotEmpty())
        assertEquals("Hash output should be deterministic for identical salt", hash1, hash2)

        assertTrue(
            "Password verification should succeed for matching raw password",
            securityManager.verifyPassword(rawPassword, hash1, salt)
        )

        assertFalse(
            "Password verification should fail for incorrect raw password",
            securityManager.verifyPassword("WrongPassword123", hash1, salt)
        )
    }

    @Test
    fun testEncryptionAndDecryption() {
        val originalText = "Sensitive Medical Info: Allergies to Penicillin"

        val cipherText = securityManager.encryptData(originalText)
        assertNotNull(cipherText)
        assertNotEquals(originalText, cipherText)

        val decryptedText = securityManager.decryptData(cipherText)
        assertEquals(originalText, decryptedText)
    }

    @Test
    fun testEmptyDataEncryption() {
        assertEquals("", securityManager.encryptData(""))
        assertEquals("", securityManager.decryptData(""))
    }

    @Test
    fun testAuthSessionDataClass() {
        val session = AuthSession(
            userId = "usr_1001",
            email = "test@powa.org.za",
            provider = "GOOGLE",
            sessionToken = "token_xyz_123",
            timestamp = 1700000000000L
        )

        assertEquals("usr_1001", session.userId)
        assertEquals("test@powa.org.za", session.email)
        assertEquals("GOOGLE", session.provider)
        assertEquals("token_xyz_123", session.sessionToken)
        assertEquals(1700000000000L, session.timestamp)
    }

    /**
     * Minimal Context mock object to allow unit testing on JVM host.
     */
    private class DummyContext : android.content.ContextWrapper(null) {
        override fun getSharedPreferences(name: String?, mode: Int): android.content.SharedPreferences {
            throw UnsupportedOperationException("No SharedPreferences in DummyContext")
        }
    }
}
