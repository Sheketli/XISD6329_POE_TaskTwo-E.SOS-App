package com.example.esos_app_powa

import com.example.esos_app_powa.utils.DataParser
import org.junit.Assert.*
import org.junit.Test

class DataParserTest {

    @Test
    fun testParseCoordinatesSuccess() {
        val result = DataParser.parseCoordinates("-26.2041, 28.0473")
        assertNotNull(result)
        assertEquals(-26.2041, result!!.first, 0.0001)
        assertEquals(28.0473, result.second, 0.0001)
    }

    @Test
    fun testParseCoordinatesInvalidInputs() {
        assertNull(DataParser.parseCoordinates(null))
        assertNull(DataParser.parseCoordinates(""))
        assertNull(DataParser.parseCoordinates("   "))
        assertNull(DataParser.parseCoordinates("invalid_location"))
        assertNull(DataParser.parseCoordinates("-26.2041"))
        assertNull(DataParser.parseCoordinates("100.0, 28.0473")) // Latitude out of bounds (> 90)
        assertNull(DataParser.parseCoordinates("-26.2041, 200.0")) // Longitude out of bounds (> 180)
    }

    @Test
    fun testFormatPhoneNumberToE164() {
        assertEquals("+27821234567", DataParser.formatPhoneNumberToE164("0821234567"))
        assertEquals("+27821234567", DataParser.formatPhoneNumberToE164("+27821234567"))
        assertEquals("+27821234567", DataParser.formatPhoneNumberToE164("821234567"))
        assertEquals("", DataParser.formatPhoneNumberToE164(""))
    }

    @Test
    fun testIsValidReferenceNumber() {
        assertTrue(DataParser.isValidReferenceNumber("RPT-1710000000000"))
        assertTrue(DataParser.isValidReferenceNumber("RPT-12345"))

        assertFalse(DataParser.isValidReferenceNumber(null))
        assertFalse(DataParser.isValidReferenceNumber(""))
        assertFalse(DataParser.isValidReferenceNumber("RPT-"))
        assertFalse(DataParser.isValidReferenceNumber("INVALID-12345"))
    }

    @Test
    fun testParseTimestampToFormattedDate() {
        val timestamp = 1700000000000L // UTC: 2023-11-14 22:13:20
        val formatted = DataParser.parseTimestampToFormattedDate(timestamp, "yyyy-MM-dd HH:mm:ss", "UTC")
        assertEquals("2023-11-14 22:13:20", formatted)

        assertEquals("N/A", DataParser.parseTimestampToFormattedDate(null))
        assertEquals("N/A", DataParser.parseTimestampToFormattedDate(0L))
        assertEquals("N/A", DataParser.parseTimestampToFormattedDate(-1000L))
    }

    @Test
    fun testSanitizeText() {
        assertEquals("Hello World", DataParser.sanitizeText("  Hello    World  "))
        assertEquals("Multiple lines space clean", DataParser.sanitizeText("Multiple \n lines  space \t clean"))
        assertEquals("", DataParser.sanitizeText(null))
        assertEquals("", DataParser.sanitizeText("   "))
    }

    @Test
    fun testParseCommaSeparatedList() {
        val input = " url1, url2 , url3 ,, "
        val result = DataParser.parseCommaSeparatedList(input)
        assertEquals(3, result.size)
        assertEquals("url1", result[0])
        assertEquals("url2", result[1])
        assertEquals("url3", result[2])

        assertTrue(DataParser.parseCommaSeparatedList(null).isEmpty())
        assertTrue(DataParser.parseCommaSeparatedList("   ").isEmpty())
    }
}
