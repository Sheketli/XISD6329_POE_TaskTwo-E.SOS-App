package com.example.esos_app_powa

import com.example.esos_app_powa.data.local.converters.AppTypeConverters
import com.example.esos_app_powa.data.local.entities.AlertStatus
import com.example.esos_app_powa.data.local.entities.AlertType
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.util.Date

class AppTypeConvertersTest {

    private lateinit var converters: AppTypeConverters

    @Before
    fun setUp() {
        converters = AppTypeConverters()
    }

    @Test
    fun testDateToTimestampAndBack() {
        val now = Date()
        val timestamp = converters.dateToTimestamp(now)
        assertNotNull(timestamp)
        val dateFromTimestamp = converters.fromTimestamp(timestamp)
        assertEquals(now.time, dateFromTimestamp?.time)

        assertNull(converters.dateToTimestamp(null))
        assertNull(converters.fromTimestamp(null))
    }

    @Test
    fun testAlertTypeConverters() {
        assertEquals(AlertType.SOS, converters.fromAlertType("SOS"))
        assertEquals(AlertType.SILENT, converters.fromAlertType("SILENT"))
        assertEquals(AlertType.SOS, converters.fromAlertType("INVALID_TYPE"))
        assertEquals(AlertType.SOS, converters.fromAlertType(null))
        assertEquals(AlertType.SOS, converters.fromAlertType(""))

        assertEquals("SOS", converters.alertTypeToString(AlertType.SOS))
        assertEquals("SILENT", converters.alertTypeToString(AlertType.SILENT))
        assertEquals("SOS", converters.alertTypeToString(null))
    }

    @Test
    fun testAlertStatusConverters() {
        assertEquals(AlertStatus.ACTIVE, converters.fromAlertStatus("ACTIVE"))
        assertEquals(AlertStatus.RESOLVED, converters.fromAlertStatus("RESOLVED"))
        assertEquals(AlertStatus.CANCELLED, converters.fromAlertStatus("CANCELLED"))
        assertEquals(AlertStatus.ACTIVE, converters.fromAlertStatus("UNKNOWN"))
        assertEquals(AlertStatus.ACTIVE, converters.fromAlertStatus(null))

        assertEquals("ACTIVE", converters.alertStatusToString(AlertStatus.ACTIVE))
        assertEquals("RESOLVED", converters.alertStatusToString(AlertStatus.RESOLVED))
        assertEquals("ACTIVE", converters.alertStatusToString(null))
    }

    @Test
    fun testStringListConverters() {
        val list = listOf("url1", "url2", "url3")
        val joined = converters.toStringList(list)
        assertEquals("url1,url2,url3", joined)

        val parsed = converters.fromStringList(joined)
        assertEquals(list, parsed)

        assertTrue(converters.fromStringList(null).isEmpty())
        assertTrue(converters.fromStringList("").isEmpty())
        assertTrue(converters.fromStringList("   ").isEmpty())
        assertEquals("", converters.toStringList(null))
        assertEquals("", converters.toStringList(emptyList()))
    }
}
