package com.example.esos_app_powa

import com.example.esos_app_powa.data.model.EmergencyContact
import com.example.esos_app_powa.data.model.IncidentReport
import com.example.esos_app_powa.data.model.Message
import com.example.esos_app_powa.data.model.SOSAlert
import com.example.esos_app_powa.data.model.User
import org.junit.Assert.*
import org.junit.Test

class ModelsTest {

    @Test
    fun testUserModelDefaults() {
        val user = User(userId = "u123", fullName = "Jane Doe", email = "jane@powa.org.za")
        assertEquals("u123", user.userId)
        assertEquals("Jane Doe", user.fullName)
        assertEquals("jane@powa.org.za", user.email)
        assertTrue(user.isActive)
        assertEquals("en", user.preferredLanguage)
    }

    @Test
    fun testSOSAlertModelDefaults() {
        val alert = SOSAlert(alertId = "a1", userId = "u123", latitude = -26.2041, longitude = 28.0473)
        assertEquals("a1", alert.alertId)
        assertEquals("SOS", alert.alertType)
        assertEquals("ACTIVE", alert.status)
        assertFalse(alert.locationApproximate)
        assertEquals(-26.2041, alert.latitude, 0.0001)
        assertEquals(28.0473, alert.longitude, 0.0001)
    }

    @Test
    fun testIncidentReportModelDefaults() {
        val report = IncidentReport(
            reportId = "r1",
            userId = "u123",
            incidentType = "Physical",
            description = "Test description",
            referenceNumber = "RPT-1001"
        )
        assertEquals("r1", report.reportId)
        assertEquals("Physical", report.incidentType)
        assertEquals("SUBMITTED", report.status)
        assertEquals("RPT-1001", report.referenceNumber)
        assertTrue(report.mediaFileUrls.isEmpty())
    }

    @Test
    fun testEmergencyContactModelDefaults() {
        val contact = EmergencyContact(
            contactId = "c1",
            userId = "u123",
            name = "Sarah",
            phoneNumber = "+27820000000"
        )
        assertEquals("c1", contact.contactId)
        assertEquals("Sarah", contact.name)
        assertTrue(contact.notifySms)
        assertTrue(contact.notifyEmail)
    }

    @Test
    fun testMessageModelDefaults() {
        val msg = Message(
            messageId = "m1",
            senderId = "u123",
            recipientId = "POWA_OPERATOR",
            contentEncrypted = "encrypted_blob"
        )
        assertEquals("m1", msg.messageId)
        assertEquals("u123", msg.senderId)
        assertEquals("POWA_OPERATOR", msg.recipientId)
        assertFalse(msg.isRead)
    }
}
