package com.example.esos_app_powa.auth

import android.content.Context
import com.example.esos_app_powa.data.model.User
import com.example.esos_app_powa.data.repository.UserRepository
import com.example.esos_app_powa.security.SecurityManager
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.auth.api.signin.GoogleSignInStatusCodes
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.Timestamp
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import timber.log.Timber
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SsoManager @Inject constructor(
    @param:ApplicationContext private val context: Context,
    private val auth: FirebaseAuth,
    private val userRepository: UserRepository,
    private val securityManager: SecurityManager
) {

    /**
     * Creates and returns GoogleSignInClient configured for SSO.
     */
    fun getGoogleSignInClient(): GoogleSignInClient {
        val webClientId = getWebClientId()
        val gsoBuilder = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()

        if (webClientId.isNotEmpty()) {
            gsoBuilder.requestIdToken(webClientId)
        }

        return GoogleSignIn.getClient(context, gsoBuilder.build())
    }

    /**
     * Processes Google Sign-In intent result and authenticates with Firebase Auth.
     */
    suspend fun handleGoogleSignInResult(completedTask: Task<GoogleSignInAccount>): Result<FirebaseUser> = withContext(Dispatchers.IO) {
        try {
            var account: GoogleSignInAccount?
            var apiException: ApiException? = null

            try {
                account = completedTask.getResult(ApiException::class.java)
            } catch (e: ApiException) {
                apiException = e
                Timber.w(e, "Google Sign In ApiException code: ${e.statusCode}")
                
                when (e.statusCode) {
                    GoogleSignInStatusCodes.SIGN_IN_CANCELLED -> {
                        throw Exception("SSO Sign-In canceled by user")
                    }
                    GoogleSignInStatusCodes.DEVELOPER_ERROR -> {
                        throw Exception("SSO Misconfigured: Missing SHA-1 in Firebase Console")
                    }
                }
                
                // Fall back to last signed in account on device if task failed due to missing client ID / developer error
                account = GoogleSignIn.getLastSignedInAccount(context)
            }

            if (account == null) {
                account = GoogleSignIn.getLastSignedInAccount(context)
            }

            val idToken = account?.idToken

            if (!idToken.isNullOrEmpty()) {
                // Authenticate with Firebase using Google Credential
                val credential = GoogleAuthProvider.getCredential(idToken, null)
                val authResult: AuthResult = auth.signInWithCredential(credential).await()
                val firebaseUser = authResult.user ?: throw Exception("Firebase user is null after SSO login")

                // Synchronize SSO User profile with local Room DB, Firestore, and RTDB
                syncSsoUserProfile(firebaseUser)

                Result.success(firebaseUser)
            } else if (account != null) {
                // Anonymous or email credential sign-in fallback if idToken is not configured or missing
                val email = if (!account.email.isNullOrEmpty()) account.email!! else "sso_user@powa.org.za"
                val displayName = if (!account.displayName.isNullOrEmpty()) account.displayName!! else "SSO User"

                var currentFbUser = auth.currentUser
                if (currentFbUser == null) {
                    val authResult = auth.signInAnonymously().await()
                    currentFbUser = authResult.user
                }

                val userId = currentFbUser?.uid ?: "sso_${account.id ?: System.currentTimeMillis()}"

                val user = User(
                    userId = userId,
                    fullName = displayName,
                    email = email,
                    phoneNumber = "+27000000000",
                    isActive = true,
                    preferredLanguage = "en",
                    createdAt = Timestamp.now(),
                    updatedAt = Timestamp.now()
                )
                userRepository.saveUser(user, authProvider = "GOOGLE")

                if (currentFbUser != null) {
                    Result.success(currentFbUser)
                } else {
                    throw Exception("Failed to establish SSO Firebase session")
                }
            } else {
                val errorMsg = apiException?.let { "Google SSO Error (${it.statusCode}): ${it.message}" }
                    ?: "Failed to retrieve Google account details"
                throw Exception(errorMsg)
            }
        } catch (e: Exception) {
            Timber.e(e, "Google SSO Sign-In failed")
            Result.failure(e)
        }
    }

    /**
     * Synchronizes SSO user profile across local Room DB, Firestore, and Realtime DB.
     */
    private suspend fun syncSsoUserProfile(firebaseUser: FirebaseUser) {
        val existingUser = userRepository.getUser(firebaseUser.uid)
        if (existingUser == null) {
            val newUser = User(
                userId = firebaseUser.uid,
                fullName = firebaseUser.displayName ?: "SSO User",
                email = firebaseUser.email ?: "",
                phoneNumber = firebaseUser.phoneNumber ?: "",
                medicalInfo = "",
                isActive = true,
                preferredLanguage = "en",
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )
            userRepository.saveUser(newUser, authProvider = "GOOGLE")
        } else {
            // Save active session token
            securityManager.saveAuthSession(
                userId = firebaseUser.uid,
                email = firebaseUser.email ?: "",
                provider = "GOOGLE",
                sessionToken = firebaseUser.uid
            )
        }
    }

    /**
     * Helper to retrieve Web Client ID for Google Sign-In token verification.
     */
    private fun getWebClientId(): String {
        return try {
            val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
            if (resId != 0) context.getString(resId) else ""
        } catch (e: Exception) {
            ""
        }
    }

    fun signOutSso() {
        try {
            getGoogleSignInClient().signOut()
            auth.signOut()
            securityManager.clearAuthSession()
        } catch (e: Exception) {
            Timber.e(e, "Error signing out SSO")
        }
    }
}
