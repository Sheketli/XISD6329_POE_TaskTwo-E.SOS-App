package com.example.esos_app_powa

import android.app.Application
import com.google.firebase.FirebaseApp
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber

@HiltAndroidApp
class ESosApp : Application() {
    override fun onCreate() {
        super.onCreate()
        
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }

        // Initialize Firebase safely
        try {
            FirebaseApp.initializeApp(this)
        } catch (e: Throwable) {
            Timber.e(e, "Firebase initialization error in ESosApp")
        }
        
        // Initialize SQLCipher native libraries
        try {
            System.loadLibrary("sqlcipher")
            Timber.d("SQLCipher initialized successfully")
        } catch (e: Throwable) {
            Timber.e(e, "SQLCipher initialization failed")
        }
    }
}
