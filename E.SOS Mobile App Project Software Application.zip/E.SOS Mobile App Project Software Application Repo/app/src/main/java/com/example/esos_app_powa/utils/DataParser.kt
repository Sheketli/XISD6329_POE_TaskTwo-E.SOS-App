package com.example.esos_app_powa.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Data parsing and formatting utility methods for GPS coordinates, phone numbers, reference numbers, and timestamps.
 */
object DataParser {

    /**
     * Parses a string representation of coordinates e.g., "-26.2041, 28.0473" into a Pair(latitude, longitude).
     * Returns null if string is malformed or coordinates are out of valid range.
     */
    fun parseCoordinates(locationString: String?): Pair<Double, Double>? {
        if (locationString.isNullOrBlank()) return null
        val parts = locationString.split(",")
        if (parts.size != 2) return null

        return try {
            val lat = parts[0].trim().toDouble()
            val lng = parts[1].trim().toDouble()
            if (lat in -90.0..90.0 && lng in -180.0..180.0) {
                Pair(lat, lng)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Formats phone numbers to international standard E.164.
     * e.g., "0821234567" -> "+27821234567"
     */
    fun formatPhoneNumberToE164(phone: String, defaultCountryCode: String = "+27"): String {
        val cleaned = phone.replace(Regex("[^0-9+]"), "")
        if (cleaned.isEmpty()) return ""

        return when {
            cleaned.startsWith("+") -> cleaned
            cleaned.startsWith("0") -> defaultCountryCode + cleaned.substring(1)
            else -> defaultCountryCode + cleaned
        }
    }

    /**
     * Verifies if an incident reference code matches the "RPT-<digits>" pattern.
     */
    fun isValidReferenceNumber(referenceNumber: String?): Boolean {
        if (referenceNumber.isNullOrBlank()) return false
        return referenceNumber.matches(Regex("^RPT-\\d+$"))
    }

    /**
     * Formats epoch timestamp milliseconds to a readable date string.
     */
    fun parseTimestampToFormattedDate(
        timestampMillis: Long?,
        pattern: String = "yyyy-MM-dd HH:mm:ss",
        timeZoneId: String = "UTC"
    ): String {
        if (timestampMillis == null || timestampMillis <= 0) return "N/A"
        return try {
            val sdf = SimpleDateFormat(pattern, Locale.US)
            sdf.timeZone = TimeZone.getTimeZone(timeZoneId)
            sdf.format(Date(timestampMillis))
        } catch (e: Exception) {
            "N/A"
        }
    }

    /**
     * Sanitizes raw user text by trimming white spaces and reducing multiple consecutive spaces.
     */
    fun sanitizeText(input: String?): String {
        if (input == null) return ""
        return input.trim().replace(Regex("\\s+"), " ")
    }

    /**
     * Parses a comma-separated string into a list of cleaned, non-empty tokens.
     */
    fun parseCommaSeparatedList(input: String?): List<String> {
        if (input.isNullOrBlank()) return emptyList()
        return input.split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
    }
}
