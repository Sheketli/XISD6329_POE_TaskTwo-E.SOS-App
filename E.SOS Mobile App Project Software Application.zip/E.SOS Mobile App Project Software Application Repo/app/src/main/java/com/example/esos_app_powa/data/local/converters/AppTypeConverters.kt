package com.example.esos_app_powa.data.local.converters

import androidx.room.TypeConverter
import com.example.esos_app_powa.data.local.entities.AlertStatus
import com.example.esos_app_powa.data.local.entities.AlertType
import java.util.Date

class AppTypeConverters {
    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time
    }

    @TypeConverter
    fun fromAlertType(value: String?): AlertType {
        if (value.isNullOrBlank()) return AlertType.SOS
        return try {
            AlertType.valueOf(value)
        } catch (_: Exception) {
            AlertType.SOS
        }
    }

    @TypeConverter
    fun alertTypeToString(type: AlertType?): String {
        return (type ?: AlertType.SOS).name
    }

    @TypeConverter
    fun fromAlertStatus(value: String?): AlertStatus {
        if (value.isNullOrBlank()) return AlertStatus.ACTIVE
        return try {
            AlertStatus.valueOf(value)
        } catch (_: Exception) {
            AlertStatus.ACTIVE
        }
    }

    @TypeConverter
    fun alertStatusToString(status: AlertStatus?): String {
        return (status ?: AlertStatus.ACTIVE).name
    }

    @TypeConverter
    fun fromStringList(value: String?): List<String> {
        if (value.isNullOrBlank()) return emptyList()
        return value.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    @TypeConverter
    fun toStringList(list: List<String>?): String {
        if (list.isNullOrEmpty()) return ""
        return list.joinToString(",")
    }
}
