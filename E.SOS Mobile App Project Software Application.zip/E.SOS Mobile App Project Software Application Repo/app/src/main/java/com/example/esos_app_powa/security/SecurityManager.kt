package com.example.esos_app_powa.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import timber.log.Timber
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import javax.inject.Inject
import javax.inject.Singleton

data class AuthSession(
    val userId: String,
    val email: String,
    val provider: String,
    val sessionToken: String,
    val timestamp: Long
)

@Singleton
class SecurityManager @Inject constructor(
    @param:ApplicationContext private val context: Context
) {
    private val encryptedPrefs: SharedPreferences? by lazy {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            EncryptedSharedPreferences.create(
                context,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Timber.e(e, "EncryptedSharedPreferences initialization failed, using standard prefs fallback")
            try {
                context.getSharedPreferences("${PREFS_NAME}_fallback", Context.MODE_PRIVATE)
            } catch (ex: Exception) {
                null
            }
        }
    }

    private var cachedPassphrase: ByteArray? = null

    /**
     * Retrieves or securely generates a passphrase for SQLCipher database encryption.
     */
    fun getOrCreateDatabasePassphrase(): ByteArray {
        cachedPassphrase?.let { return it }
        return try {
            val prefs = encryptedPrefs
            val storedPassphrase = prefs?.getString(KEY_DB_PASSPHRASE, null)
            if (storedPassphrase != null) {
                val decoded = Base64.getDecoder().decode(storedPassphrase)
                cachedPassphrase = decoded
                decoded
            } else if (prefs != null) {
                val randomBytes = ByteArray(32)
                SecureRandom().nextBytes(randomBytes)
                val encodedPassphrase = Base64.getEncoder().encodeToString(randomBytes)

                prefs.edit()
                    .putString(KEY_DB_PASSPHRASE, encodedPassphrase)
                    .apply()

                cachedPassphrase = randomBytes
                randomBytes
            } else {
                val fallback = FALLBACK_PASSPHRASE.toByteArray()
                cachedPassphrase = fallback
                fallback
            }
        } catch (e: Exception) {
            Timber.e(e, "Error accessing passphrase, using fallback passphrase")
            val fallback = FALLBACK_PASSPHRASE.toByteArray()
            cachedPassphrase = fallback
            fallback
        }
    }

    fun hashPassword(password: String, salt: String = DEFAULT_SALT): String {
        return try {
            val spec = PBEKeySpec(password.toCharArray(), salt.toByteArray(), 10000, 256)
            val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            val hash = factory.generateSecret(spec).encoded
            Base64.getEncoder().encodeToString(hash)
        } catch (e: Exception) {
            Timber.e(e, "Error hashing password with PBKDF2, falling back to SHA-256")
            val md = MessageDigest.getInstance("SHA-256")
            md.update(salt.toByteArray())
            val digest = md.digest(password.toByteArray())
            Base64.getEncoder().encodeToString(digest)
        }
    }

    fun verifyPassword(password: String, storedHash: String, salt: String = DEFAULT_SALT): Boolean {
        val computedHash = hashPassword(password, salt)
        return computedHash == storedHash
    }

    fun encryptData(plainText: String): String {
        if (plainText.isEmpty()) return ""
        return try {
            val iv = ByteArray(GCM_IV_LENGTH)
            SecureRandom().nextBytes(iv)
            val gcmSpec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val secretKey = getAESKey()
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, gcmSpec)
            val encryptedBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))

            val combined = ByteArray(iv.size + encryptedBytes.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(encryptedBytes, 0, combined, iv.size, encryptedBytes.size)

            Base64.getEncoder().encodeToString(combined)
        } catch (e: Exception) {
            Timber.e(e, "Error encrypting data")
            plainText
        }
    }

    fun decryptData(cipherText: String): String {
        if (cipherText.isEmpty()) return ""
        return try {
            val combined = Base64.getDecoder().decode(cipherText)
            if (combined.size < GCM_IV_LENGTH) return cipherText

            val iv = ByteArray(GCM_IV_LENGTH)
            val encryptedBytes = ByteArray(combined.size - GCM_IV_LENGTH)

            System.arraycopy(combined, 0, iv, 0, GCM_IV_LENGTH)
            System.arraycopy(combined, GCM_IV_LENGTH, encryptedBytes, 0, encryptedBytes.size)

            val cipher = Cipher.getInstance(TRANSFORMATION)
            val secretKey = getAESKey()
            val gcmSpec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec)

            val decryptedBytes = cipher.doFinal(encryptedBytes)
            String(decryptedBytes, Charsets.UTF_8)
        } catch (e: Exception) {
            Timber.e(e, "Error decrypting data")
            cipherText
        }
    }

    fun saveAuthSession(userId: String, email: String, provider: String, sessionToken: String) {
        try {
            encryptedPrefs?.edit()
                ?.putString(KEY_USER_ID, userId)
                ?.putString(KEY_USER_EMAIL, email)
                ?.putString(KEY_AUTH_PROVIDER, provider)
                ?.putString(KEY_SESSION_TOKEN, sessionToken)
                ?.putLong(KEY_SESSION_TIME, System.currentTimeMillis())
                ?.apply()
        } catch (e: Exception) {
            Timber.e(e, "Failed to save auth session")
        }
    }

    fun getAuthSession(): AuthSession? {
        return try {
            val prefs = encryptedPrefs ?: return null
            val userId = prefs.getString(KEY_USER_ID, null) ?: return null
            val email = prefs.getString(KEY_USER_EMAIL, "") ?: ""
            val provider = prefs.getString(KEY_AUTH_PROVIDER, "EMAIL") ?: "EMAIL"
            val sessionToken = prefs.getString(KEY_SESSION_TOKEN, "") ?: ""
            val timestamp = prefs.getLong(KEY_SESSION_TIME, 0L)

            AuthSession(userId, email, provider, sessionToken, timestamp)
        } catch (e: Exception) {
            Timber.e(e, "Failed to get auth session")
            null
        }
    }

    fun clearAuthSession() {
        try {
            encryptedPrefs?.edit()
                ?.remove(KEY_USER_ID)
                ?.remove(KEY_USER_EMAIL)
                ?.remove(KEY_AUTH_PROVIDER)
                ?.remove(KEY_SESSION_TOKEN)
                ?.remove(KEY_SESSION_TIME)
                ?.apply()
        } catch (e: Exception) {
            Timber.e(e, "Failed to clear auth session")
        }
    }

    fun isSsoUser(): Boolean {
        return try {
            val provider = encryptedPrefs?.getString(KEY_AUTH_PROVIDER, "EMAIL")
            provider == "GOOGLE" || provider == "MICROSOFT" || provider == "SSO"
        } catch (e: Exception) {
            false
        }
    }

    private fun getAESKey(): SecretKey {
        val passphrase = getOrCreateDatabasePassphrase()
        val keyBytes = MessageDigest.getInstance("SHA-256").digest(passphrase)
        return SecretKeySpec(keyBytes, "AES")
    }

    companion object {
        private const val PREFS_NAME = "esos_secure_prefs"
        private const val KEY_DB_PASSPHRASE = "db_passphrase_key"
        private const val KEY_USER_ID = "auth_user_id"
        private const val KEY_USER_EMAIL = "auth_user_email"
        private const val KEY_AUTH_PROVIDER = "auth_provider"
        private const val KEY_SESSION_TOKEN = "auth_session_token"
        private const val KEY_SESSION_TIME = "auth_session_time"

        private const val FALLBACK_PASSPHRASE = "powa_secure_passphrase_2026_keys"
        private const val DEFAULT_SALT = "esos_powa_secure_salt_2026"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_IV_LENGTH = 12
        private const val GCM_TAG_LENGTH = 128
    }
}
