package com.example.esos_app_powa.data.repository

import com.example.esos_app_powa.data.local.dao.SosAlertDao
import com.example.esos_app_powa.data.local.dao.UserDao
import com.example.esos_app_powa.data.local.entities.AlertStatus
import com.example.esos_app_powa.data.local.entities.AlertType
import com.example.esos_app_powa.data.local.entities.SosAlertEntity
import com.example.esos_app_powa.data.local.entities.UserEntity
import com.example.esos_app_powa.data.model.SOSAlert
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.util.Date
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SosRepository @Inject constructor(
    private val sosAlertDao: SosAlertDao,
    private val userDao: UserDao,
    private val firestore: FirebaseFirestore,
    private val database: FirebaseDatabase
) {
    suspend fun triggerSOS(alert: SOSAlert) = withContext(Dispatchers.IO) {
        // 1. Ensure parent UserEntity exists in Room DB to satisfy Foreign Key constraint
        try {
            val localUser = userDao.getUserById(alert.userId)
            if (localUser == null) {
                val newEntity = UserEntity(
                    userId = alert.userId,
                    fullName = "User",
                    phoneNumber = "",
                    email = "",
                    passwordHash = "",
                    medicalInfo = "",
                    isActive = true,
                    preferredLanguage = "en",
                    createdAt = Date(),
                    updatedAt = Date()
                )
                userDao.insertUser(newEntity)
            }
        } catch (e: Throwable) {
            Timber.e(e, "Error verifying/creating parent user for SOS Alert")
        }

        // 2. Save SOS Alert to Room
        try {
            val alertTypeEnum = try {
                AlertType.valueOf(alert.alertType)
            } catch (e: Exception) {
                AlertType.SOS
            }

            val alertStatusEnum = try {
                AlertStatus.valueOf(alert.status)
            } catch (e: Exception) {
                AlertStatus.ACTIVE
            }

            val entity = SosAlertEntity(
                alertId = alert.alertId,
                userId = alert.userId,
                alertType = alertTypeEnum,
                latitude = alert.latitude,
                longitude = alert.longitude,
                locationApproximate = alert.locationApproximate,
                status = alertStatusEnum,
                notificationsSent = alert.notificationsSent,
                triggeredAt = alert.triggeredAt.toDate(),
                resolvedAt = alert.resolvedAt?.toDate(),
                assignedOperatorId = alert.assignedOperatorId
            )
            sosAlertDao.insertAlert(entity)
            Timber.d("SOS Alert saved to Room successfully: ${alert.alertId}")
        } catch (e: Throwable) {
            Timber.e(e, "Room insertion error for SOS Alert: ${alert.alertId}")
        }

        // 3. Sync to Remote Services (Firestore & Realtime Database)
        try {
            firestore.collection("sos_alerts").document(alert.alertId).set(alert)
                .addOnSuccessListener { Timber.d("SOS Alert synced to Firestore: ${alert.alertId}") }
                .addOnFailureListener { e -> Timber.e(e, "Failed to sync SOS Alert to Firestore") }

            database.getReference("sos_alerts").child(alert.alertId).setValue(alert)
                .addOnSuccessListener { Timber.d("SOS Alert synced to RTDB: ${alert.alertId}") }
                .addOnFailureListener { e -> Timber.e(e, "Failed to sync SOS Alert to RTDB") }
        } catch (e: Throwable) {
            Timber.e(e, "Remote sync error for SOS Alert: ${alert.alertId}")
        }
    }

    suspend fun resolveSOS(alertId: String) = withContext(Dispatchers.IO) {
        if (alertId.isEmpty()) return@withContext
        try {
            val localAlert = sosAlertDao.getAlertById(alertId)
            if (localAlert != null) {
                val updatedAlert = localAlert.copy(
                    status = AlertStatus.RESOLVED,
                    resolvedAt = Date()
                )
                sosAlertDao.updateAlert(updatedAlert)
                Timber.d("Local Room SOS Alert resolved: $alertId")
            }
        } catch (e: Throwable) {
            Timber.e(e, "Error updating local Room alert status: $alertId")
        }

        try {
            val updates = mapOf<String, Any>(
                "status" to "RESOLVED",
                "resolvedAt" to com.google.firebase.Timestamp.now()
            )
            firestore.collection("sos_alerts").document(alertId).update(updates)
            database.getReference("sos_alerts").child(alertId).child("status").setValue("RESOLVED")
            Timber.d("Remote SOS Alert resolved: $alertId")
        } catch (e: Throwable) {
            Timber.e(e, "Error updating remote alert status: $alertId")
        }
    }
}
