package com.example.esos_app_powa.ui.messaging

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.esos_app_powa.R
import com.example.esos_app_powa.data.local.dao.MessageDao
import com.example.esos_app_powa.data.local.entities.MessageEntity
import com.example.esos_app_powa.security.SecurityManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.Timestamp
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import javax.inject.Inject

@AndroidEntryPoint
class MessagingActivity : AppCompatActivity() {
    
    @Inject
    lateinit var auth: FirebaseAuth

    @Inject
    lateinit var firestore: FirebaseFirestore

    @Inject
    lateinit var messageDao: MessageDao

    @Inject
    lateinit var securityManager: SecurityManager
    
    private lateinit var messageContainer: LinearLayout
    private lateinit var messageEditText: EditText
    private lateinit var sendButton: Button
    private lateinit var backButton: ImageButton
    private lateinit var scrollView: ScrollView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_messaging)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        
        initializeViews()
        setupClickListeners()
        loadMessages()
    }
    
    private fun initializeViews() {
        messageContainer = findViewById(R.id.messageContainer)
        messageEditText = findViewById(R.id.messageEditText)
        sendButton = findViewById(R.id.sendButton)
        backButton = findViewById(R.id.backButton)
        scrollView = findViewById(R.id.scrollView)
    }
    
    private fun setupClickListeners() {
        sendButton.setOnClickListener { sendMessage() }
        backButton.setOnClickListener { finish() }
    }
    
    private fun loadMessages() {
        val userId = auth.currentUser?.uid ?: return
        val operatorId = "POWA_OPERATOR"
        
        lifecycleScope.launch {
            try {
                messageDao.observeChatHistory(userId, operatorId).collectLatest { messages ->
                    if (isFinishing || isDestroyed) return@collectLatest
                    messageContainer.removeAllViews()

                    if (messages.isEmpty()) {
                        addMessageBubble("Welcome to Secure Messaging. Your messages are end-to-end encrypted.", "POWA Support Team", true, "Now")
                    } else {
                        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
                        for (entity in messages) {
                            val plainText = securityManager.decryptData(entity.contentEncrypted)
                            val isOperator = entity.senderId != userId
                            val senderName = if (isOperator) "POWA Support Team" else "You"
                            val timeStr = timeFormat.format(entity.sentAt)
                            addMessageBubble(plainText, senderName, isOperator, timeStr)
                        }
                    }
                    scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
                }
            } catch (e: Exception) {
                Timber.e(e, "Error observing message chat history")
            }
        }
    }
    
    private fun sendMessage() {
        val message = messageEditText.text.toString().trim()
        
        if (message.isEmpty()) {
            Toast.makeText(this, "Message cannot be empty", Toast.LENGTH_SHORT).show()
            return
        }
        
        val userId = auth.currentUser?.uid ?: return
        val operatorId = "POWA_OPERATOR"
        val messageId = UUID.randomUUID().toString()
        val encryptedContent = securityManager.encryptData(message)
        
        messageEditText.text.clear()

        lifecycleScope.launch {
            try {
                val entity = MessageEntity(
                    messageId = messageId,
                    senderId = userId,
                    recipientId = operatorId,
                    contentEncrypted = encryptedContent,
                    sentAt = Date(),
                    isRead = false
                )
                messageDao.insertMessage(entity)

                val messageData = mapOf(
                    "messageId" to messageId,
                    "senderId" to userId,
                    "recipientId" to operatorId,
                    "contentEncrypted" to encryptedContent,
                    "sentAt" to Timestamp.now(),
                    "isRead" to false
                )
                
                firestore.collection("messages").document(messageId).set(messageData)
                    .addOnSuccessListener {
                        if (!isFinishing && !isDestroyed) {
                            scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
                        }
                    }
                    .addOnFailureListener { exception ->
                        Timber.e(exception, "Failed to sync message to remote Firestore")
                    }
            } catch (e: Exception) {
                Timber.e(e, "Error inserting local message")
            }
        }
    }
    
    private fun addMessageBubble(message: String, sender: String, isFromOperator: Boolean, time: String) {
        val messageView = layoutInflater.inflate(R.layout.item_message_bubble, messageContainer, false)
        
        val bubbleContainer = messageView.findViewById<LinearLayout>(R.id.bubbleContainer)
        val messageText = messageView.findViewById<TextView>(R.id.messageText)
        val senderText = messageView.findViewById<TextView>(R.id.senderText)
        val timeText = messageView.findViewById<TextView>(R.id.timeText)
        val bubble = messageView.findViewById<LinearLayout>(R.id.messageBubble)
        
        messageText.text = message
        senderText.text = sender
        timeText.text = time
        
        if (isFromOperator) {
            bubble.setBackgroundResource(R.drawable.message_bubble_operator)
            messageText.setTextColor(getColor(R.color.text_primary))
            bubbleContainer.gravity = Gravity.START
        } else {
            bubble.setBackgroundResource(R.drawable.message_bubble_user)
            messageText.setTextColor(getColor(R.color.text_white))
            bubbleContainer.gravity = Gravity.END
        }
        
        messageContainer.addView(messageView)
    }
}
