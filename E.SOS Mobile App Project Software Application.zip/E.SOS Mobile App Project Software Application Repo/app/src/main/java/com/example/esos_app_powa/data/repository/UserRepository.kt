package com.example.esos_app_powa.data.repository

import com.example.esos_app_powa.data.local.dao.UserDao
import com.example.esos_app_powa.data.local.entities.UserEntity
import com.example.esos_app_powa.data.model.User
import com.example.esos_app_powa.security.SecurityManager
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.util.Date
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepository @Inject constructor(
    private val userDao: UserDao,
    private val firestore: FirebaseFirestore,
    private val database: FirebaseDatabase,
    private val securityManager: SecurityManager,
    private val auth: FirebaseAuth
) {
    /**
     * Saves a user to local Room database, remote Firestore, and Realtime Database.
     * Encrypts local credentials and stores session state.
     */
    suspend fun saveUser(
        user: User,
        rawPassword: String = "",
        authProvider: String = "EMAIL"
    ) = withContext(Dispatchers.IO) {
        try {
            val hashedPassword = if (rawPassword.isNotEmpty()) {
                securityManager.hashPassword(rawPassword)
            } else {
                ""
            }

            // 1. Map Model to Room Entity
            val userEntity = UserEntity(
                userId = user.userId,
                fullName = user.fullName,
                phoneNumber = user.phoneNumber,
                email = user.email,
                passwordHash = hashedPassword,
                medicalInfo = user.medicalInfo,
                isActive = user.isActive,
                preferredLanguage = user.preferredLanguage,
                createdAt = user.createdAt?.toDate() ?: Date(),
                updatedAt = user.updatedAt?.toDate() ?: Date()
            )

            // 2. Store in local Room database
            userDao.insertUser(userEntity)
            Timber.d("User saved to local Room database: ${user.userId}")

            // 3. Save session in SecurityManager
            securityManager.saveAuthSession(
                userId = user.userId,
                email = user.email,
                provider = authProvider,
                sessionToken = auth.currentUser?.uid ?: user.userId
            )

            // 4. Store in Firestore safely
            try {
                firestore.collection("users").document(user.userId).set(user).await()
                Timber.d("User synced to Firestore: ${user.userId}")
            } catch (e: Exception) {
                Timber.w(e, "Firestore user sync failed or offline for ${user.userId}")
            }

            // 5. Store in Realtime Database (RTDB) safely
            try {
                database.getReference("users").child(user.userId).setValue(user).await()
                Timber.d("User synced to RTDB: ${user.userId}")
            } catch (e: Exception) {
                Timber.w(e, "RTDB user sync failed or offline for ${user.userId}")
            }

        } catch (e: Exception) {
            Timber.e(e, "Error saving user: ${user.userId}")
            throw e
        }
    }

    suspend fun getUser(userId: String): User? = withContext(Dispatchers.IO) {
        try {
            // Try Room first for performance
            val localUser = userDao.getUserById(userId)
            if (localUser != null) {
                return@withContext User(
                    userId = localUser.userId,
                    fullName = localUser.fullName,
                    phoneNumber = localUser.phoneNumber,
                    email = localUser.email,
                    medicalInfo = localUser.medicalInfo ?: "",
                    isActive = localUser.isActive,
                    preferredLanguage = localUser.preferredLanguage,
                    createdAt = Timestamp(localUser.createdAt),
                    updatedAt = Timestamp(localUser.updatedAt)
                )
            }

            // Fallback to Firestore
            val doc = firestore.collection("users").document(userId).get().await()
            if (doc.exists()) {
                val remoteUser = try {
                    doc.toObject(User::class.java)
                } catch (e: Exception) {
                    Timber.e(e, "Firestore deserialization failed for user $userId")
                    null
                }

                val finalUser = remoteUser ?: User(
                    userId = userId,
                    fullName = doc.getString("fullName") ?: "User",
                    email = doc.getString("email") ?: "",
                    phoneNumber = doc.getString("phoneNumber") ?: "",
                    medicalInfo = doc.getString("medicalInfo") ?: "",
                    isActive = doc.getBoolean("isActive") ?: true,
                    preferredLanguage = doc.getString("preferredLanguage") ?: "en",
                    createdAt = doc.getTimestamp("createdAt") ?: Timestamp.now(),
                    updatedAt = doc.getTimestamp("updatedAt") ?: Timestamp.now()
                )

                // Cache locally
                try {
                    val userEntity = UserEntity(
                        userId = finalUser.userId,
                        fullName = finalUser.fullName,
                        phoneNumber = finalUser.phoneNumber,
                        email = finalUser.email,
                        passwordHash = "",
                        medicalInfo = finalUser.medicalInfo,
                        isActive = finalUser.isActive,
                        preferredLanguage = finalUser.preferredLanguage,
                        createdAt = finalUser.createdAt.toDate(),
                        updatedAt = finalUser.updatedAt.toDate()
                    )
                    userDao.insertUser(userEntity)
                } catch (e: Exception) {
                    Timber.e(e, "Error caching user entity to Room")
                }
                return@withContext finalUser
            }
        } catch (e: Exception) {
            Timber.e(e, "Error fetching user: $userId")
        }
        return@withContext null
    }

    /**
     * Updates user personal profile in Room, Firestore, and Realtime DB safely.
     */
    suspend fun updateUserProfile(updatedUser: User) = withContext(Dispatchers.IO) {
        try {
            val existingEntity = userDao.getUserById(updatedUser.userId)
            val updatedEntity = UserEntity(
                userId = updatedUser.userId,
                fullName = updatedUser.fullName,
                phoneNumber = updatedUser.phoneNumber,
                email = updatedUser.email,
                passwordHash = existingEntity?.passwordHash ?: "",
                medicalInfo = updatedUser.medicalInfo,
                isActive = updatedUser.isActive,
                preferredLanguage = updatedUser.preferredLanguage,
                createdAt = existingEntity?.createdAt ?: updatedUser.createdAt.toDate(),
                updatedAt = Date()
            )

            userDao.updateUser(updatedEntity)
            try {
                firestore.collection("users").document(updatedUser.userId).set(updatedUser).await()
            } catch (e: Exception) {
                Timber.w(e, "Firestore profile update failed or offline for ${updatedUser.userId}")
            }
            try {
                database.getReference("users").child(updatedUser.userId).setValue(updatedUser).await()
            } catch (e: Exception) {
                Timber.w(e, "RTDB profile update failed or offline for ${updatedUser.userId}")
            }

            Timber.d("User profile updated successfully across platforms: ${updatedUser.userId}")
        } catch (e: Exception) {
            Timber.e(e, "Error updating user profile: ${updatedUser.userId}")
            throw e
        }
    }

    /**
     * Safely updates user password in Firebase Auth and updates local hashed credentials.
     */
    suspend fun updateUserPassword(newPassword: String) = withContext(Dispatchers.IO) {
        val currentUser = auth.currentUser ?: throw IllegalStateException("User not authenticated")
        
        // 1. Update password in Firebase Auth
        currentUser.updatePassword(newPassword).await()

        // 2. Hash new password and update local Room database
        val newHash = securityManager.hashPassword(newPassword)
        val localUser = userDao.getUserById(currentUser.uid)
        if (localUser != null) {
            val updatedEntity = localUser.copy(
                passwordHash = newHash,
                updatedAt = Date()
            )
            userDao.updateUser(updatedEntity)
        }
        Timber.d("User password updated securely")
    }

    fun clearSession() {
        securityManager.clearAuthSession()
    }
}
