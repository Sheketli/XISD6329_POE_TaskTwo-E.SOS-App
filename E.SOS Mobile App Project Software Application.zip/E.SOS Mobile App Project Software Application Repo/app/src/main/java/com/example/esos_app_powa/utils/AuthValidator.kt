package com.example.esos_app_powa.utils

/**
 * Automated validation rules for authentication, profile updates, and input forms.
 */
object AuthValidator {

    private val EMAIL_REGEX = Regex(
        "^[a-zA-Z0-9.+_%-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}\$"
    )

    /**
     * Validates email format.
     */
    fun isValidEmail(email: String?): Boolean {
        if (email.isNullOrBlank()) return false
        return EMAIL_REGEX.matches(email.trim())
    }

    /**
     * Validates password criteria (at least 8 characters).
     */
    fun isValidPassword(password: String?): Boolean {
        if (password == null) return false
        return password.length >= 8
    }

    /**
     * Verifies that password and confirmation match.
     */
    fun doPasswordsMatch(password: String?, confirmPassword: String?): Boolean {
        if (password == null || confirmPassword == null) return false
        return password == confirmPassword
    }

    /**
     * Validates phone numbers (accepts digits, spaces, hyphens, and leading '+').
     * Expects between 10 and 15 digits.
     */
    fun isValidPhoneNumber(phone: String?): Boolean {
        if (phone.isNullOrBlank()) return false
        val trimmed = phone.trim()
        val isValidChars = trimmed.all { it.isDigit() || it == '+' || it == ' ' || it == '-' }
        if (!isValidChars) return false

        if (trimmed.count { it == '+' } > 1 || (trimmed.contains('+') && !trimmed.startsWith("+"))) {
            return false
        }

        val digitCount = trimmed.count { it.isDigit() }
        return digitCount in 10..15
    }

    /**
     * Validates full name input (must be at least 2 characters).
     */
    fun isValidFullName(fullName: String?): Boolean {
        if (fullName.isNullOrBlank()) return false
        return fullName.trim().length >= 2
    }

    /**
     * Validates login input fields and returns a descriptive result.
     */
    fun validateLoginInputs(email: String, password: String): ValidationResult {
        if (email.isBlank()) {
            return ValidationResult.Error("Email field is required", FieldType.EMAIL)
        }
        if (!isValidEmail(email)) {
            return ValidationResult.Error("Invalid email address format", FieldType.EMAIL)
        }
        if (password.isBlank()) {
            return ValidationResult.Error("Password field is required", FieldType.PASSWORD)
        }
        if (!isValidPassword(password)) {
            return ValidationResult.Error("Password must be at least 8 characters", FieldType.PASSWORD)
        }
        return ValidationResult.Success
    }

    /**
     * Validates user registration fields and returns a descriptive result.
     */
    fun validateRegistrationInputs(
        fullName: String,
        email: String,
        phone: String,
        password: String,
        confirmPassword: String,
        popiaAccepted: Boolean
    ): ValidationResult {
        if (!isValidFullName(fullName)) {
            return ValidationResult.Error("Full name must be at least 2 characters", FieldType.FULL_NAME)
        }
        if (!isValidEmail(email)) {
            return ValidationResult.Error("Invalid email address format", FieldType.EMAIL)
        }
        if (!isValidPhoneNumber(phone)) {
            return ValidationResult.Error("Invalid phone number format", FieldType.PHONE)
        }
        if (!isValidPassword(password)) {
            return ValidationResult.Error("Password must be at least 8 characters", FieldType.PASSWORD)
        }
        if (!doPasswordsMatch(password, confirmPassword)) {
            return ValidationResult.Error("Passwords do not match", FieldType.CONFIRM_PASSWORD)
        }
        if (!popiaAccepted) {
            return ValidationResult.Error("You must accept POPIA terms to register", FieldType.POPIA)
        }
        return ValidationResult.Success
    }

    enum class FieldType {
        FULL_NAME, EMAIL, PHONE, PASSWORD, CONFIRM_PASSWORD, POPIA
    }

    sealed class ValidationResult {
        object Success : ValidationResult()
        data class Error(val message: String, val field: FieldType) : ValidationResult()
    }
}
