package com.example.esos_app_powa.ui.profile

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.esos_app_powa.R
import com.example.esos_app_powa.auth.SsoManager
import com.example.esos_app_powa.data.model.EmergencyContact
import com.example.esos_app_powa.data.model.User
import com.example.esos_app_powa.data.repository.UserRepository
import com.example.esos_app_powa.security.SecurityManager
import com.example.esos_app_powa.ui.auth.LoginActivity
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import timber.log.Timber
import javax.inject.Inject

@AndroidEntryPoint
class ProfileActivity : AppCompatActivity() {

    @Inject
    lateinit var auth: FirebaseAuth

    @Inject
    lateinit var firestore: FirebaseFirestore

    @Inject
    lateinit var userRepository: UserRepository

    @Inject
    lateinit var ssoManager: SsoManager

    @Inject
    lateinit var securityManager: SecurityManager

    private lateinit var backButton: ImageButton
    private lateinit var profileProgressBar: ProgressBar

    // Header Display
    private lateinit var fullNameDisplay: TextView
    private lateinit var emailDisplay: TextView
    private lateinit var ssoBadge: TextView
    private lateinit var encryptionBadge: TextView

    // Personal Details Inputs
    private lateinit var fullNameInput: EditText
    private lateinit var phoneInput: EditText
    private lateinit var languageInput: EditText
    private lateinit var medicalInfoInput: EditText
    private lateinit var saveProfileButton: Button

    // Password Security Inputs
    private lateinit var newPasswordInput: EditText
    private lateinit var confirmNewPasswordInput: EditText
    private lateinit var updatePasswordButton: Button

    // Emergency Contacts
    private lateinit var addContactButton: Button
    private lateinit var emergencyContactsContainer: LinearLayout

    // Account Actions
    private lateinit var signOutButton: Button
    private lateinit var deleteAccountButton: Button

    private var currentUserModel: User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        initializeViews()
        setupClickListeners()
        loadUserProfile()
    }

    private fun initializeViews() {
        backButton = findViewById(R.id.backButton)
        profileProgressBar = findViewById(R.id.profileProgressBar)

        fullNameDisplay = findViewById(R.id.fullNameDisplay)
        emailDisplay = findViewById(R.id.emailDisplay)
        ssoBadge = findViewById(R.id.ssoBadge)
        encryptionBadge = findViewById(R.id.encryptionBadge)

        fullNameInput = findViewById(R.id.fullNameInput)
        phoneInput = findViewById(R.id.phoneInput)
        languageInput = findViewById(R.id.languageInput)
        medicalInfoInput = findViewById(R.id.medicalInfoInput)
        saveProfileButton = findViewById(R.id.saveProfileButton)

        newPasswordInput = findViewById(R.id.newPasswordInput)
        confirmNewPasswordInput = findViewById(R.id.confirmNewPasswordInput)
        updatePasswordButton = findViewById(R.id.updatePasswordButton)

        addContactButton = findViewById(R.id.addContactButton)
        emergencyContactsContainer = findViewById(R.id.emergencyContactsContainer)

        signOutButton = findViewById(R.id.signOutButton)
        deleteAccountButton = findViewById(R.id.deleteAccountButton)
    }

    private fun setupClickListeners() {
        backButton.setOnClickListener { finish() }
        saveProfileButton.setOnClickListener { performSaveProfile() }
        updatePasswordButton.setOnClickListener { performUpdatePassword() }
        addContactButton.setOnClickListener { showAddContactDialog() }
        signOutButton.setOnClickListener { showSignOutConfirmation() }
        deleteAccountButton.setOnClickListener { showDeleteAccountConfirmation() }
    }

    private fun loadUserProfile() {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            navigateToLogin()
            return
        }

        val userId = currentUser.uid
        val currentEmail = currentUser.email ?: ""
        val currentDisplayName = currentUser.displayName ?: ""

        profileProgressBar.visibility = android.view.View.VISIBLE

        lifecycleScope.launch {
            try {
                var user = userRepository.getUser(userId)
                if (user == null) {
                    try {
                        val doc = firestore.collection("users").document(userId).get().await()
                        if (doc.exists()) {
                            user = doc.toObject(User::class.java) ?: User(
                                userId = userId,
                                fullName = doc.getString("fullName") ?: currentDisplayName.ifEmpty { "User" },
                                email = doc.getString("email") ?: currentEmail,
                                phoneNumber = doc.getString("phoneNumber") ?: "",
                                medicalInfo = doc.getString("medicalInfo") ?: "",
                                isActive = true,
                                preferredLanguage = "en",
                                createdAt = Timestamp.now(),
                                updatedAt = Timestamp.now()
                            )
                        }
                    } catch (e: Exception) {
                        Timber.e(e, "Direct Firestore profile fetch exception")
                    }
                }

                val finalUser = user ?: User(
                    userId = userId,
                    fullName = currentDisplayName.ifEmpty { "User Profile" },
                    email = currentEmail,
                    phoneNumber = currentUser.phoneNumber ?: "",
                    medicalInfo = "",
                    isActive = true,
                    preferredLanguage = "en",
                    createdAt = Timestamp.now(),
                    updatedAt = Timestamp.now()
                )

                if (isFinishing || isDestroyed) return@launch

                currentUserModel = finalUser
                displayUserProfile(finalUser)
                loadEmergencyContacts(userId)

            } catch (e: Exception) {
                Timber.e(e, "Error loading user profile")
                if (!isFinishing && !isDestroyed) {
                    val fallbackUser = User(
                        userId = userId,
                        fullName = currentDisplayName.ifEmpty { "User Profile" },
                        email = currentEmail,
                        phoneNumber = currentUser.phoneNumber ?: "",
                        medicalInfo = "",
                        isActive = true,
                        preferredLanguage = "en",
                        createdAt = Timestamp.now(),
                        updatedAt = Timestamp.now()
                    )
                    currentUserModel = fallbackUser
                    displayUserProfile(fallbackUser)
                }
            } finally {
                if (!isFinishing && !isDestroyed) {
                    profileProgressBar.visibility = android.view.View.GONE
                }
            }
        }
    }

    private fun displayUserProfile(user: User) {
        fullNameDisplay.text = user.fullName.ifEmpty { "User Profile" }
        emailDisplay.text = user.email.ifEmpty { auth.currentUser?.email ?: "" }

        fullNameInput.setText(user.fullName)
        phoneInput.setText(user.phoneNumber)
        languageInput.setText(user.preferredLanguage.ifEmpty { "en" })
        medicalInfoInput.setText(user.medicalInfo)

        val isSso = securityManager.isSsoUser() || auth.currentUser?.providerData?.any { it.providerId == "google.com" } == true
        if (isSso) {
            ssoBadge.text = getString(R.string.sso_linked_status)
            ssoBadge.visibility = android.view.View.VISIBLE
        } else {
            ssoBadge.text = getString(R.string.login)
            ssoBadge.visibility = android.view.View.VISIBLE
        }
    }

    private fun performSaveProfile() {
        val userId = auth.currentUser?.uid ?: return
        val fullName = fullNameInput.text.toString().trim()
        val phone = phoneInput.text.toString().trim()
        val language = languageInput.text.toString().trim()
        val medicalInfo = medicalInfoInput.text.toString().trim()

        // Inputs Validation to prevent crash or corrupted data
        if (fullName.isEmpty()) {
            fullNameInput.error = getString(R.string.error_field_required)
            fullNameInput.requestFocus()
            return
        }

        if (phone.isNotEmpty() && !isValidPhoneNumber(phone)) {
            phoneInput.error = getString(R.string.error_phone_invalid)
            phoneInput.requestFocus()
            return
        }

        profileProgressBar.visibility = android.view.View.VISIBLE
        saveProfileButton.isEnabled = false

        val updatedUser = User(
            userId = userId,
            fullName = fullName,
            email = currentUserModel?.email ?: auth.currentUser?.email ?: "",
            phoneNumber = phone,
            medicalInfo = medicalInfo,
            isActive = true,
            preferredLanguage = language.ifEmpty { "en" },
            createdAt = currentUserModel?.createdAt ?: Timestamp.now(),
            updatedAt = Timestamp.now()
        )

        lifecycleScope.launch {
            try {
                userRepository.updateUserProfile(updatedUser)
                if (isFinishing || isDestroyed) return@launch

                currentUserModel = updatedUser
                fullNameDisplay.text = fullName

                Toast.makeText(this@ProfileActivity, getString(R.string.profile_updated), Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Timber.e(e, "Error updating profile")
                if (!isFinishing && !isDestroyed) {
                    Toast.makeText(this@ProfileActivity, "Failed to update profile: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            } finally {
                if (!isFinishing && !isDestroyed) {
                    profileProgressBar.visibility = android.view.View.GONE
                    saveProfileButton.isEnabled = true
                }
            }
        }
    }

    private fun performUpdatePassword() {
        val newPassword = newPasswordInput.text.toString()
        val confirmPassword = confirmNewPasswordInput.text.toString()

        if (newPassword.isEmpty()) {
            newPasswordInput.error = getString(R.string.error_field_required)
            newPasswordInput.requestFocus()
            return
        }

        if (newPassword.length < 8) {
            newPasswordInput.error = getString(R.string.error_password_short)
            newPasswordInput.requestFocus()
            return
        }

        if (newPassword != confirmPassword) {
            confirmNewPasswordInput.error = getString(R.string.error_password_mismatch)
            confirmNewPasswordInput.requestFocus()
            return
        }

        profileProgressBar.visibility = android.view.View.VISIBLE
        updatePasswordButton.isEnabled = false

        lifecycleScope.launch {
            try {
                userRepository.updateUserPassword(newPassword)
                if (isFinishing || isDestroyed) return@launch

                newPasswordInput.text?.clear()
                confirmNewPasswordInput.text?.clear()

                Toast.makeText(this@ProfileActivity, getString(R.string.password_updated), Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Timber.e(e, "Failed to update password")
                if (!isFinishing && !isDestroyed) {
                    Toast.makeText(this@ProfileActivity, "Password update failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } finally {
                if (!isFinishing && !isDestroyed) {
                    profileProgressBar.visibility = android.view.View.GONE
                    updatePasswordButton.isEnabled = true
                }
            }
        }
    }

    private fun showAddContactDialog() {
        val userId = auth.currentUser?.uid ?: return

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 24)
        }

        val nameInput = EditText(this).apply {
            hint = "Contact Name"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        val relationInput = EditText(this).apply {
            hint = "Relationship (e.g. Sister, Friend)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        val phoneInput = EditText(this).apply {
            hint = "Phone Number (+27...)"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }

        layout.addView(nameInput)
        layout.addView(relationInput)
        layout.addView(phoneInput)

        AlertDialog.Builder(this)
            .setTitle(R.string.add_contact)
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val name = nameInput.text.toString().trim()
                val relation = relationInput.text.toString().trim()
                val phone = phoneInput.text.toString().trim()

                if (name.isEmpty()) {
                    Toast.makeText(this, "Contact name is required", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                if (phone.isEmpty() || !isValidPhoneNumber(phone)) {
                    Toast.makeText(this, getString(R.string.error_phone_invalid), Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val contactId = firestore.collection("users").document(userId).collection("emergency_contacts").document().id
                val contact = EmergencyContact(
                    contactId = contactId,
                    userId = userId,
                    name = name,
                    relationship = relation,
                    phoneNumber = phone
                )

                firestore.collection("users").document(userId).collection("emergency_contacts")
                    .document(contactId)
                    .set(contact)
                    .addOnSuccessListener {
                        if (!isFinishing && !isDestroyed) {
                            Toast.makeText(this, "Emergency Contact Added", Toast.LENGTH_SHORT).show()
                            loadEmergencyContacts(userId)
                        }
                    }
                    .addOnFailureListener { e ->
                        if (!isFinishing && !isDestroyed) {
                            Toast.makeText(this, "Failed to add contact: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun loadEmergencyContacts(userId: String) {
        firestore.collection("users").document(userId).collection("emergency_contacts")
            .get()
            .addOnSuccessListener { snapshot ->
                if (!isFinishing && !isDestroyed) {
                    val contacts = snapshot.toObjects(EmergencyContact::class.java)
                    displayEmergencyContacts(contacts)
                }
            }
            .addOnFailureListener { exception ->
                Timber.e(exception, "Failed to load emergency contacts")
            }
    }

    private fun displayEmergencyContacts(contacts: List<EmergencyContact>) {
        emergencyContactsContainer.removeAllViews()
        if (contacts.isEmpty()) {
            val emptyView = TextView(this).apply {
                text = getString(R.string.no_emergency_contacts)
                setPadding(0, 16, 0, 16)
                setTextColor(resources.getColor(R.color.text_secondary, null))
            }
            emergencyContactsContainer.addView(emptyView)
            return
        }

        for (contact in contacts) {
            val card = layoutInflater.inflate(R.layout.item_contact_card, emergencyContactsContainer, false)
            val nameView = card.findViewById<TextView>(R.id.contactName)
            val relationView = card.findViewById<TextView>(R.id.contactRelation)
            val phoneView = card.findViewById<TextView>(R.id.contactPhone)

            nameView.text = contact.name
            relationView.text = contact.relationship
            phoneView.text = contact.phoneNumber

            emergencyContactsContainer.addView(card)
        }
    }

    private fun isValidPhoneNumber(phone: String): Boolean {
        return com.example.esos_app_powa.utils.AuthValidator.isValidPhoneNumber(phone)
    }

    private fun showSignOutConfirmation() {
        AlertDialog.Builder(this)
            .setTitle(R.string.sign_out)
            .setMessage("Are you sure you want to sign out?")
            .setPositiveButton("Sign Out") { _, _ -> performSignOut() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun performSignOut() {
        ssoManager.signOutSso()
        userRepository.clearSession()
        navigateToLogin()
    }

    private fun showDeleteAccountConfirmation() {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_account)
            .setMessage("WARNING: This will permanently delete your account and all data. This action cannot be undone. Are you sure?")
            .setPositiveButton("Delete Permanently") { _, _ -> performDeleteAccount() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun performDeleteAccount() {
        val user = auth.currentUser
        val userId = user?.uid ?: return

        profileProgressBar.visibility = android.view.View.VISIBLE

        firestore.collection("users").document(userId).delete()
            .addOnSuccessListener {
                user.delete()
                    .addOnSuccessListener {
                        ssoManager.signOutSso()
                        userRepository.clearSession()
                        if (!isFinishing && !isDestroyed) {
                            Toast.makeText(this, "Account deleted successfully", Toast.LENGTH_LONG).show()
                            navigateToLogin()
                        }
                    }
                    .addOnFailureListener { exception ->
                        if (!isFinishing && !isDestroyed) {
                            profileProgressBar.visibility = android.view.View.GONE
                            Timber.e(exception, "Failed to delete auth user")
                            Toast.makeText(this, "Failed to delete account. Please re-authenticate and try again.", Toast.LENGTH_LONG).show()
                        }
                    }
            }
            .addOnFailureListener { exception ->
                if (!isFinishing && !isDestroyed) {
                    profileProgressBar.visibility = android.view.View.GONE
                    Timber.e(exception, "Failed to delete firestore data")
                    Toast.makeText(this, "Error deleting data", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
