package com.example.esos_app_powa.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.esos_app_powa.data.local.converters.AppTypeConverters
import com.example.esos_app_powa.data.local.dao.*
import com.example.esos_app_powa.data.local.entities.*
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import timber.log.Timber

@Database(
    entities = [
        UserEntity::class,
        SosAlertEntity::class,
        IncidentReportEntity::class,
        EmergencyContactEntity::class,
        MessageEntity::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(AppTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun sosAlertDao(): SosAlertDao
    abstract fun incidentReportDao(): IncidentReportDao
    abstract fun emergencyContactDao(): EmergencyContactDao
    abstract fun messageDao(): MessageDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, passphrase: ByteArray): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val existingInstance = INSTANCE
                if (existingInstance != null) {
                    return existingInstance
                }
                try {
                    val factory = SupportOpenHelperFactory(passphrase)
                    val instance = Room.databaseBuilder(
                        context.applicationContext,
                        AppDatabase::class.java,
                        "esos_database"
                    )
                        .openHelperFactory(factory)
                        .fallbackToDestructiveMigration()
                        .build()
                    INSTANCE = instance
                    instance
                } catch (e: Throwable) {
                    Timber.e(e, "Error opening encrypted database with SQLCipher, falling back to standard Room builder")
                    try {
                        context.deleteDatabase("esos_database")
                    } catch (ex: Throwable) {
                        Timber.e(ex, "Failed to delete corrupt database file")
                    }
                    val fallbackInstance = Room.databaseBuilder(
                        context.applicationContext,
                        AppDatabase::class.java,
                        "esos_database_std"
                    )
                        .fallbackToDestructiveMigration()
                        .build()
                    INSTANCE = fallbackInstance
                    fallbackInstance
                }
            }
        }
    }
}
