package com.example.esos_app_powa

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.esos_app_powa.ui.auth.LoginActivity
import com.example.esos_app_powa.ui.home.HomeActivity
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    @Inject
    lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        try {
            if (auth.currentUser != null) {
                startActivity(Intent(this, HomeActivity::class.java))
            } else {
                startActivity(Intent(this, LoginActivity::class.java))
            }
        } catch (e: Throwable) {
            Timber.e(e, "Error checking auth in MainActivity, navigating to Login")
            try {
                startActivity(Intent(this, LoginActivity::class.java))
            } catch (ex: Throwable) {
                Timber.e(ex, "Failed to launch LoginActivity")
            }
        }
        finish()
    }
}
