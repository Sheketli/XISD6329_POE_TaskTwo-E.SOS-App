package com.example.esos_app_powa.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.esos_app_powa.R
import com.example.esos_app_powa.auth.SsoManager
import com.example.esos_app_powa.data.repository.UserRepository
import com.example.esos_app_powa.ui.home.HomeActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.firebase.auth.FirebaseAuth
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@AndroidEntryPoint
class LoginActivity : AppCompatActivity() {
    
    @Inject
    lateinit var auth: FirebaseAuth

    @Inject
    lateinit var ssoManager: SsoManager

    @Inject
    lateinit var userRepository: UserRepository

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var googleSsoButton: Button
    private lateinit var registerLink: TextView
    private lateinit var forgotPasswordLink: TextView
    private lateinit var progressBar: ProgressBar

    private val googleSsoLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val intentData = result.data
        if (intentData == null && result.resultCode == RESULT_CANCELED) {
            Toast.makeText(this, "SSO Sign-In canceled", Toast.LENGTH_SHORT).show()
            googleSsoButton.isEnabled = true
            return@registerForActivityResult
        }

        val task = GoogleSignIn.getSignedInAccountFromIntent(intentData)
        lifecycleScope.launch {
            progressBar.visibility = android.view.View.VISIBLE
            googleSsoButton.isEnabled = false
            
            val authResult = ssoManager.handleGoogleSignInResult(task)
            if (isFinishing || isDestroyed) return@launch

            progressBar.visibility = android.view.View.GONE
            googleSsoButton.isEnabled = true

            authResult.fold(
                onSuccess = { _ ->
                    Toast.makeText(this@LoginActivity, "SSO Authentication Successful", Toast.LENGTH_SHORT).show()
                    navigateToHome()
                },
                onFailure = { exception ->
                    val message = exception.message ?: ""
                    if (message.contains("canceled", ignoreCase = true)) {
                        Toast.makeText(this@LoginActivity, "SSO Sign-In canceled", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@LoginActivity, "SSO Sign-In Failed: $message", Toast.LENGTH_LONG).show()
                    }
                    Timber.e(exception, "SSO Sign-In Error")
                }
            )
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        
        // Check if user is already logged in
        if (auth.currentUser != null) {
            navigateToHome()
            return
        }
        
        initializeViews()
        setupClickListeners()
    }
    
    private fun initializeViews() {
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)
        googleSsoButton = findViewById(R.id.googleSsoButton)
        registerLink = findViewById(R.id.registerLink)
        forgotPasswordLink = findViewById(R.id.forgotPasswordLink)
        progressBar = findViewById(R.id.progressBar)
    }
    
    private fun setupClickListeners() {
        loginButton.setOnClickListener { performLogin() }
        googleSsoButton.setOnClickListener { performGoogleSso() }
        registerLink.setOnClickListener { navigateToRegister() }
        forgotPasswordLink.setOnClickListener { handleForgotPassword() }
    }
    
    private fun performGoogleSso() {
        try {
            val signInIntent = ssoManager.getGoogleSignInClient().signInIntent
            googleSsoLauncher.launch(signInIntent)
        } catch (e: Exception) {
            Timber.e(e, "Error launching Google SSO")
            Toast.makeText(this, "Could not start Google SSO: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun performLogin() {
        val email = emailEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()
        
        // Validation
        if (!validateInputs(email, password)) {
            return
        }
        
        progressBar.visibility = android.view.View.VISIBLE
        loginButton.isEnabled = false
        
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { authResult ->
                val userId = authResult.user?.uid ?: ""
                lifecycleScope.launch {
                    try {
                        val user = userRepository.getUser(userId)
                        if (user != null) {
                            userRepository.saveUser(user, rawPassword = password, authProvider = "EMAIL")
                        }
                    } catch (e: Exception) {
                        Timber.e(e, "Error caching local session")
                    }
                    if (isFinishing || isDestroyed) return@launch
                    progressBar.visibility = android.view.View.GONE
                    Toast.makeText(this@LoginActivity, "Login successful", Toast.LENGTH_SHORT).show()
                    navigateToHome()
                }
            }
            .addOnFailureListener { exception ->
                if (isFinishing || isDestroyed) return@addOnFailureListener
                progressBar.visibility = android.view.View.GONE
                loginButton.isEnabled = true
                val message = when {
                    exception.message?.contains("user not found") == true -> "Email not registered"
                    exception.message?.contains("wrong password") == true -> "Incorrect password"
                    else -> exception.message ?: "Login failed"
                }
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                Timber.e(exception, "Login failed")
            }
    }
    
    private fun validateInputs(email: String, password: String): Boolean {
        return when {
            email.isEmpty() -> {
                emailEditText.error = getString(R.string.error_field_required)
                emailEditText.requestFocus()
                false
            }
            !com.example.esos_app_powa.utils.AuthValidator.isValidEmail(email) -> {
                emailEditText.error = getString(R.string.error_email_invalid)
                emailEditText.requestFocus()
                false
            }
            password.isEmpty() -> {
                passwordEditText.error = getString(R.string.error_field_required)
                passwordEditText.requestFocus()
                false
            }
            !com.example.esos_app_powa.utils.AuthValidator.isValidPassword(password) -> {
                passwordEditText.error = getString(R.string.error_password_short)
                passwordEditText.requestFocus()
                false
            }
            else -> true
        }
    }
    
    private fun handleForgotPassword() {
        val email = emailEditText.text.toString().trim()
        
        if (email.isEmpty()) {
            emailEditText.error = getString(R.string.error_field_required)
            emailEditText.requestFocus()
            Toast.makeText(this, "Please enter your email", Toast.LENGTH_SHORT).show()
            return
        }

        if (!com.example.esos_app_powa.utils.AuthValidator.isValidEmail(email)) {
            emailEditText.error = getString(R.string.error_email_invalid)
            emailEditText.requestFocus()
            return
        }
        
        auth.sendPasswordResetEmail(email)
            .addOnSuccessListener {
                if (!isFinishing && !isDestroyed) {
                    Toast.makeText(this, "Password reset email sent", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { exception ->
                if (!isFinishing && !isDestroyed) {
                    Toast.makeText(this, "Error: ${exception.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }
    
    private fun navigateToRegister() {
        val intent = Intent(this, RegisterActivity::class.java)
        startActivity(intent)
    }
    
    private fun navigateToHome() {
        val intent = Intent(this, HomeActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
