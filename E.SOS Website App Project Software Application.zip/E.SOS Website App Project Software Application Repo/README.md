# e.sos Website Application

e.sos is a support and safety web application for people affected by gender-based
violence in South Africa. It brings practical information and support tools
together in one place, including shelter and helpline directories, safety
planning resources, trusted contacts, and a private incident log.

The site is designed to make support easier to find. It is not an emergency
response service and does not replace a qualified counselor, lawyer, or the
police.

## Features

- **Find support:** Search shelter listings by name, location, province, or
  service, and browse helplines and help guides.
- **Safety tools:** Use the panic page to start a countdown and sound an alarm,
  call listed emergency numbers, or open a text message to a trusted ally.
  Location can be included in that message if the user allows browser location
  access.
- **Trusted allies:** Keep a list of people who may be able to help.
- **Evidence vault:** Record incident details, keep a timeline, and export
  entries as JSON. Selected evidence files are not uploaded; only their file
  names are recorded.
- **Automated chat:** Nomvula is a rule-based assistant that provides general
  information. The conversation is held in the current page and is not sent to
  a counselor or stored by the app.
- **Get involved:** Submit a donation pledge or volunteer application.
- **Account features:** Sign in with Firebase Authentication to sync supported
  account data with the local API. Some features also work using bundled data
  and browser storage without Firebase.
- **Privacy affordances:** Use the cover page to quickly switch to a neutral
  screen.

## Technology

- React 19, TypeScript, and Vite
- Tailwind CSS 4
- Firebase Authentication (optional; required for signed-in API sync)
- Node.js HTTP API and SQLite database

## Getting started

### Prerequisites

- Node.js 22.12 or later
- npm

### Install dependencies

From the repository root, run:

```bash
npm ci
```

### Start the website

```bash
npm run dev
```

Open the local URL printed by Vite (by default, `http://localhost:3000`).

### Start the API (optional)

The frontend can show bundled shelter and helpline data without the API. To
enable database-backed public data and account sync, start the API in a second
terminal:

```bash
npm run api
```

The API listens on port `3001` by default; Vite proxies `/api` requests to it.
The SQLite database is stored at `database/esos.db` by default. Set `ESOS_DB`
to use a different database file. If you change `API_PORT`, update the `/api`
proxy target in `vite.config.ts` to match.

Initialize or reseed the database with sample data:

```bash
npm run db:init
```

To clear and reseed the database, run `npm run db:reset`. **This deletes the
existing database records before inserting sample data.**

### Configure Firebase (optional)

Firebase is required for sign-in and signed-in API synchronization. Create a
`.env` file in the repository root with the Firebase project's web configuration
and project ID:

```dotenv
VITE_FIREBASE_API_KEY=your-firebase-web-api-key
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_APP_ID=your-firebase-app-id
FIREBASE_PROJECT_ID=your-project-id
```

The `VITE_` values configure the browser client. `FIREBASE_PROJECT_ID` is used
by the API to verify Firebase ID tokens. Enable the authentication providers
you intend to use in the Firebase project. Do not commit `.env` or private
credentials.

## Build and checks

```bash
npm run typecheck
npm run build
```

`npm run build` runs the TypeScript check and creates the production site in
`dist/`. To serve that build locally, use:

```bash
npm run preview
```

There is currently no test script configured in `package.json`.

## Safety and privacy notes

- The panic page **does not contact anyone automatically**. It plays an alarm
  in the browser and offers actions to call or message contacts; those actions
  require the user to continue through their device.
- In an immediate emergency in South Africa, call **10111**. The site also
  lists the GBV Command Centre at **0800 428 428**. Check current contact
  details and shelter availability with the relevant service.
- The chat is automated and provides general information only. It is not a
  live counselor or emergency service.
- Incident entries and trusted allies may be stored in browser storage and,
  when Firebase sync is enabled, in the configured API database. Use a device
  and account that are safe for you, and sign out or clear local browser data
  when appropriate.
- Shelter listings and other sample content must be verified before use in a
  live service. Do not rely on demo data as a substitute for contacting a
  provider.

## Contributing

Contributions are welcome. Before opening a pull request:

1. Create a branch for your change.
2. Keep changes focused and describe the user-facing impact.
3. Run `npm run typecheck` and `npm run build`.
4. Include or update tests when adding behavior, and update this README when
   setup or user-facing capabilities change.
5. Avoid including personal information, secrets, or real survivor records in
   code, commits, screenshots, or test data.
