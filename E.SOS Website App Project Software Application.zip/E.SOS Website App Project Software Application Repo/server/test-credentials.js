// Shared by the seed and export scripts. For sample data only - never reuse these for real accounts.
export const TEST_PASSWORD = "Test#1234";
export const TEST_DECOY = "Decoy#1234";
