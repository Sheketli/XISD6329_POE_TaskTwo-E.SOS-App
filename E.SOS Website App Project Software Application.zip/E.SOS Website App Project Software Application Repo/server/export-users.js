import { writeFileSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { openDb } from "./db.js";
import { TEST_PASSWORD, TEST_DECOY } from "./test-credentials.js";

const out = resolve(dirname(fileURLToPath(import.meta.url)), "..", "database", "users.txt");
const db = openDb();
const users = db.prepare("SELECT * FROM users ORDER BY created_at").all();

const lines = [
  "e.sos - USER ACCOUNTS",
  `Exported: ${new Date().toISOString()}`,
  `Total users: ${users.length}`,
  "",
  "NOTE: Real passwords are stored only as one-way PBKDF2-SHA256 hashes (pbkdf2$iterations$salt$hash).",
  "Sample accounts (ID starting 'seed-') are the exception below: they share a KNOWN TEST password so",
  "you can verify them. This file is generated from database/esos.db with `npm run db:export` and must",
  "be kept private.",
  "",
  "=".repeat(78),
];

users.forEach((u, i) => {
  lines.push(
    `User #${i + 1}`,
    `  ID              : ${u.id}`,
    `  Full name       : ${u.full_name ?? "-"}`,
    `  Username        : ${u.username}`,
    `  Email           : ${u.email}`,
    `  Phone           : ${u.phone ?? "-"}`,
    `  Province        : ${u.province ?? "-"}`,
    `  Sign-in method  : ${u.auth_provider}`,
    `  Role            : ${u.role}`,
    `  Email verified  : ${u.email_verified ? "yes" : "no"}`,
    `  Password        : ${u.id.startsWith("seed-") ? TEST_PASSWORD + "  (test password)" : "(hashed - not readable)"}`,
    `  Password (hash) : ${u.password_hash ?? "none"}`,
    `  Decoy password  : ${u.decoy_hash ? (u.id.startsWith("seed-") ? TEST_DECOY + "  (test decoy)" : "set (hashed)") : "not set"}`,
    `  Decoy (hash)    : ${u.decoy_hash ?? "not set"}`,
    `  Created         : ${u.created_at}`,
    `  Last login      : ${u.last_login_at ?? "-"}`,
    "-".repeat(78),
  );
});

writeFileSync(out, lines.join("\r\n") + "\r\n", "utf8");
console.log(`Wrote ${users.length} users to ${out}`);
