import { pbkdf2Sync, randomBytes } from "node:crypto";
import { openDb, tx } from "./db.js";
import { TEST_PASSWORD, TEST_DECOY } from "./test-credentials.js";
import { USERS, SHELTERS, HELPLINES, REPORTS, ALLIES, DONATIONS, VOLUNTEERS } from "./seed-data.js";

const ITERATIONS = 210_000;

// Same format the website uses: pbkdf2$iterations$salt$hash
function hashSecret(secret) {
  const salt = randomBytes(16);
  return `pbkdf2$${ITERATIONS}$${salt.toString("hex")}$${pbkdf2Sync(secret, salt, ITERATIONS, 32, "sha256").toString("hex")}`;
}

const reset = process.argv.includes("--reset");
const db = openDb();

if (reset) {
  db.exec(`DELETE FROM report_attachments; DELETE FROM evidence_reports; DELETE FROM trusted_allies;
           DELETE FROM shelter_services; DELETE FROM shelters; DELETE FROM helplines;
           DELETE FROM donations; DELETE FROM volunteer_applications; DELETE FROM users;
           DELETE FROM sqlite_sequence;`);
}

const count = (t) => db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get().n;
if (!reset && count("users") > 0) {
  console.log("Database already has data. Use `npm run db:reset` to wipe and re-seed.");
  process.exit(0);
}

tx(db, () => {
  const addUser = db.prepare(`INSERT INTO users (id, full_name, username, email, phone, province, password_hash, decoy_hash,
    auth_provider, role, email_verified, created_at, last_login_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  for (const u of USERS) {
    // Sample accounts share a known test password (documented in users.txt) so the database demo is usable.
    const password = hashSecret(TEST_PASSWORD);
    const decoy = u.decoy ? hashSecret(TEST_DECOY) : null;
    addUser.run(u.id, u.full_name, u.username, u.email, u.phone, u.province, password, decoy, u.auth_provider, u.role, u.verified, u.created, u.created);
  }

  const addShelter = db.prepare("INSERT INTO shelters (id, name, location, province, phone, capacity) VALUES (?,?,?,?,?,?)");
  const addService = db.prepare("INSERT INTO shelter_services (shelter_id, service) VALUES (?,?)");
  for (const [id, name, location, province, phone, capacity, services] of SHELTERS) {
    addShelter.run(id, name, location, province, phone, capacity);
    services.forEach((s) => addService.run(id, s));
  }

  const addHelpline = db.prepare("INSERT INTO helplines (name, phone, dial, category, details, is_top) VALUES (?,?,?,?,?,?)");
  HELPLINES.forEach((h) => addHelpline.run(...h));

  const addReport = db.prepare(`INSERT INTO evidence_reports (id, user_id, title, incident_type, incident_date, incident_time, description, confidentiality, created_at)
    VALUES (?,?,?,?,?,?,?,?,?)`);
  const addFile = db.prepare("INSERT INTO report_attachments (report_id, file_name) VALUES (?,?)");
  REPORTS.forEach(([ui, title, type, date, time, desc, files], i) => {
    const id = `seed-r${String(i + 1).padStart(2, "0")}`;
    addReport.run(id, USERS[ui].id, title, type, date, time, desc, "private", `${date}T${time}:00Z`);
    files.forEach((f) => addFile.run(id, f));
  });

  const addAlly = db.prepare("INSERT INTO trusted_allies (id, user_id, name, relationship, phone) VALUES (?,?,?,?,?)");
  ALLIES.forEach(([ui, name, rel, phone], i) => addAlly.run(`seed-a${String(i + 1).padStart(2, "0")}`, USERS[ui].id, name, rel, phone));

  const addDonation = db.prepare("INSERT INTO donations (reference, donor_name, donor_email, amount_zar, status, created_at) VALUES (?,?,?,?,?,?)");
  DONATIONS.forEach((d) => addDonation.run(...d));

  const addVol = db.prepare(`INSERT INTO volunteer_applications (full_name, email, phone, role, availability, motivation, status, created_at)
    VALUES (?,?,?,?,?,?,?,?)`);
  VOLUNTEERS.forEach((v) => addVol.run(...v));
});

for (const t of ["users", "shelters", "shelter_services", "helplines", "evidence_reports", "report_attachments", "trusted_allies", "donations", "volunteer_applications"]) {
  console.log(`${t.padEnd(24)} ${count(t)} rows`);
}
