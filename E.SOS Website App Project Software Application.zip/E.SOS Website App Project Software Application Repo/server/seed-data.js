// Realistic sample data (fictional people). Shelters and helplines are real public South African services.
export const USERS = [
  { id: "seed-u01", full_name: "Thandiwe Nkosi", username: "thandi", email: "thandiwe.nkosi@example.com", phone: "082 555 0101", province: "Gauteng", auth_provider: "password", role: "member", verified: 1, created: "2026-01-12T08:15:00Z", decoy: true },
  { id: "seed-u02", full_name: "Lerato Mokoena", username: "lerato_m", email: "lerato.mokoena@example.com", phone: "083 555 0102", province: "Gauteng", auth_provider: "google", role: "member", verified: 1, created: "2026-01-19T10:40:00Z" },
  { id: "seed-u03", full_name: "Naledi Dlamini", username: "naledi", email: "naledi.dlamini@example.com", phone: "071 555 0103", province: "KwaZulu-Natal", auth_provider: "password", role: "member", verified: 1, created: "2026-02-03T13:05:00Z", decoy: true },
  { id: "seed-u04", full_name: "Ayanda Zulu", username: "ayanda_z", email: "ayanda.zulu1@example.com", phone: "072 555 0104", province: "KwaZulu-Natal", auth_provider: "google", role: "member", verified: 1, created: "2026-02-14T09:22:00Z" },
  { id: "seed-u05", full_name: "Fatima Patel", username: "fatima", email: "fatima.patel@example.com", phone: "084 555 0105", province: "Western Cape", auth_provider: "password", role: "member", verified: 0, created: "2026-02-27T16:48:00Z" },
  { id: "seed-u06", full_name: "Zanele Khumalo", username: "zanele_k", email: "zanele.khumalo@example.com", phone: "073 555 0106", province: "Gauteng", auth_provider: "password", role: "volunteer", verified: 1, created: "2026-03-05T07:30:00Z" },
  { id: "seed-u07", full_name: "Megan van der Merwe", username: "megan_vdm", email: "megan.vdmerwe@example.com", phone: "076 555 0107", province: "Western Cape", auth_provider: "google", role: "member", verified: 1, created: "2026-03-18T11:10:00Z" },
  { id: "seed-u08", full_name: "Palesa Sithole", username: "palesa", email: "palesa.sithole@example.com", phone: "060 555 0108", province: "Mpumalanga", auth_provider: "password", role: "member", verified: 1, created: "2026-04-02T14:55:00Z", decoy: true },
  { id: "seed-u09", full_name: "Nomsa Ndlovu", username: "nomsa_n", email: "nomsa.ndlovu@example.com", phone: "079 555 0109", province: "Limpopo", auth_provider: "password", role: "member", verified: 0, created: "2026-04-21T18:02:00Z" },
  { id: "seed-u10", full_name: "Refilwe Molefe", username: "refilwe", email: "refilwe.molefe@example.com", phone: "081 555 0110", province: "Free State", auth_provider: "google", role: "member", verified: 1, created: "2026-05-09T12:34:00Z" },
  { id: "seed-u11", full_name: "Busisiwe Mahlangu", username: "busi_m", email: "busisiwe.mahlangu@example.com", phone: "074 555 0111", province: "Eastern Cape", auth_provider: "password", role: "volunteer", verified: 1, created: "2026-06-01T09:00:00Z" },
  { id: "seed-u12", full_name: "Sheketli Mochaki", username: "admin_sheketli", email: "admin@example.com", phone: "011 555 0112", province: "Gauteng", auth_provider: "password", role: "admin", verified: 1, created: "2026-01-02T08:00:00Z" },
];

export const SHELTERS = [
  ["s1", "Frida Hartley Shelter", "Yeoville, Johannesburg", "Gauteng", "011 648 6005", "Available", ["Counseling", "Skills development", "Employment support", "Children welcome"]],
  ["s2", "Nisaa Institute for Women's Development", "Lenasia, Johannesburg", "Gauteng", "011 854 6372", "Limited", ["Legal advocacy", "Clinical therapy", "Immediate admission", "Children welcome"]],
  ["s3", "POWA Crisis Safe House", "Berea, Johannesburg", "Gauteng", "011 642 4345", "Available", ["24/7 security", "Psychosocial support", "Legal aid", "Emergency transport"]],
  ["s4", "Sisters Incorporated", "Kenilworth, Cape Town", "Western Cape", "021 797 4190", "Limited", ["Pregnancy support", "Infant care", "Individual therapy", "Long-term stay"]],
  ["s5", "Saartjie Baartman Centre", "Manenberg, Cape Town", "Western Cape", "021 633 5287", "Full", ["Child counseling", "Legal advice clinic", "Residential shelter", "Medical care"]],
  ["s6", "The Safe House", "Stellenbosch", "Western Cape", "0861 322 322", "Available", ["Security", "Trauma counseling", "Safe haven"]],
  ["s7", "Open Door Crisis Care Centre", "Pinetown, Durban", "KwaZulu-Natal", "031 709 2637", "Available", ["Trauma centre", "Social work", "Support groups", "Court accompaniment"]],
  ["s8", "Thuthuzela Care Centre", "Mamelodi, Pretoria", "Gauteng", "012 841 9000", "Available", ["Medical care", "Counseling", "Court preparation"]],
  ["s9", "Masithandane Shelter", "Mthatha", "Eastern Cape", "047 531 0000", "Limited", ["Safe haven", "Social work", "Children welcome"]],
  ["s10", "Bloemfontein Women's Haven", "Bloemfontein", "Free State", "051 447 0000", "Available", ["Counseling", "Legal advice clinic", "Skills development"]],
  ["s11", "Mpumalanga Safe Haven", "Mbombela", "Mpumalanga", "013 752 0000", "Full", ["24/7 security", "Trauma counseling"]],
  ["s12", "Polokwane Crisis Home", "Polokwane", "Limpopo", "015 295 0000", "Available", ["Emergency admission", "Psychosocial support", "Children welcome"]],
];

export const HELPLINES = [
  ["GBV Command Centre", "0800 428 428", "0800428428", "Counseling and abuse support", "Toll-free, 24/7. Speak to a trauma counselor.", 1],
  ["SAPS emergency", "10111", "10111", "Police", "Nationwide police emergency line. Call if you are in immediate danger.", 1],
  ["Family Violence, Child Protection and Sexual Offences Unit", "08600 10111", "08600 10111", "Police", "Open protection filings and report domestic assault.", 0],
  ["Childline South Africa", "0800 055 555", "0800055555", "Children and youth", "Toll-free, 24 hours, in all official languages.", 1],
  ["TEARS Foundation", "*134*7355#", "*134*7355%23", "Self-help (USSD)", "Dial from your phone to find the nearest emergency clinic.", 0],
  ["LifeLine SA", "0861 322 322", "0861322322", "Crisis and trauma care", "Emotional support and referrals.", 0],
  ["Legal Aid South Africa", "0800 110 110", "0800110110", "Legal help", "Free legal advice, including protection orders.", 0],
  ["SA Human Rights Commission", "011 877 3600", "0118773600", "Legal help", "Report human-rights violations.", 0],
  ["Stop Gender Violence Helpline", "0800 150 150", "0800150150", "Counseling and abuse support", "Toll-free, 24/7 support for survivors of gender-based violence.", 0],
  ["SADAG Mental Health Line", "0800 456 789", "0800456789", "Crisis and trauma care", "Toll-free depression and anxiety support, 8am to 8pm.", 0],
  ["Rape Crisis Cape Town", "021 447 9762", "0214479762", "Counseling and abuse support", "Counseling and court support for survivors of sexual violence.", 0],
  ["Lifeline Suicide Crisis Line", "0800 567 567", "0800567567", "Crisis and trauma care", "Toll-free suicide crisis line, 24/7.", 0],
];

// [userIndex, title, type, date, time, description, attachments]
export const REPORTS = [
  [0, "Verbal threats at home", "Psychological abuse", "2026-02-10", "21:15", "Partner shouted threats and blocked the doorway when I tried to leave the lounge.", ["voice-note.m4a"]],
  [0, "Phone taken away", "Economic control", "2026-03-02", "08:30", "Partner took my phone and bank card before work and refused to return them.", []],
  [2, "Pushed during argument", "Physical abuse", "2026-02-21", "19:45", "Pushed against the kitchen wall. Bruising on my upper arm, photographed the same night.", ["bruise-photo.jpg", "kitchen-wall-photo.jpg"]],
  [2, "Repeated threatening messages", "Emotional abuse", "2026-03-15", "23:05", "Received more than twenty threatening WhatsApp messages in one evening.", ["messages-screenshot.png"]],
  [4, "Followed home from work", "Stalking or tracking", "2026-03-30", "17:50", "Ex-partner followed my taxi and waited outside my building for an hour.", []],
  [4, "Unknown tracker in bag", "Stalking or tracking", "2026-04-04", "07:20", "Found a small tracking device sewn into the lining of my handbag.", ["tracker-photo.jpg", "bag-lining-photo.jpg"]],
  [7, "Money withheld", "Economic control", "2026-04-12", "12:00", "Salary was redirected to an account I cannot access for the third month in a row.", ["payslip.pdf"]],
  [7, "Locked out of the house", "Psychological abuse", "2026-04-28", "22:30", "Locked outside overnight after refusing to hand over my phone.", []],
  [8, "Slapped in front of children", "Physical abuse", "2026-05-06", "18:10", "Slapped across the face during an argument while the children watched.", ["medical-note.pdf"]],
  [9, "Insults and name calling", "Emotional abuse", "2026-05-19", "20:00", "Daily insults for weeks, recorded one incident on my phone.", ["recording.mp3"]],
  [1, "Harassment on social media", "Other", "2026-06-02", "09:40", "Multiple fake accounts created to harass and impersonate me.", ["screenshots.zip"]],
  [3, "Threatened with a knife", "Physical abuse", "2026-06-14", "21:55", "Partner held a kitchen knife and threatened me. Reported to the police, case number noted.", ["case-number.txt"]],
];

// [userIndex, name, relationship, phone]
export const ALLIES = [
  [0, "Sibongile Nkosi", "Sister", "082 555 0201"],
  [0, "Dr. Mpho Radebe", "Family doctor", "011 555 0202"],
  [1, "Karabo Mokoena", "Cousin", "083 555 0203"],
  [2, "Zodwa Dlamini", "Mother", "071 555 0204"],
  [2, "Pastor Sipho Mthembu", "Pastor", "031 555 0205"],
  [3, "Thulani Zulu", "Brother", "072 555 0206"],
  [4, "Aisha Patel", "Best friend", "084 555 0207"],
  [6, "Charlene Botha", "Colleague", "076 555 0208"],
  [7, "Lindiwe Sithole", "Aunt", "060 555 0209"],
  [8, "Grace Ndlovu", "Neighbour", "079 555 0210"],
  [9, "Dineo Molefe", "Friend", "081 555 0211"],
  [10, "Anele Mahlangu", "Sister", "074 555 0212"],
];

// [reference, name, email, amount, status, created]
export const DONATIONS = [
  ["PW-100234", "Karen Smit", "karen.smit@example.com", 250, "received", "2026-03-01T09:00:00Z"],
  ["PW-100871", "Sipho Mabasa", "sipho.mabasa@example.com", 500, "received", "2026-03-04T11:30:00Z"],
  ["PW-101455", "Anonymous", "donor1@example.com", 50, "received", "2026-03-12T15:20:00Z"],
  ["PW-102018", "Priya Naidoo", "priya.naidoo@example.com", 1000, "received", "2026-04-02T08:10:00Z"],
  ["PW-102977", "Johan Pretorius", "johan.pretorius@example.com", 150, "received", "2026-04-18T13:45:00Z"],
  ["PW-103340", "Mbali Cele", "mbali.cele@example.com", 250, "pledged", "2026-05-03T10:05:00Z"],
  ["PW-104112", "Tebogo Sekhu", "tebogo.sekhu@example.com", 100, "received", "2026-05-21T17:00:00Z"],
  ["PW-104689", "Anonymous", "donor2@example.com", 750, "pledged", "2026-06-07T12:12:00Z"],
  ["PW-105230", "Elize Joubert", "elize.joubert@example.com", 300, "received", "2026-06-25T09:55:00Z"],
  ["PW-105901", "Vusi Mkhize", "vusi.mkhize@example.com", 200, "cancelled", "2026-07-11T14:30:00Z"],
  ["PW-106478", "Hannah Cohen", "hannah.cohen@example.com", 500, "received", "2026-08-02T16:40:00Z"],
  ["PW-107003", "Thabo Maseko", "thabo.maseko@example.com", 150, "pledged", "2026-09-15T08:25:00Z"],
];

// [name, email, phone, role, availability, motivation, status, created]
export const VOLUNTEERS = [
  ["Zanele Khumalo", "zanele.khumalo@example.com", "073 555 0106", "Crisis helpline operator", "Weekdays, Mornings", "I survived an abusive relationship and want to give other women the support I needed.", "accepted", "2026-03-06T08:00:00Z"],
  ["Busisiwe Mahlangu", "busisiwe.mahlangu@example.com", "074 555 0111", "Counseling and social support", "Weekends", "I am a final-year social work student looking for field experience supporting survivors.", "accepted", "2026-06-02T10:00:00Z"],
  ["Rachel Adams", "rachel.adams@example.com", "082 555 0301", "Legal aid helper", "Weekdays, Afternoons", "I am a paralegal and can help clients complete protection order applications.", "screening", "2026-06-20T09:30:00Z"],
  ["Mandla Zwane", "mandla.zwane@example.com", "083 555 0302", "Community awareness and events", "Weekends", "I coordinate men's accountability workshops in my community and want to partner with POWA.", "screening", "2026-06-28T14:10:00Z"],
  ["Sarah Williams", "sarah.williams@example.com", "084 555 0303", "Admin and clerical support", "Weekdays", "Ten years of office administration experience and I can offer three days a week.", "new", "2026-07-08T11:00:00Z"],
  ["Ntombi Radebe", "ntombi.radebe@example.com", "071 555 0304", "Media, design and marketing", "Weekends, Afternoons", "Graphic designer who wants to create awareness campaigns for the 16 Days of Activism.", "new", "2026-07-15T16:45:00Z"],
  ["Pieter Botha", "pieter.botha@example.com", "072 555 0305", "Crisis helpline operator", "Weekdays, Mornings", "Retired police officer with experience handling domestic violence call-outs.", "declined", "2026-07-22T09:15:00Z"],
  ["Amahle Ngcobo", "amahle.ngcobo@example.com", "073 555 0306", "Counseling and social support", "Weekdays, Afternoons", "Registered counsellor completing my community service year.", "screening", "2026-08-05T10:20:00Z"],
  ["Imran Khan", "imran.khan@example.com", "076 555 0307", "Community awareness and events", "Weekends", "I run a youth group and want to teach teenagers about healthy relationships.", "new", "2026-08-19T13:00:00Z"],
  ["Lwazi Dube", "lwazi.dube@example.com", "079 555 0308", "Admin and clerical support", "Weekdays, Mornings", "Looking to volunteer while between jobs, comfortable with data capture and filing.", "accepted", "2026-09-02T08:40:00Z"],
  ["Chantal Dupont", "chantal.dupont@example.com", "060 555 0309", "Legal aid helper", "Weekends", "Law student at Wits, available on weekends to support the legal advice clinic.", "new", "2026-09-14T12:30:00Z"],
  ["Kgomotso Phiri", "kgomotso.phiri@example.com", "081 555 0310", "Media, design and marketing", "Weekdays, Afternoons", "Social media manager who can run POWA's accounts and content calendar.", "screening", "2026-10-01T15:00:00Z"],
];
