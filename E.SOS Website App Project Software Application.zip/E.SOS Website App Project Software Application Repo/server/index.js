import { createServer } from "node:http";
import { createVerify } from "node:crypto";
import { existsSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { openDb, tx } from "./db.js";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
if (existsSync(resolve(root, ".env"))) process.loadEnvFile(resolve(root, ".env"));

const PORT = Number(process.env.API_PORT ?? 3001);
const PROJECT_ID = process.env.FIREBASE_PROJECT_ID ?? process.env.VITE_FIREBASE_PROJECT_ID;
const CERTS_URL = "https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com";
const HASH_RE = /^pbkdf2\$\d{5,7}\$[0-9a-f]{32}\$[0-9a-f]{64}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const db = openDb();

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const bad = (msg) => new HttpError(400, msg);

// ---------- Firebase ID token verification (RS256, Google public certificates) ----------
let certs = { at: 0, keys: {} };
async function getCerts() {
  if (Date.now() - certs.at < 3_600_000 && Object.keys(certs.keys).length) return certs.keys;
  const res = await fetch(CERTS_URL);
  if (!res.ok) throw new HttpError(503, "Could not load Firebase signing keys.");
  certs = { at: Date.now(), keys: await res.json() };
  return certs.keys;
}

async function verifyToken(token) {
  if (!PROJECT_ID) throw new HttpError(503, "Server is missing FIREBASE_PROJECT_ID.");
  const parts = token.split(".");
  if (parts.length !== 3) throw new HttpError(401, "Invalid token.");
  const decode = (s) => JSON.parse(Buffer.from(s, "base64url").toString("utf8"));
  let header, claims;
  try {
    header = decode(parts[0]);
    claims = decode(parts[1]);
  } catch {
    throw new HttpError(401, "Invalid token.");
  }
  const pem = (await getCerts())[header.kid];
  const now = Math.floor(Date.now() / 1000);
  const ok =
    header.alg === "RS256" &&
    pem &&
    createVerify("RSA-SHA256").update(`${parts[0]}.${parts[1]}`).verify(pem, Buffer.from(parts[2], "base64url")) &&
    claims.aud === PROJECT_ID &&
    claims.iss === `https://securetoken.google.com/${PROJECT_ID}` &&
    typeof claims.sub === "string" && claims.sub &&
    claims.exp > now &&
    claims.iat <= now + 60;
  if (!ok) throw new HttpError(401, "Invalid or expired token.");
  return claims;
}

async function authenticate(req) {
  const m = /^Bearer (.+)$/.exec(req.headers.authorization ?? "");
  if (!m) throw new HttpError(401, "Sign in required.");
  return verifyToken(m[1]);
}

// ---------- helpers ----------
const hits = new Map();
function rateLimit(req, limit = 20, windowMs = 60_000) {
  const ip = req.socket.remoteAddress ?? "?";
  const now = Date.now();
  const list = (hits.get(ip) ?? []).filter((t) => now - t < windowMs);
  list.push(now);
  hits.set(ip, list);
  if (list.length > limit) throw new HttpError(429, "Too many requests. Please wait a minute.");
}

async function readBody(req) {
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > 100_000) throw new HttpError(413, "Request too large.");
    chunks.push(c);
  }
  if (!chunks.length) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw bad("Body must be valid JSON.");
  }
}

const str = (v, name, { min = 1, max = 500, optional = false } = {}) => {
  if ((v === undefined || v === null || v === "") && optional) return null;
  if (typeof v !== "string") throw bad(`${name} is required.`);
  const s = v.trim();
  if (s.length < min || s.length > max) throw bad(`${name} must be ${min}-${max} characters.`);
  return s;
};

const reportOut = (r, files) => ({
  id: r.id, title: r.title, type: r.incident_type, date: r.incident_date, time: r.incident_time,
  description: r.description, confidentiality: r.confidentiality, attachments: files, createdAt: r.created_at,
});

// ---------- routes ----------
const routes = [];
const route = (method, pattern, handler) => routes.push({ method, re: new RegExp(`^${pattern}$`), handler });

route("GET", "/api/health", () => ({
  status: "ok",
  users: db.prepare("SELECT COUNT(*) AS n FROM users").get().n,
  firebaseProject: PROJECT_ID ?? null,
}));

route("GET", "/api/shelters", () => {
  const services = db.prepare("SELECT shelter_id, service FROM shelter_services ORDER BY id").all();
  return db.prepare("SELECT * FROM shelters ORDER BY province, name").all().map((s) => ({
    id: s.id, name: s.name, location: s.location, province: s.province, phone: s.phone, capacity: s.capacity,
    services: services.filter((x) => x.shelter_id === s.id).map((x) => x.service),
  }));
});

route("GET", "/api/helplines", () =>
  db.prepare("SELECT name, phone, dial, category, details, is_top FROM helplines ORDER BY id").all()
    .map(({ is_top, ...h }) => ({ ...h, top: Boolean(is_top) })));

route("POST", "/api/donations", async (req) => {
  rateLimit(req);
  const b = await readBody(req);
  const email = str(b.email, "Email", { max: 200 });
  if (!EMAIL_RE.test(email)) throw bad("Enter a valid email address.");
  const amount = Number(b.amount);
  if (!Number.isFinite(amount) || amount <= 0 || amount > 1_000_000) throw bad("Amount must be between R1 and R1,000,000.");
  const reference = str(b.reference, "Reference", { max: 30 });
  if (!/^PW-\d{6}$/.test(reference)) throw bad("Invalid reference.");
  try {
    db.prepare("INSERT INTO donations (reference, donor_name, donor_email, amount_zar) VALUES (?,?,?,?)")
      .run(reference, str(b.name, "Name", { optional: true, max: 120 }), email, amount);
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) throw new HttpError(409, "That reference already exists.");
    throw e;
  }
  return { status: 201, body: { reference } };
});

route("POST", "/api/volunteers", async (req) => {
  rateLimit(req);
  const b = await readBody(req);
  const email = str(b.email, "Email", { max: 200 });
  if (!EMAIL_RE.test(email)) throw bad("Enter a valid email address.");
  const times = Array.isArray(b.availability) ? b.availability.filter((x) => typeof x === "string").slice(0, 8) : [];
  if (!times.length) throw bad("Select at least one availability.");
  const info = db.prepare(`INSERT INTO volunteer_applications (full_name, email, phone, role, availability, motivation)
    VALUES (?,?,?,?,?,?)`).run(
    str(b.name, "Name", { max: 120 }), email, str(b.phone, "Phone", { optional: true, max: 30 }),
    str(b.role, "Role", { max: 120 }), times.join(", "), str(b.motivation, "Motivation", { min: 20, max: 2000 }),
  );
  return { status: 201, body: { id: Number(info.lastInsertRowid) } };
});

const userOut = (u) => ({
  id: u.id, email: u.email, username: u.username, fullName: u.full_name, phone: u.phone, province: u.province,
  provider: u.auth_provider, role: u.role, createdAt: u.created_at, hasDecoy: Boolean(u.decoy_hash),
});

route("GET", "/api/users/me", async (req) => {
  const claims = await authenticate(req);
  const u = db.prepare("SELECT * FROM users WHERE id = ?").get(claims.sub);
  if (!u) throw new HttpError(404, "No profile yet.");
  return userOut(u);
});

route("PUT", "/api/users/me", async (req) => {
  const claims = await authenticate(req);
  const b = await readBody(req);
  const email = claims.email;
  if (!email) throw bad("Account has no email address.");
  const existing = db.prepare("SELECT * FROM users WHERE id = ?").get(claims.sub);
  const clash = db.prepare("SELECT id FROM users WHERE email = ? AND id <> ?").get(email, claims.sub);
  if (clash) throw new HttpError(409, "That email belongs to another account.");

  const provider = claims.firebase?.sign_in_provider === "google.com" ? "google" : "password";
  const pick = (key, current) => (key in b ? b[key] : current);
  const hash = (key, current) => {
    if (!(key in b)) return current;
    if (b[key] === null) return null;
    if (typeof b[key] !== "string" || !HASH_RE.test(b[key])) throw bad("Passwords must be sent as PBKDF2 hashes.");
    return b[key];
  };
  const next = {
    username: str(pick("username", existing?.username ?? email.split("@")[0]), "Username", { max: 60 }),
    full_name: str(pick("fullName", existing?.full_name ?? claims.name), "Full name", { optional: true, max: 120 }),
    phone: str(pick("phone", existing?.phone), "Phone", { optional: true, max: 30 }),
    province: str(pick("province", existing?.province), "Province", { optional: true, max: 60 }),
    password_hash: hash("passwordHash", existing?.password_hash ?? null),
    decoy_hash: hash("decoyHash", existing?.decoy_hash ?? null),
  };
  const verified = claims.email_verified ? 1 : 0;
  const now = new Date().toISOString();
  if (existing) {
    db.prepare(`UPDATE users SET username=?, full_name=?, phone=?, province=?, password_hash=?, decoy_hash=?, email=?,
      auth_provider=?, email_verified=?, last_login_at=? WHERE id=?`)
      .run(next.username, next.full_name, next.phone, next.province, next.password_hash, next.decoy_hash, email, provider, verified, now, claims.sub);
  } else {
    db.prepare(`INSERT INTO users (id, full_name, username, email, phone, province, password_hash, decoy_hash, auth_provider,
      email_verified, last_login_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)`)
      .run(claims.sub, next.full_name, next.username, email, next.phone, next.province, next.password_hash, next.decoy_hash, provider, verified, now);
  }
  return userOut(db.prepare("SELECT * FROM users WHERE id = ?").get(claims.sub));
});

route("DELETE", "/api/users/me", async (req) => {
  const claims = await authenticate(req);
  db.prepare("DELETE FROM users WHERE id = ?").run(claims.sub);
  return { status: 204 };
});

const requireUser = async (req) => {
  const claims = await authenticate(req);
  if (!db.prepare("SELECT 1 FROM users WHERE id = ?").get(claims.sub)) throw new HttpError(409, "Profile not synced yet.");
  return claims.sub;
};

route("GET", "/api/reports", async (req) => {
  const uid = await requireUser(req);
  const files = db.prepare(`SELECT a.report_id, a.file_name FROM report_attachments a
    JOIN evidence_reports r ON r.id = a.report_id WHERE r.user_id = ? ORDER BY a.id`).all(uid);
  return db.prepare("SELECT * FROM evidence_reports WHERE user_id = ? ORDER BY created_at DESC").all(uid)
    .map((r) => reportOut(r, files.filter((f) => f.report_id === r.id).map((f) => f.file_name)));
});

route("POST", "/api/reports", async (req) => {
  const uid = await requireUser(req);
  const b = await readBody(req);
  const id = str(b.id, "Id", { max: 60 });
  const date = str(b.date, "Date", { max: 10 });
  const time = str(b.time, "Time", { max: 5 });
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time)) throw bad("Invalid date or time.");
  const files = (Array.isArray(b.attachments) ? b.attachments : []).filter((f) => typeof f === "string").slice(0, 20);
  tx(db, () => {
    if (db.prepare("SELECT 1 FROM evidence_reports WHERE id = ?").get(id)) throw new HttpError(409, "Report already exists.");
    db.prepare(`INSERT INTO evidence_reports (id, user_id, title, incident_type, incident_date, incident_time, description, confidentiality, created_at)
      VALUES (?,?,?,?,?,?,?,?,?)`).run(id, uid, str(b.title, "Title", { max: 200 }), str(b.type, "Type", { max: 80 }), date, time,
      str(b.description, "Description", { min: 10, max: 5000 }), str(b.confidentiality, "Confidentiality", { optional: true, max: 30 }) ?? "private",
      typeof b.createdAt === "string" ? b.createdAt.slice(0, 30) : new Date().toISOString());
    files.forEach((f) => db.prepare("INSERT INTO report_attachments (report_id, file_name) VALUES (?,?)").run(id, f.slice(0, 255)));
  });
  return { status: 201, body: { id } };
});

route("DELETE", "/api/reports/([\\w-]+)", async (req, m) => {
  const uid = await requireUser(req);
  db.prepare("DELETE FROM evidence_reports WHERE id = ? AND user_id = ?").run(m[1], uid);
  return { status: 204 };
});

route("GET", "/api/allies", async (req) => {
  const uid = await requireUser(req);
  return db.prepare("SELECT id, name, relationship, phone FROM trusted_allies WHERE user_id = ? ORDER BY created_at, id").all(uid);
});

route("POST", "/api/allies", async (req) => {
  const uid = await requireUser(req);
  const b = await readBody(req);
  const id = str(b.id, "Id", { max: 60 });
  if (db.prepare("SELECT 1 FROM trusted_allies WHERE id = ?").get(id)) throw new HttpError(409, "Ally already exists.");
  db.prepare("INSERT INTO trusted_allies (id, user_id, name, relationship, phone) VALUES (?,?,?,?,?)")
    .run(id, uid, str(b.name, "Name", { max: 120 }), str(b.relationship, "Relationship", { max: 60 }), str(b.phone, "Phone", { max: 30 }));
  return { status: 201, body: { id } };
});

route("DELETE", "/api/allies/([\\w-]+)", async (req, m) => {
  const uid = await requireUser(req);
  db.prepare("DELETE FROM trusted_allies WHERE id = ? AND user_id = ?").run(m[1], uid);
  return { status: 204 };
});

// ---------- server ----------
const server = createServer(async (req, res) => {
  const send = (status, body) => {
    res.writeHead(status, {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    });
    res.end(status === 204 || body === undefined ? undefined : JSON.stringify(body));
  };
  try {
    const path = new URL(req.url ?? "/", "http://x").pathname.replace(/\/+$/, "") || "/";
    for (const r of routes) {
      const m = r.re.exec(path);
      if (m && r.method === req.method) {
        const out = await r.handler(req, m);
        return out && typeof out === "object" && typeof out.status === "number" ? send(out.status, out.body) : send(200, out);
      }
    }
    send(404, { error: "Not found." });
  } catch (e) {
    if (e instanceof HttpError) return send(e.status, { error: e.message });
    console.error(e);
    send(500, { error: "Something went wrong on the server." });
  }
});

server.listen(PORT, () => console.log(`e.sos API listening on http://localhost:${PORT} (Firebase project: ${PROJECT_ID ?? "not set"})`));
