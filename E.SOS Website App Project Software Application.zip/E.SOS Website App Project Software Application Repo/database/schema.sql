-- e.sos relational schema (SQLite). Run with: npm run db:init
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id             TEXT PRIMARY KEY,                       -- Firebase UID (same on web and mobile)
  full_name      TEXT,
  username       TEXT    NOT NULL,
  email          TEXT    NOT NULL UNIQUE COLLATE NOCASE,
  phone          TEXT,
  province       TEXT,
  password_hash  TEXT,                                   -- PBKDF2-SHA256, never plaintext; NULL for Google SSO users
  decoy_hash     TEXT,                                   -- PBKDF2-SHA256 hash of the optional decoy password
  auth_provider  TEXT    NOT NULL DEFAULT 'password' CHECK (auth_provider IN ('password', 'google')),
  role           TEXT    NOT NULL DEFAULT 'member'   CHECK (role IN ('member', 'volunteer', 'admin')),
  email_verified INTEGER NOT NULL DEFAULT 0 CHECK (email_verified IN (0, 1)),
  created_at     TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
  last_login_at  TEXT
);

CREATE TABLE IF NOT EXISTS shelters (
  id        TEXT PRIMARY KEY,
  name      TEXT NOT NULL,
  location  TEXT NOT NULL,
  province  TEXT NOT NULL,
  phone     TEXT NOT NULL,
  capacity  TEXT NOT NULL CHECK (capacity IN ('Available', 'Limited', 'Full'))
);

CREATE TABLE IF NOT EXISTS shelter_services (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  shelter_id TEXT NOT NULL REFERENCES shelters(id) ON DELETE CASCADE,
  service    TEXT NOT NULL,
  UNIQUE (shelter_id, service)
);

CREATE TABLE IF NOT EXISTS helplines (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  name      TEXT NOT NULL UNIQUE,
  phone     TEXT NOT NULL,
  dial      TEXT NOT NULL,
  category  TEXT NOT NULL,
  details   TEXT NOT NULL,
  is_top    INTEGER NOT NULL DEFAULT 0 CHECK (is_top IN (0, 1))
);

CREATE TABLE IF NOT EXISTS evidence_reports (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title           TEXT NOT NULL,
  incident_type   TEXT NOT NULL,
  incident_date   TEXT NOT NULL,                          -- YYYY-MM-DD
  incident_time   TEXT NOT NULL,                          -- HH:MM
  description     TEXT NOT NULL,
  confidentiality TEXT NOT NULL DEFAULT 'private',
  created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE IF NOT EXISTS report_attachments (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  report_id TEXT NOT NULL REFERENCES evidence_reports(id) ON DELETE CASCADE,
  file_name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS trusted_allies (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name         TEXT NOT NULL,
  relationship TEXT NOT NULL,
  phone        TEXT NOT NULL,
  created_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE IF NOT EXISTS donations (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  reference   TEXT NOT NULL UNIQUE,
  donor_name  TEXT,
  donor_email TEXT NOT NULL,
  amount_zar  REAL NOT NULL CHECK (amount_zar > 0),
  status      TEXT NOT NULL DEFAULT 'pledged' CHECK (status IN ('pledged', 'received', 'cancelled')),
  created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE IF NOT EXISTS volunteer_applications (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name    TEXT NOT NULL,
  email        TEXT NOT NULL,
  phone        TEXT,
  role         TEXT NOT NULL,
  availability TEXT NOT NULL,                             -- comma-separated list
  motivation   TEXT NOT NULL,
  status       TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'screening', 'accepted', 'declined')),
  created_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_reports_user ON evidence_reports(user_id);
CREATE INDEX IF NOT EXISTS idx_allies_user ON trusted_allies(user_id);
CREATE INDEX IF NOT EXISTS idx_services_shelter ON shelter_services(shelter_id);
CREATE INDEX IF NOT EXISTS idx_attachments_report ON report_attachments(report_id);

-- Readable view for browsing users in VS Code (the only secrets are one-way hashes)
CREATE VIEW IF NOT EXISTS v_users AS
SELECT id, full_name, username, email, phone, province, auth_provider, role, email_verified,
       password_hash, decoy_hash, created_at, last_login_at
FROM users;
