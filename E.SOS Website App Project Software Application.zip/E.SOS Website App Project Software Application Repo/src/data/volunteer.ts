export const VOLUNTEER_ROLES = [
  { name: "Crisis helpline operator", desc: "Take calls and make emergency referrals after e.sos training." },
  { name: "Counseling and social support", desc: "Assist social workers during intake and support groups." },
  { name: "Community awareness and events", desc: "Coordinate workshops, outreach drives and local activism." },
  { name: "Legal aid helper", desc: "Help survivors complete protection-order paperwork and book appointments." },
  { name: "Admin and clerical support", desc: "Keep the office, records and donor communication running." },
  { name: "Media, design and marketing", desc: "Create content and campaigns that raise awareness." },
];

export const AVAILABILITY = ["Weekdays", "Weekends", "Mornings", "Afternoons"];

export const DONATION_AMOUNTS = [50, 150, 250, 500, 1000];

export function impactFor(amount: number): string {
  if (amount <= 0) return "Every contribution helps sustain our support services.";
  if (amount <= 50) return "Feeds a survivor in our shelter for a full day.";
  if (amount <= 150) return "Pays for a counseling session with a qualified counselor.";
  if (amount <= 300) return "Covers transport and intake for an emergency shelter placement.";
  if (amount <= 600) return "Supports a legal consultant helping a survivor secure a protection order.";
  if (amount <= 1200) return "Covers a month of intensive therapeutic counseling for a client.";
  return "Provides shelter, legal guidance and counseling to a survivor and her children.";
}
