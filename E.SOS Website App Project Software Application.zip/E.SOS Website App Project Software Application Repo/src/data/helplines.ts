import type { Helpline } from "../types";

export const HELPLINES: Helpline[] = [
  { name: "GBV Command Centre", phone: "0800 428 428", dial: "0800428428", category: "Counseling and abuse support", details: "Toll-free, 24/7. Speak to a trauma counselor." },
  { name: "SAPS emergency", phone: "10111", dial: "10111", category: "Police", details: "Nationwide police emergency line. Call if you are in immediate danger." },
  { name: "Family Violence, Child Protection and Sexual Offences Unit", phone: "08600 10111", dial: "08600 10111", category: "Police", details: "Open protection filings and report domestic assault." },
  { name: "Childline South Africa", phone: "0800 055 555", dial: "0800055555", category: "Children and youth", details: "Toll-free, 24 hours, in all official languages." },
  { name: "TEARS Foundation", phone: "*134*7355#", dial: "*134*7355%23", category: "Self-help (USSD)", details: "Dial from your phone to find the nearest emergency clinic." },
  { name: "LifeLine SA", phone: "0861 322 322", dial: "0861322322", category: "Crisis and trauma care", details: "Emotional support and referrals." },
  { name: "Legal Aid South Africa", phone: "0800 110 110", dial: "0800110110", category: "Legal help", details: "Free legal advice, including protection orders." },
  { name: "SA Human Rights Commission", phone: "011 877 3600", dial: "0118773600", category: "Legal help", details: "Report human-rights violations." },
];

export const TOP_HELPLINES = ["GBV Command Centre", "SAPS emergency", "Childline South Africa"];
