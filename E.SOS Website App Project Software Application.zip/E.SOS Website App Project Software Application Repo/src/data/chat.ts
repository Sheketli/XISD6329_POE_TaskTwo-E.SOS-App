export const CHAT_SHORTCUTS = [
  {
    label: "Calm my breathing",
    response:
      "Let's do a grounding exercise together. You are safe in this moment.\n\n1. Sit comfortably and touch something solid, like a table or your clothing.\n2. Breathe in slowly for 4 seconds.\n3. Hold for 4 seconds.\n4. Breathe out slowly for 6 seconds.\n5. Repeat 3 times.\n\nWhen you're ready, tell me what you need.",
  },
  {
    label: "Check my digital safety",
    response:
      "Here is a quick digital safety check:\n\n• Change email and bank passwords from a device the abuser cannot access, such as a friend's phone or a library computer.\n• In Google Maps, open Profile → Location sharing and review who can see you.\n• Turn off shared family access in Find My / Find My Device.\n• Clear your browser history after using sensitive pages.\n• If your phone behaves strangely, an unknown app may be tracking it. Consider a factory reset or ask a trusted person for help.",
  },
  {
    label: "Plan to leave safely",
    response:
      "If you're planning to leave, gather these in a hidden, safe place (a friend's home or a workplace locker):\n\n1. Documents: ID, children's birth certificates, marriage certificate, clinic cards.\n2. Money: some cash, a bank card in your own name.\n3. Medication and a change of clothes.\n4. Evidence: print or export your incident log from the Evidence vault.\n\nCall the GBV Command Centre on 0800 428 428 to plan with a trained counselor.",
  },
];

export function botReply(input: string): string {
  const t = input.toLowerCase();
  if (/(hit|hurt|danger|panic|kill|weapon|right now)/.test(t))
    return "If you are in danger right now, call 10111 or the GBV Command Centre on 0800 428 428. You can also open the Panic button page. Your safety comes first.";
  if (/(shelter|safe ?house|sleep|stay|place to)/.test(t))
    return "We list shelters in Gauteng, Western Cape and KwaZulu-Natal on the Find a shelter page. Call a shelter directly to ask about space; they can arrange safe transport.";
  if (/(police|court|legal|law|protection order)/.test(t))
    return "You can apply for a protection order at your nearest magistrate's court. It is free. Legal Aid SA (0800 110 110) can help, and a social worker can accompany you.";
  if (/(fear|cry|afraid|scared|anxious)/.test(t))
    return "What you're feeling is valid, and you are not alone. Try the \"Calm my breathing\" shortcut, and tell me what would help most right now.";
  return "Thank you for telling me. I'm an automated assistant and can share information on safety planning, legal options and shelters. For a real person, call the GBV Command Centre on 0800 428 428, free, 24/7. What would you like to explore first?";
}
