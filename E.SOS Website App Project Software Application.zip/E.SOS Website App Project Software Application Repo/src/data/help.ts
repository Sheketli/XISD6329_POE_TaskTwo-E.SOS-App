export interface Guide {
  id: string;
  title: string;
  summary: string;
  to: string;
  needsLogin?: boolean;
  steps: string[];
}

export const GUIDES: Guide[] = [
  {
    id: "account",
    title: "Create an account and log in",
    summary: "Sign in with Google so your settings, allies and reports follow you.",
    to: "/login",
    steps: [
      "Open Log in from the top menu.",
      "Choose Continue with Google and pick your Google account.",
      "You stay signed in on this device until you log out. The same Google account works on any device.",
      "Using a shared device? Log out afterwards from the menu.",
    ],
  },
  {
    id: "shelters",
    title: "Find a shelter",
    summary: "Search safe houses by province and the services you need.",
    to: "/shelters",
    steps: [
      "Open Get help, then Find a shelter.",
      "Filter by province and tick the services you need, such as counselling or children's support.",
      "Tap a shelter's phone number to call. Always call first to check space and arrange safe arrival.",
    ],
  },
  {
    id: "helplines",
    title: "Call a helpline",
    summary: "Free, confidential numbers you can tap to dial.",
    to: "/helplines",
    steps: [
      "Open Get help, then Helplines.",
      "Tap any number to call from your phone. The red bar at the top of every page always shows Police 10111 and the GBV Command Centre 0800 428 428.",
    ],
  },
  {
    id: "chat",
    title: "Talk to a counselor",
    summary: "Private guidance and help building a safety plan.",
    to: "/chat",
    steps: [
      "Open Get help, then Talk to a counselor.",
      "Type your message or pick a suggested topic.",
      "In an emergency, call 10111 instead. This chat is guidance, not an emergency service.",
    ],
  },
  {
    id: "panic",
    title: "Use the panic button",
    summary: "Quick alert tools for when you feel unsafe.",
    to: "/panic",
    steps: [
      "Open My safety, then Panic button.",
      "Use the call buttons to reach emergency services immediately.",
      "Use Send alert SMS to message your trusted allies. Your phone opens a ready-written message and nothing is sent until you press send.",
    ],
  },
  {
    id: "allies",
    title: "Add trusted allies",
    summary: "Save people who can help you quickly.",
    to: "/allies",
    steps: [
      "Open My safety, then Trusted allies.",
      "Enter a name, relationship and phone number, then press Add.",
      "Signed-in users have allies saved to their account. Use the remove button to delete someone.",
    ],
  },
  {
    id: "vault",
    title: "Record an incident in the Evidence vault",
    summary: "Keep a private, dated record you can use later.",
    to: "/vault",
    needsLogin: true,
    steps: [
      "Log in, then open My safety, then Evidence vault.",
      "Enter a title, type, date, time and a clear description of what happened.",
      "Save the report. You can view, export or delete it at any time.",
      "Export a copy regularly and keep it somewhere safe.",
    ],
  },
  {
    id: "settings",
    title: "Change your settings",
    summary: "Update your details, password and privacy options.",
    to: "/settings",
    needsLogin: true,
    steps: [
      "Log in and choose Settings in the top bar.",
      "Update your username and personal details, and save.",
      "Set a decoy password if offered, and change your password where your sign-in method allows it.",
      "Delete account permanently removes your profile, reports and allies. This cannot be undone.",
    ],
  },
  {
    id: "donate",
    title: "Donate or volunteer",
    summary: "Support shelters and counselling with money or time.",
    to: "/donate",
    steps: [
      "Open Get involved, then Donate. Choose an amount and note your payment reference.",
      "Make an EFT using the bank details shown and quote that reference.",
      "To volunteer, open Volunteer, choose a role and availability, and submit the application. We will contact you.",
    ],
  },
];

export interface Faq {
  q: string;
  a: string;
}

export const FAQS: { group: string; items: Faq[] }[] = [
  {
    group: "Safety & privacy",
    items: [
      { q: "How do I leave the site quickly?", a: "Press the Quick exit button shown on every page. It immediately takes you to a neutral website." },
      { q: "Will anyone see that I used this site?", a: "Your browser history may show it. Use a private or incognito window, clear your history afterwards, and use Quick exit if someone walks in." },
      { q: "Is my information safe?", a: "Sign-in is handled by Google through Firebase. Any password hashes are one-way encrypted, and stored passwords are never shown in plain text." },
      { q: "What is a decoy password?", a: "A second password that, if entered at login, instantly sends the browser to Google instead of opening your account. Set it in Settings." },
    ],
  },
  {
    group: "Account",
    items: [
      { q: "Which sign-in methods are supported?", a: "Google sign-in. Use the same Google account on the website and the mobile app." },
      { q: "I can't sign in. What should I do?", a: "Check your internet connection and that pop-ups are allowed for this site, then try again. If it still fails, contact our office." },
      { q: "How do I delete my data?", a: "Go to Settings and choose Delete account. Your profile, reports and allies are removed from our database and this device." },
    ],
  },
  {
    group: "Getting help",
    items: [
      { q: "Are the helplines free?", a: "Most are free and confidential. The GBV Command Centre 0800 428 428 is free and open 24/7." },
      { q: "Can I use the shelter finder without an account?", a: "Yes. Shelters, helplines, the panic button and the counselor chat do not need an account." },
      { q: "Is the counselor chat a replacement for emergency services?", a: "No. If you are in immediate danger, call Police 10111 or the GBV Command Centre." },
    ],
  },
];
