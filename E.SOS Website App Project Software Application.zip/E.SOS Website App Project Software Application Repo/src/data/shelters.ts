import type { Shelter } from "../types";

export const SHELTERS: Shelter[] = [
  { id: "s1", name: "Frida Hartley Shelter", location: "Yeoville, Johannesburg", province: "Gauteng", phone: "011 648 6005", services: ["Counseling", "Skills development", "Employment support", "Children welcome"], capacity: "Available" },
  { id: "s2", name: "Nisaa Institute for Women's Development", location: "Lenasia, Johannesburg", province: "Gauteng", phone: "011 854 6372", services: ["Legal advocacy", "Clinical therapy", "Immediate admission", "Children welcome"], capacity: "Limited" },
  { id: "s3", name: "POWA Crisis Safe House", location: "Berea, Johannesburg", province: "Gauteng", phone: "011 642 4345", services: ["24/7 security", "Psychosocial support", "Legal aid", "Emergency transport"], capacity: "Available" },
  { id: "s4", name: "Sisters Incorporated", location: "Kenilworth, Cape Town", province: "Western Cape", phone: "021 797 4190", services: ["Pregnancy support", "Infant care", "Individual therapy", "Long-term stay"], capacity: "Limited" },
  { id: "s5", name: "Saartjie Baartman Centre", location: "Manenberg, Cape Town", province: "Western Cape", phone: "021 633 5287", services: ["Child counseling", "Legal advice clinic", "Residential shelter", "Medical care"], capacity: "Full" },
  { id: "s6", name: "The Safe House", location: "Stellenbosch", province: "Western Cape", phone: "0861 322 322", services: ["Security", "Trauma counseling", "Safe haven"], capacity: "Available" },
  { id: "s7", name: "Open Door Crisis Care Centre", location: "Pinetown, Durban", province: "KwaZulu-Natal", phone: "031 709 2637", services: ["Trauma centre", "Social work", "Support groups", "Court accompaniment"], capacity: "Available" },
];
