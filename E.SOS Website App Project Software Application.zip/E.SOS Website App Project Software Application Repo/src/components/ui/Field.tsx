import { useId, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes } from "react";
import { cn } from "../../lib/utils";

interface FieldProps {
  label: string;
  hint?: string;
  error?: string;
  optional?: boolean;
}

const control =
  "w-full rounded-xl border bg-white px-4 py-3 text-base text-ink placeholder:text-muted/70 transition-colors focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-200";

function Wrapper({ id, label, hint, error, optional, children }: FieldProps & { id: string; children: ReactNode }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-sm font-semibold text-brand-900">
        {label}
        {optional && <span className="ml-1 font-normal text-muted">(optional)</span>}
      </label>
      {children}
      {hint && !error && <p id={`${id}-hint`} className="mt-1.5 text-sm text-muted">{hint}</p>}
      {error && <p id={`${id}-err`} role="alert" className="mt-1.5 text-sm font-medium text-danger-700">{error}</p>}
    </div>
  );
}

const aria = (id: string, p: FieldProps) => ({
  "aria-invalid": p.error ? true : undefined,
  "aria-describedby": p.error ? `${id}-err` : p.hint ? `${id}-hint` : undefined,
});

export function Input({ label, hint, error, optional, className, ...rest }: FieldProps & InputHTMLAttributes<HTMLInputElement>) {
  const id = useId();
  return (
    <Wrapper id={id} {...{ label, hint, error, optional }}>
      <input id={id} className={cn(control, error ? "border-danger-600" : "border-line", className)} {...aria(id, { label, hint, error })} {...rest} />
    </Wrapper>
  );
}

export function Textarea({ label, hint, error, optional, className, ...rest }: FieldProps & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const id = useId();
  return (
    <Wrapper id={id} {...{ label, hint, error, optional }}>
      <textarea id={id} rows={4} className={cn(control, error ? "border-danger-600" : "border-line", className)} {...aria(id, { label, hint, error })} {...rest} />
    </Wrapper>
  );
}

export function Select({ label, hint, error, optional, className, children, ...rest }: FieldProps & SelectHTMLAttributes<HTMLSelectElement>) {
  const id = useId();
  return (
    <Wrapper id={id} {...{ label, hint, error, optional }}>
      <select id={id} className={cn(control, error ? "border-danger-600" : "border-line", className)} {...aria(id, { label, hint, error })} {...rest}>
        {children}
      </select>
    </Wrapper>
  );
}
