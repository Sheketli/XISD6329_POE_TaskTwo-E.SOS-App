import type { ButtonHTMLAttributes, AnchorHTMLAttributes, ReactNode } from "react";
import { Link, type LinkProps } from "react-router-dom";
import { cn } from "../../lib/utils";

type Variant = "primary" | "secondary" | "danger" | "ghost" | "accent";
type Size = "md" | "lg" | "sm";

const base =
  "inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-50";
const variants: Record<Variant, string> = {
  primary: "bg-brand-700 text-white hover:bg-brand-800",
  accent: "bg-accent-600 text-white hover:bg-accent-500",
  secondary: "border border-line bg-white text-brand-800 hover:bg-brand-50",
  danger: "bg-danger-600 text-white hover:bg-danger-700",
  ghost: "text-brand-700 hover:bg-brand-50",
};
const sizes: Record<Size, string> = {
  sm: "min-h-9 px-3 text-sm",
  md: "min-h-11 px-5 text-base",
  lg: "min-h-14 px-7 text-lg",
};

interface Common {
  variant?: Variant;
  size?: Size;
  className?: string;
  children?: ReactNode;
}

const classes = ({ variant = "primary", size = "md", className }: Common) =>
  cn(base, variants[variant], sizes[size], className);

export function Button({ variant, size, className, ...rest }: Common & ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button type="button" className={classes({ variant, size, className })} {...rest} />;
}

export function ButtonLink({ variant, size, className, ...rest }: Common & LinkProps) {
  return <Link className={classes({ variant, size, className })} {...rest} />;
}

export function ButtonAnchor({ variant, size, className, ...rest }: Common & AnchorHTMLAttributes<HTMLAnchorElement>) {
  return <a className={classes({ variant, size, className })} {...rest} />;
}
