import type { ReactNode } from "react";
import { AlertTriangle, CheckCircle2, Info } from "lucide-react";
import { cn } from "../../lib/utils";

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return <div className={cn("rounded-2xl border border-line bg-white p-6 shadow-sm", className)}>{children}</div>;
}

type Tone = "info" | "success" | "danger" | "warning";
const tones: Record<Tone, { box: string; icon: ReactNode }> = {
  info: { box: "border-brand-200 bg-brand-50 text-brand-900", icon: <Info className="h-5 w-5 shrink-0" aria-hidden /> },
  success: { box: "border-ok-700/30 bg-ok-50 text-ok-700", icon: <CheckCircle2 className="h-5 w-5 shrink-0" aria-hidden /> },
  danger: { box: "border-danger-600/30 bg-danger-50 text-danger-700", icon: <AlertTriangle className="h-5 w-5 shrink-0" aria-hidden /> },
  warning: { box: "border-accent-500/40 bg-accent-50 text-ink", icon: <AlertTriangle className="h-5 w-5 shrink-0 text-accent-600" aria-hidden /> },
};

export function Alert({ tone = "info", children, className }: { tone?: Tone; children: ReactNode; className?: string }) {
  return (
    <div role={tone === "danger" ? "alert" : "status"} className={cn("flex gap-3 rounded-xl border p-4 text-sm", tones[tone].box, className)}>
      {tones[tone].icon}
      <div>{children}</div>
    </div>
  );
}

export function Badge({ tone = "neutral", children }: { tone?: "neutral" | "ok" | "warn" | "danger"; children: ReactNode }) {
  const map = {
    neutral: "bg-brand-100 text-brand-800",
    ok: "bg-ok-50 text-ok-700",
    warn: "bg-accent-50 text-accent-600",
    danger: "bg-danger-50 text-danger-700",
  };
  return <span className={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold", map[tone])}>{children}</span>;
}

export function PageHeader({ title, intro, icon }: { title: string; intro?: string; icon?: ReactNode }) {
  return (
    <header className="border-b border-line bg-white">
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 sm:py-14">
        {icon && <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-brand-100 text-brand-700">{icon}</div>}
        <h1 className="text-3xl sm:text-4xl">{title}</h1>
        {intro && <p className="mt-3 max-w-2xl text-lg text-muted">{intro}</p>}
      </div>
    </header>
  );
}

export function Container({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("mx-auto max-w-6xl px-4 py-10 sm:px-6", className)}>{children}</div>;
}

export function EmptyState({ title, text, action }: { title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="rounded-2xl border border-dashed border-line bg-white p-8 text-center">
      <p className="font-semibold text-brand-900">{title}</p>
      {text && <p className="mt-1 text-sm text-muted">{text}</p>}
      {action && <div className="mt-4 flex justify-center">{action}</div>}
    </div>
  );
}
