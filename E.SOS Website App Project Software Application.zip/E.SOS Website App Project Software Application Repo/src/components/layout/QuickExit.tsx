import { useEffect, useRef } from "react";
import { LogOut } from "lucide-react";

export function quickExit() {
  window.open("https://www.google.com", "_blank", "noopener");
  window.location.replace("https://www.weather.com");
}

export function QuickExit() {
  const last = useRef(0);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      const now = Date.now();
      if (now - last.current < 800) quickExit();
      last.current = now;
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <button
      type="button"
      onClick={quickExit}
      title="Leave this site immediately (or press Esc twice)"
      className="fixed bottom-4 right-4 z-50 inline-flex min-h-12 items-center gap-2 rounded-full bg-danger-600 px-5 font-bold text-white shadow-lg ring-4 ring-white hover:bg-danger-700"
    >
      <LogOut className="h-5 w-5" aria-hidden />
      Quick exit
    </button>
  );
}

