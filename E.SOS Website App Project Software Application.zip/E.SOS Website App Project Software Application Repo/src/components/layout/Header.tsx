import { useEffect, useRef, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { ChevronDown, LogOut, Menu, Settings, Phone, ShieldCheck, UserRound, X } from "lucide-react";
import { NAV_GROUPS } from "../../config/site";
import { useAuth } from "../../context/AuthContext";
import { cn } from "../../lib/utils";
import { ButtonLink } from "../ui/Button";

export function Logo({ light }: { light?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-700 text-lg font-extrabold text-white">e</span>
      <span className={cn("text-xl font-extrabold tracking-tight", light ? "text-white" : "text-brand-900")}>e.sos</span>
    </span>
  );
}

function EmergencyBar() {
  return (
    <div className="bg-danger-700 text-sm text-white">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-center gap-x-6 gap-y-1 px-4 py-2 text-center sm:px-6">
        <span className="font-semibold">In danger now?</span>
        <a href="tel:10111" className="inline-flex items-center gap-1.5 font-bold underline underline-offset-2">
          <Phone className="h-4 w-4" aria-hidden /> Police 10111
        </a>
        <a href="tel:0800428428" className="inline-flex items-center gap-1.5 font-bold underline underline-offset-2">
          <Phone className="h-4 w-4" aria-hidden /> GBV Command Centre 0800 428 428 (free, 24/7)
        </a>
      </div>
    </div>
  );
}

function Dropdown({ group }: { group: (typeof NAV_GROUPS)[number] }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const { pathname } = useLocation();

  useEffect(() => {
    setOpen(false);
  }, [pathname]);
  useEffect(() => {
    const close = (e: MouseEvent) => !ref.current?.contains(e.target as Node) && setOpen(false);
    const esc = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("mousedown", close);
      document.removeEventListener("keydown", esc);
    };
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        aria-expanded={open}
        aria-haspopup="true"
        onClick={() => setOpen((o) => !o)}
        className="inline-flex min-h-11 items-center gap-1 rounded-lg px-3 font-semibold text-brand-900 hover:bg-brand-50"
      >
        {group.label}
        <ChevronDown className={cn("h-4 w-4 transition-transform", open && "rotate-180")} aria-hidden />
      </button>
      {open && (
        <div className="absolute left-0 top-full z-40 mt-1 w-72 rounded-xl border border-line bg-white p-2 shadow-xl">
          {group.items.map((item) => (
            <Link key={item.to} to={item.to} className="block rounded-lg px-3 py-2.5 hover:bg-brand-50">
              <span className="block font-semibold text-brand-900">{item.label}</span>
              {item.description && <span className="block text-sm text-muted">{item.description}</span>}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

export function Header() {
  const [menu, setMenu] = useState(false);
  const { user, logout } = useAuth();
  const { pathname } = useLocation();

  useEffect(() => {
    setMenu(false);
  }, [pathname]);
  useEffect(() => {
    document.body.style.overflow = menu ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menu]);

  return (
    <>
      <EmergencyBar />
      <header className="sticky top-0 z-30 border-b border-line bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <Link to="/" aria-label="e.sos home">
            <Logo />
          </Link>

          <nav aria-label="Main" className="hidden items-center gap-1 lg:flex">
            {NAV_GROUPS.map((g) => (
              <Dropdown key={g.label} group={g} />
            ))}
          </nav>

          <div className="hidden items-center gap-2 lg:flex">
            {user ? (
              <>
                <ButtonLink to="/dashboard" variant="secondary" size="sm">
                  <UserRound className="h-4 w-4" aria-hidden /> {user.username}
                </ButtonLink>
                <ButtonLink to="/settings" variant="ghost" size="sm" aria-label="Settings">
                  <Settings className="h-4 w-4" aria-hidden /> Settings
                </ButtonLink>
                <button type="button" onClick={() => void logout()} className="inline-flex min-h-9 items-center gap-1.5 rounded-lg px-3 text-sm font-semibold text-muted hover:bg-brand-50">
                  <LogOut className="h-4 w-4" aria-hidden /> Log out
                </button>
              </>
            ) : (
              <ButtonLink to="/login" size="sm">Log in</ButtonLink>
            )}
          </div>

          <button
            type="button"
            className="inline-flex h-11 w-11 items-center justify-center rounded-lg text-brand-900 hover:bg-brand-50 lg:hidden"
            aria-label={menu ? "Close menu" : "Open menu"}
            aria-expanded={menu}
            onClick={() => setMenu((m) => !m)}
          >
            {menu ? <X /> : <Menu />}
          </button>
        </div>
      </header>

      {menu && (
        <div className="fixed inset-0 top-[104px] z-20 overflow-y-auto bg-white px-4 pb-28 pt-4 lg:hidden">
          <nav aria-label="Mobile">
            {NAV_GROUPS.map((g) => (
              <div key={g.label} className="mb-6">
                <p className="mb-2 text-xs font-bold uppercase tracking-wider text-muted">{g.label}</p>
                {g.items.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    className={({ isActive }) =>
                      cn("block rounded-xl px-3 py-3 text-lg font-semibold", isActive ? "bg-brand-100 text-brand-800" : "text-brand-900 hover:bg-brand-50")
                    }
                  >
                    {item.label}
                  </NavLink>
                ))}
              </div>
            ))}
            <div className="border-t border-line pt-4">
              {user ? (
                <div className="space-y-2">
                  <ButtonLink to="/dashboard" variant="secondary" className="w-full">
                    <ShieldCheck className="h-5 w-5" aria-hidden /> My dashboard
                  </ButtonLink>
                  <ButtonLink to="/settings" variant="secondary" className="w-full">
                    <Settings className="h-5 w-5" aria-hidden /> Settings
                  </ButtonLink>
                  <button type="button" onClick={() => void logout()} className="min-h-11 w-full rounded-xl text-center font-semibold text-muted">
                    Log out
                  </button>
                </div>
              ) : (
                <ButtonLink to="/login" className="w-full">Log in or create account</ButtonLink>
              )}
            </div>
          </nav>
        </div>
      )}
    </>
  );
}
