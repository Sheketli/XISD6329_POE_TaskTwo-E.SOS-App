import { Link } from "react-router-dom";
import { NAV_GROUPS, SITE } from "../../config/site";
import { Logo } from "./Header";

export function Footer() {
  return (
    <footer className="mt-16 bg-brand-900 text-brand-100">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-4">
        <div className="md:col-span-1">
          <Logo light />
          <p className="mt-3 text-sm text-brand-200">{SITE.tagline}</p>
          <p className="mt-2 text-sm text-brand-200">{SITE.npo}</p>
        </div>
        {NAV_GROUPS.map((g) => (
          <div key={g.label}>
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-white">{g.label}</h2>
            <ul className="space-y-2 text-sm">
              {g.items.map((i) => (
                <li key={i.to}>
                  <Link to={i.to} className="hover:text-white hover:underline">{i.label}</Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-5 text-sm text-brand-200 sm:flex-row sm:justify-between sm:px-6">
          <p>© {new Date().getFullYear()} e.sos. All rights reserved.</p>
          <p>
            Office: <a href={`tel:${SITE.phone.replace(/\s/g, "")}`} className="underline">{SITE.phone}</a> · {SITE.city}
          </p>
        </div>
      </div>
    </footer>
  );
}
