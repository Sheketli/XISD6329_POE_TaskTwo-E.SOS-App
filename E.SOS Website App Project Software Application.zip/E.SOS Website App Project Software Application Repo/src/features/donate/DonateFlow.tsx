import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { DONATION_AMOUNTS, impactFor } from "../../data/volunteer";
import { SITE } from "../../config/site";
import { Alert, Card } from "../../components/ui/Display";
import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Field";
import { cn } from "../../lib/utils";
import { api } from "../../lib/api";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function CopyRow({ label, value }: { label: string; value: string }) {
  const [done, setDone] = useState(false);
  return (
    <div className="flex items-center justify-between gap-3 border-b border-line py-3 last:border-0">
      <div>
        <p className="text-xs text-muted">{label}</p>
        <p className="font-semibold text-brand-900">{value}</p>
      </div>
      <button
        type="button"
        aria-label={`Copy ${label}`}
        className="flex h-9 w-9 items-center justify-center rounded-lg text-brand-700 hover:bg-brand-50"
        onClick={() => void navigator.clipboard?.writeText(value).then(() => { setDone(true); window.setTimeout(() => setDone(false), 1500); })}
      >
        {done ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
      </button>
    </div>
  );
}

export function DonateFlow() {
  const [amount, setAmount] = useState("250");
  const [custom, setCustom] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [errors, setErrors] = useState<{ amount?: string; email?: string }>({});
  const [ref, setRef] = useState<string | null>(null);
  const value = Number(amount) || 0;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: typeof errors = {};
    if (value <= 0) next.amount = "Choose or enter an amount above R0.";
    if (!EMAIL.test(email.trim())) next.email = "Enter your email so we can send a tax receipt.";
    setErrors(next);
    if (Object.keys(next).length) return;
    const reference = `PW-${Math.floor(100000 + Math.random() * 900000)}`;
    setRef(reference);
    api("/donations", { method: "POST", body: { reference, name: name.trim(), email: email.trim(), amount: value } }).catch(() => undefined);
  };

  if (ref) {
    return (
      <div className="mx-auto max-w-2xl space-y-6">
        <Alert tone="success"><strong>Thank you{name ? `, ${name}` : ""}!</strong> Your pledge of R{value} is recorded. To complete it, make an EFT using the details below.</Alert>
        <Card>
          <h2 className="text-xl">Complete your donation by EFT</h2>
          <div className="mt-3">
            <CopyRow label="Bank" value={SITE.bank.bank} />
            <CopyRow label="Account name" value={SITE.bank.accountName} />
            <CopyRow label="Account number" value={SITE.bank.accountNumber} />
            <CopyRow label="Branch code" value={SITE.bank.branchCode} />
            <CopyRow label="Payment reference" value={ref} />
            <CopyRow label="Amount" value={`R${value}`} />
          </div>
          <p className="mt-4 text-sm text-muted">Once we receive your payment we'll email a Section 18A tax receipt to {email}.</p>
          <Button variant="secondary" className="mt-5" onClick={() => setRef(null)}>Make another pledge</Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="mx-auto grid max-w-5xl gap-8 lg:grid-cols-[1fr_340px]">
      <Card>
        <form onSubmit={submit} className="space-y-8" noValidate>
          <fieldset>
            <legend className="mb-3 text-lg font-bold text-brand-900">1. Choose an amount (ZAR)</legend>
            <div className="flex flex-wrap gap-2">
              {DONATION_AMOUNTS.map((a) => (
                <button key={a} type="button" aria-pressed={amount === String(a) && !custom} onClick={() => { setAmount(String(a)); setCustom(""); }}
                  className={cn("min-h-12 min-w-[84px] flex-1 rounded-xl border-2 px-4 font-bold", amount === String(a) && !custom ? "border-brand-700 bg-brand-700 text-white" : "border-line bg-white text-brand-900 hover:border-brand-300")}>
                  R{a}
                </button>
              ))}
            </div>
            <div className="mt-4">
              <Input label="Or enter another amount" inputMode="numeric" value={custom} placeholder="e.g. 400" error={errors.amount}
                onChange={(e) => { const d = e.target.value.replace(/\D/g, ""); setCustom(d); setAmount(d); }} />
            </div>
            <p className="mt-4 rounded-xl bg-accent-50 p-4 text-sm"><strong>Your impact:</strong> {impactFor(value)}</p>
          </fieldset>

          <fieldset className="space-y-4">
            <legend className="mb-3 text-lg font-bold text-brand-900">2. Your details</legend>
            <Input label="Full name" optional value={name} onChange={(e) => setName(e.target.value)} hint="Leave blank to donate anonymously." autoComplete="name" />
            <Input label="Email address" type="email" value={email} onChange={(e) => setEmail(e.target.value)} error={errors.email} hint="Needed for your Section 18A tax receipt." autoComplete="email" />
          </fieldset>

          <Button type="submit" size="lg" className="w-full">Continue to payment details{value > 0 ? ` (R${value})` : ""}</Button>
        </form>
      </Card>

      <aside className="space-y-4">
        <Card>
          <h2 className="text-lg">Where your money goes</h2>
          <ul className="mt-3 space-y-3 text-sm text-muted">
            <li><strong className="text-brand-900">R50</strong> feeds a survivor in shelter for a day.</li>
            <li><strong className="text-brand-900">R250</strong> funds an emergency therapy and intake session.</li>
            <li><strong className="text-brand-900">R1000</strong> funds legal representation for a protection order.</li>
          </ul>
        </Card>
        <Alert>{SITE.name} is a registered NPO ({SITE.npo}). Donations are Section 18A tax-deductible.</Alert>
      </aside>
    </div>
  );
}
