import { useCallback, useEffect, useState } from "react";
import { BellRing, EyeOff, MessageSquareWarning, Phone, ShieldAlert, Volume2, VolumeX, X } from "lucide-react";
import { Link } from "react-router-dom";
import { Alert, Card } from "../../components/ui/Display";
import { Button, ButtonAnchor } from "../../components/ui/Button";
import { alertLink, useAllies } from "../allies/useAllies";
import { beep } from "../../lib/utils";

type Phase = "idle" | "countdown" | "active";
const COUNTDOWN = 5;

export function PanicConsole() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [seconds, setSeconds] = useState(COUNTDOWN);
  const [sound, setSound] = useState(true);
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const { allies } = useAllies();

  const start = () => {
    setSeconds(COUNTDOWN);
    setPhase("countdown");
    navigator.geolocation?.getCurrentPosition(
      (p) => setCoords({ lat: p.coords.latitude, lng: p.coords.longitude }),
      () => setCoords(null),
      { timeout: 8000 },
    );
  };
  const stop = useCallback(() => setPhase("idle"), []);

  useEffect(() => {
    if (phase !== "countdown") return;
    if (seconds <= 0) {
      setPhase("active");
      return;
    }
    if (sound) beep(660, 0.2);
    const t = window.setTimeout(() => setSeconds((s) => s - 1), 1000);
    return () => window.clearTimeout(t);
  }, [phase, seconds, sound]);

  useEffect(() => {
    if (phase !== "active" || !sound) return;
    const id = window.setInterval(() => beep(900, 0.5, "sawtooth"), 900);
    return () => window.clearInterval(id);
  }, [phase, sound]);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <Alert tone="warning">
        This page does <strong>not</strong> contact anyone automatically. It helps you make a loud alarm and quickly call or message the people who can help. If you are in danger, call <a className="font-bold underline" href="tel:10111">10111</a>.
      </Alert>

      <Card className="text-center">
        <div className="mb-6 flex flex-wrap justify-center gap-2">
          <Button variant="secondary" size="sm" onClick={() => setSound((s) => !s)} aria-pressed={sound}>
            {sound ? <Volume2 className="h-4 w-4" aria-hidden /> : <VolumeX className="h-4 w-4" aria-hidden />}
            {sound ? "Alarm sound on" : "Silent mode"}
          </Button>
          <Link to="/cover" className="inline-flex min-h-9 items-center gap-2 rounded-xl border border-line bg-white px-3 text-sm font-semibold text-brand-800 hover:bg-brand-50">
            <EyeOff className="h-4 w-4" aria-hidden /> Show cover page
          </Link>
        </div>

        {phase === "idle" && (
          <div className="py-6">
            <button type="button" onClick={start} className="mx-auto flex h-48 w-48 flex-col items-center justify-center gap-2 rounded-full bg-danger-600 text-2xl font-extrabold text-white shadow-xl ring-8 ring-danger-50 transition hover:bg-danger-700">
              <ShieldAlert className="h-10 w-10" aria-hidden /> Alert
            </button>
            <p className="mt-5 text-muted">Press to start a {COUNTDOWN}-second countdown. You can cancel at any time.</p>
          </div>
        )}

        {phase === "countdown" && (
          <div className="py-6" role="status" aria-live="assertive">
            <p className="text-lg font-semibold text-danger-700">Alert starts in</p>
            <p className="my-2 text-8xl font-extrabold text-danger-600">{seconds}</p>
            <Button variant="secondary" size="lg" onClick={stop}><X className="h-5 w-5" aria-hidden /> Cancel</Button>
          </div>
        )}

        {phase === "active" && (
          <div className="space-y-5 py-4">
            <p className="flex items-center justify-center gap-2 text-2xl font-extrabold text-danger-600">
              <BellRing className="h-7 w-7 animate-pulse" aria-hidden /> Alert active
            </p>
            <div className="grid gap-3 sm:grid-cols-2">
              <ButtonAnchor href="tel:10111" variant="danger" size="lg"><Phone className="h-5 w-5" aria-hidden /> Call police 10111</ButtonAnchor>
              <ButtonAnchor href="tel:0800428428" variant="primary" size="lg"><Phone className="h-5 w-5" aria-hidden /> GBV Command Centre</ButtonAnchor>
            </div>
            <div className="text-left">
              <p className="mb-2 font-semibold text-brand-900">Message your allies</p>
              {allies.length === 0 ? (
                <p className="text-sm text-muted">You haven't saved any allies yet. <Link to="/allies" className="font-semibold text-brand-700 underline">Add some</Link>.</p>
              ) : (
                <ul className="space-y-2">
                  {allies.map((a) => (
                    <li key={a.id}>
                      <ButtonAnchor href={alertLink(a.phone, coords)} variant="secondary" className="w-full justify-between">
                        <span>{a.name}</span>
                        <span className="flex items-center gap-1.5 text-sm"><MessageSquareWarning className="h-4 w-4" aria-hidden /> Open SMS</span>
                      </ButtonAnchor>
                    </li>
                  ))}
                </ul>
              )}
              <p className="mt-2 text-xs text-muted">{coords ? "Your location will be included in the message." : "Location unavailable. Allow location access to include it."}</p>
            </div>
            <Button variant="secondary" onClick={stop}>Turn off alarm</Button>
          </div>
        )}
      </Card>
    </div>
  );
}
