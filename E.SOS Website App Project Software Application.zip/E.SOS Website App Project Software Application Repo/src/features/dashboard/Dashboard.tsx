import { Link } from "react-router-dom";
import { FileLock2, Home, MessageCircleHeart, ShieldAlert, Users } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { Alert, Card } from "../../components/ui/Display";

const ACTIONS = [
  { to: "/panic", icon: ShieldAlert, title: "Panic button", text: "Start an alarm and contact help fast.", tone: "bg-danger-50 text-danger-700" },
  { to: "/shelters", icon: Home, title: "Find a shelter", text: "Call a safe house near you.", tone: "bg-brand-100 text-brand-700" },
  { to: "/chat", icon: MessageCircleHeart, title: "Talk to a counselor", text: "Private guidance and safety plans.", tone: "bg-brand-100 text-brand-700" },
  { to: "/vault", icon: FileLock2, title: "Evidence vault", text: "Review and add incident records.", tone: "bg-brand-100 text-brand-700" },
  { to: "/allies", icon: Users, title: "Trusted allies", text: "Manage your emergency contacts.", tone: "bg-brand-100 text-brand-700" },
];

export function Dashboard() {
  const { user, demoMode } = useAuth();
  if (!user) return null;
  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
      <div>
        <h2 className="mb-4 text-xl">Quick actions</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          {ACTIONS.map(({ to, icon: Icon, title, text, tone }) => (
            <Link key={to} to={to} className="flex gap-4 rounded-2xl border border-line bg-white p-5 shadow-sm transition hover:border-brand-300 hover:shadow-md">
              <span className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${tone}`}><Icon className="h-6 w-6" aria-hidden /></span>
              <span>
                <span className="block font-semibold text-brand-900">{title}</span>
                <span className="block text-sm text-muted">{text}</span>
              </span>
            </Link>
          ))}
        </div>
      </div>
      <aside className="space-y-4">
        <Card>
          <h2 className="text-lg">Your account</h2>
          <dl className="mt-3 space-y-3 text-sm">
            <div><dt className="text-muted">Name</dt><dd className="font-semibold">{user.username}</dd></div>
            <div><dt className="text-muted">Email</dt><dd className="font-semibold break-all">{user.email}</dd></div>
            <div><dt className="text-muted">Member since</dt><dd className="font-semibold">{new Date(user.createdAt).toLocaleDateString()}</dd></div>
          </dl>
        </Card>
        {demoMode && <Alert tone="warning">Demo mode: your account exists only in this browser.</Alert>}
        <Card>
          <h2 className="text-lg">Need help now?</h2>
          <p className="mt-1 text-sm text-muted">Police: <a className="font-bold text-brand-700" href="tel:10111">10111</a><br />GBV Command Centre: <a className="font-bold text-brand-700" href="tel:0800428428">0800 428 428</a></p>
        </Card>
      </aside>
    </div>
  );
}
