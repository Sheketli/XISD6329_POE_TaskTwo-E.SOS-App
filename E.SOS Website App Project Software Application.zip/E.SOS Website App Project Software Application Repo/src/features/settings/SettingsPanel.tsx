import { useState, type FormEvent, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth, type Result } from "../../context/AuthContext";
import { Alert, Badge, Card } from "../../components/ui/Display";
import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Field";
import { PasswordInput } from "../auth/AuthForm";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PROVIDER_LABEL = { password: "Email and password", google: "Google" } as const;

function Section({ title, intro, children }: { title: string; intro?: string; children: ReactNode }) {
  return (
    <Card>
      <h2 className="text-xl font-bold text-brand-900">{title}</h2>
      {intro && <p className="mt-1 text-sm text-muted">{intro}</p>}
      <div className="mt-5">{children}</div>
    </Card>
  );
}

function useAction() {
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const run = async (fn: () => Promise<Result>) => {
    setBusy(true);
    setResult(null);
    const r = await fn();
    setBusy(false);
    setResult(r);
    return r;
  };
  return { busy, result, run, setResult };
}

function Feedback({ result }: { result: Result | null }) {
  if (!result) return null;
  if (!result.ok) return <Alert tone="danger" className="mb-4">{result.error}</Alert>;
  return result.message ? <Alert tone="success" className="mb-4">{result.message}</Alert> : null;
}

function ProfileSection() {
  const { user, updateUsername } = useAuth();
  const [username, setUsername] = useState(user?.username ?? "");
  const { busy, result, run } = useAction();
  const submit = (e: FormEvent) => {
    e.preventDefault();
    void run(() => updateUsername(username));
  };
  return (
    <Section title="Personal details" intro="You don't need to use your real name.">
      <Feedback result={result} />
      <form onSubmit={submit} className="space-y-4">
        <Input label="Username" value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" />
        <Button type="submit" disabled={busy || !username.trim() || username.trim() === user?.username}>Save changes</Button>
      </form>
    </Section>
  );
}

function EmailSection() {
  const { user, changeEmail } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const { busy, result, run } = useAction();

  if (user?.provider !== "password") {
    return (
      <Section title="Email address">
        <p className="text-brand-900">{user?.email}</p>
        <p className="mt-1 text-sm text-muted">Your email is managed by your {PROVIDER_LABEL[user?.provider ?? "password"]} account.</p>
      </Section>
    );
  }

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!EMAIL.test(email.trim())) return setError("Enter a valid email address.");
    setError("");
    const r = await run(() => changeEmail(email, password));
    if (r.ok) {
      setEmail("");
      setPassword("");
    }
  };
  return (
    <Section title="Email address" intro={`Current email: ${user.email}`}>
      <Feedback result={result} />
      <form onSubmit={submit} className="space-y-4" noValidate>
        <Input label="New email address" type="email" value={email} onChange={(e) => setEmail(e.target.value)} error={error} autoComplete="email" />
        <PasswordInput label="Current password" value={password} onChange={setPassword} autoComplete="current-password" hint="We ask for this to confirm it's you." />
        <Button type="submit" disabled={busy || !email || !password}>Update email</Button>
      </form>
    </Section>
  );
}

function PasswordSection() {
  const { user, changePassword } = useAuth();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const { busy, result, run } = useAction();

  if (user?.provider !== "password") {
    return (
      <Section title="Password">
        <p className="text-sm text-muted">You sign in with {PROVIDER_LABEL[user?.provider ?? "password"]}, so your password is managed there.</p>
      </Section>
    );
  }

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (next.length < 8) return setError("Use at least 8 characters.");
    if (next !== confirm) return setError("The two new passwords don't match.");
    setError("");
    const r = await run(() => changePassword(current, next));
    if (r.ok) {
      setCurrent("");
      setNext("");
      setConfirm("");
    }
  };
  return (
    <Section title="Password" intro="Passwords are never stored in readable form.">
      <Feedback result={result} />
      <form onSubmit={submit} className="space-y-4" noValidate>
        <PasswordInput label="Current password" value={current} onChange={setCurrent} autoComplete="current-password" />
        <PasswordInput label="New password" value={next} onChange={setNext} autoComplete="new-password" error={error} hint="At least 8 characters." />
        <PasswordInput label="Confirm new password" value={confirm} onChange={setConfirm} autoComplete="new-password" />
        <Button type="submit" disabled={busy || !current || !next || !confirm}>Change password</Button>
      </form>
    </Section>
  );
}

function DecoySection() {
  const { user, hasDecoy, setDecoy } = useAuth();
  const [decoy, setDecoyValue] = useState("");
  const [current, setCurrent] = useState("");
  const { busy, result, run } = useAction();
  const needsPassword = user?.provider === "password";

  const save = async (e: FormEvent) => {
    e.preventDefault();
    const r = await run(() => setDecoy(decoy, current));
    if (r.ok) {
      setDecoyValue("");
      setCurrent("");
    }
  };
  return (
    <Section title="Decoy password" intro="If someone forces you to log in, entering this password instantly sends the browser to Google instead.">
      <div className="mb-4"><Badge tone={hasDecoy ? "ok" : "neutral"}>{hasDecoy ? "Decoy password is set" : "Not set"}</Badge></div>
      <Feedback result={result} />
      <form onSubmit={save} className="space-y-4">
        <PasswordInput label={hasDecoy ? "New decoy password" : "Decoy password"} value={decoy} onChange={setDecoyValue} autoComplete="off" />
        {needsPassword && <PasswordInput label="Current password" value={current} onChange={setCurrent} autoComplete="current-password" />}
        <div className="flex flex-wrap gap-3">
          <Button type="submit" disabled={busy || !decoy || (needsPassword && !current)}>Save decoy password</Button>
          {hasDecoy && <Button variant="secondary" disabled={busy} onClick={() => void run(() => setDecoy(null))}>Remove</Button>}
        </div>
      </form>
    </Section>
  );
}

function DangerSection() {
  const { user, logout, deleteAccount } = useAuth();
  const navigate = useNavigate();
  const [confirming, setConfirming] = useState(false);
  const [password, setPassword] = useState("");
  const { busy, result, run } = useAction();
  const needsPassword = user?.provider === "password";

  const remove = async (e: FormEvent) => {
    e.preventDefault();
    const r = await run(() => deleteAccount(password));
    if (r.ok) navigate("/", { replace: true });
  };
  return (
    <Section title="Session and account">
      <div className="flex flex-wrap gap-3">
        <Button variant="secondary" onClick={() => void logout().then(() => navigate("/"))}>Log out</Button>
        {!confirming && <Button variant="danger" onClick={() => setConfirming(true)}>Delete my account</Button>}
      </div>
      {confirming && (
        <form onSubmit={remove} className="mt-5 space-y-4 rounded-xl border border-danger-600/30 bg-danger-50 p-4">
          <p className="text-sm font-semibold text-danger-700">This permanently deletes your account, evidence reports and saved allies from the database and this device.</p>
          <Feedback result={result} />
          {needsPassword && <PasswordInput label="Confirm with your password" value={password} onChange={setPassword} autoComplete="current-password" />}
          <div className="flex gap-3">
            <Button type="submit" variant="danger" disabled={busy || (needsPassword && !password)}>Delete permanently</Button>
            <Button variant="secondary" onClick={() => setConfirming(false)}>Cancel</Button>
          </div>
        </form>
      )}
    </Section>
  );
}

export function SettingsPanel() {
  const { user, demoMode } = useAuth();
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <Card>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="font-bold text-brand-900">{user?.email}</p>
            <p className="text-sm text-muted">Signed in with {PROVIDER_LABEL[user?.provider ?? "password"]}</p>
          </div>
          <Badge tone={demoMode ? "warn" : "ok"}>{demoMode ? "Demo mode" : "Secure session"}</Badge>
        </div>
      </Card>
      <ProfileSection />
      <EmailSection />
      <PasswordSection />
      <DecoySection />
      <DangerSection />
    </div>
  );
}
