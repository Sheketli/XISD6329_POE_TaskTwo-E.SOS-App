import { useState, type FormEvent } from "react";
import { ArrowLeft, Eye, EyeOff, Lock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { Alert, Card } from "../../components/ui/Display";
import { Button } from "../../components/ui/Button";
import { Input } from "../../components/ui/Field";
import { cn } from "../../lib/utils";

import { validateAuth, validatePasswordReset, type AuthMode as Mode } from "../../lib/validation";

export function PasswordInput({ label, value, onChange, error, hint, autoComplete }: { label: string; value: string; onChange: (v: string) => void; error?: string; hint?: string; autoComplete: string }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative">
      <Input label={label} type={show ? "text" : "password"} value={value} onChange={(e) => onChange(e.target.value)} error={error} hint={hint} autoComplete={autoComplete} className="pr-12" />
      <button type="button" onClick={() => setShow((s) => !s)} aria-label={show ? "Hide password" : "Show password"} className="absolute right-2 top-[2.1rem] flex h-9 w-9 items-center justify-center rounded-lg text-muted hover:bg-brand-50">
        {show ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
      </button>
    </div>
  );
}

export function AuthForm() {
  const { login, resetPassword, signup, loginWithProvider, demoMode } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("login");
  const [recovering, setRecovering] = useState(false);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [recoveryPassword, setRecoveryPassword] = useState("");
  const [confirmRecoveryPassword, setConfirmRecoveryPassword] = useState("");
  const [decoy, setDecoy] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  const switchMode = (m: Mode) => {
    setMode(m);
    setRecovering(false);
    setConfirmPassword("");
    setRecoveryPassword("");
    setConfirmRecoveryPassword("");
    setErrors({});
    setFormError("");
  };

  const openRecovery = () => {
    setRecovering(true);
    setErrors({});
    setFormError("");
    setNotice("");
  };

  const returnToLogin = () => {
    setRecovering(false);
    setRecoveryPassword("");
    setConfirmRecoveryPassword("");
    setErrors({});
    setFormError("");
  };

  const sso = async () => {
    setBusy(true);
    setFormError("");
    const res = await loginWithProvider();
    setBusy(false);
    if (res.ok) navigate("/dashboard");
    else setFormError(res.error);
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const next = validateAuth(mode, { username, email, password, confirmPassword, decoy });
    setErrors(next);
    setFormError("");
    if (Object.keys(next).length) return;

    setBusy(true);
    try {
      if (mode === "login") {
        const res = await login(email.trim(), password);
        if (res.ok) navigate("/dashboard");
        else if ("decoy" in res) window.location.replace("https://www.google.com");
        else setFormError(res.error);
      } else {
        const res = await signup({ username: username.trim(), email: email.trim(), password, decoy: decoy || undefined });
        if (res.ok) {
          setNotice("Account created. You can now log in.");
          setPassword("");
          setConfirmPassword("");
          setDecoy("");
          switchMode("login");
        } else setFormError(res.error ?? "Something went wrong.");
      }
    } finally {
      setBusy(false);
    }
  };

  const submitRecovery = async (e: FormEvent) => {
    e.preventDefault();
    const next = validatePasswordReset(email, recoveryPassword, confirmRecoveryPassword, demoMode);
    setErrors(next);
    setFormError("");
    setNotice("");
    if (Object.keys(next).length) return;

    setBusy(true);
    try {
      const res = await resetPassword(email.trim(), demoMode ? recoveryPassword : undefined);
      if (res.ok) {
        setNotice(res.message ?? "Password recovery instructions have been sent.");
        setRecovering(false);
        setPassword("");
        setRecoveryPassword("");
        setConfirmRecoveryPassword("");
      } else setFormError(res.error);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-md">
      <Card>
        {!recovering && (
          <div role="tablist" className="mb-6 grid grid-cols-2 rounded-xl bg-brand-50 p-1">
            {(["login", "signup"] as Mode[]).map((m) => (
              <button key={m} role="tab" type="button" aria-selected={mode === m} onClick={() => switchMode(m)} className={cn("min-h-10 rounded-lg font-semibold transition-colors", mode === m ? "bg-white text-brand-800 shadow-sm" : "text-muted")}>
                {m === "login" ? "Log in" : "Create account"}
              </button>
            ))}
          </div>
        )}

        {notice && <Alert tone="success" className="mb-4">{notice}</Alert>}
        {formError && <Alert tone="danger" className="mb-4">{formError}</Alert>}

        {recovering ? (
          <div>
            <h2 className="mb-2 text-xl">Reset your password</h2>
            <p className="mb-5 text-sm text-muted">
              {demoMode ? "Enter your account email and choose a new password." : "Enter your account email and we’ll send you a password reset link."}
            </p>
            {demoMode && (
              <Alert tone="warning" className="mb-4">
                Demo recovery does not verify that the email belongs to you. Anyone who knows a registered email can change that account’s password in this browser.
              </Alert>
            )}
            <form onSubmit={submitRecovery} className="space-y-4" noValidate>
              <Input label="Email address" type="email" value={email} onChange={(e) => setEmail(e.target.value)} error={errors.email} autoComplete="email" />
              {demoMode && (
                <>
                  <PasswordInput label="New password" value={recoveryPassword} onChange={setRecoveryPassword} error={errors.recoveryPassword} autoComplete="new-password" />
                  <PasswordInput label="Confirm new password" value={confirmRecoveryPassword} onChange={setConfirmRecoveryPassword} error={errors.confirmRecoveryPassword} autoComplete="new-password" />
                </>
              )}
              <Button type="submit" size="lg" className="w-full" disabled={busy}>
                {busy ? "Please wait…" : demoMode ? "Set new password" : "Send reset link"}
              </Button>
            </form>
            <button type="button" onClick={returnToLogin} className="mt-4 inline-flex min-h-10 items-center gap-2 rounded-lg px-2 text-sm font-semibold text-brand-700 hover:bg-brand-50">
              <ArrowLeft className="h-4 w-4" aria-hidden />
              Back to log in
            </button>
          </div>
        ) : (
          <>
            <div className="space-y-3">
              <Button variant="secondary" size="lg" className="w-full" disabled={busy || demoMode} onClick={() => void sso()}>
                <svg viewBox="0 0 48 48" className="h-5 w-5" aria-hidden><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.1-10.1 7.1-17.5z"/><path fill="#FBBC05" d="M10.5 28.7A14.5 14.5 0 0 1 9.5 24c0-1.6.3-3.2.8-4.7l-7.9-6.1A24 24 0 0 0 0 24c0 3.9.9 7.5 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.5-5.8c-2.1 1.4-4.9 2.3-8.4 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>
                Continue with Google
              </Button>
              {demoMode && <p className="text-center text-xs text-muted">Single sign-on is available once the site is connected to Firebase.</p>}
            </div>
            <div className="my-5 flex items-center gap-3 text-xs font-semibold uppercase tracking-wider text-muted">
              <span className="h-px flex-1 bg-line" /> or use email <span className="h-px flex-1 bg-line" />
            </div>
            <form onSubmit={submit} className="space-y-4" noValidate>
              {mode === "signup" && <Input label="Username" value={username} onChange={(e) => setUsername(e.target.value)} error={errors.username} autoComplete="username" hint="You don't need to use your real name." />}
              <Input label="Email address" type="email" value={email} onChange={(e) => setEmail(e.target.value)} error={errors.email} autoComplete="email" />
              <PasswordInput label="Password" value={password} onChange={setPassword} error={errors.password} autoComplete={mode === "login" ? "current-password" : "new-password"} />
              {mode === "login" && (
                <div className="-mt-2 text-right">
                  <button type="button" onClick={openRecovery} className="rounded px-1 py-1 text-sm font-semibold text-brand-700 underline decoration-brand-300 underline-offset-2 hover:text-brand-900">
                    Forgot password?
                  </button>
                </div>
              )}
              {mode === "signup" && (
                <>
                  <PasswordInput
                    label="Confirm password"
                    value={confirmPassword}
                    onChange={setConfirmPassword}
                    error={errors.confirmPassword}
                    autoComplete="new-password"
                  />
                  <PasswordInput
                    label="Decoy password (optional)"
                    value={decoy}
                    onChange={setDecoy}
                    error={errors.decoy}
                    autoComplete="off"
                    hint="If someone forces you to log in, entering this password instantly sends the browser to Google instead."
                  />
                </>
              )}
              <Button type="submit" size="lg" className="w-full" disabled={busy}>
                {busy ? "Please wait…" : mode === "login" ? "Log in" : "Create account"}
              </Button>
            </form>
            <p className="mt-5 flex items-start gap-2 text-xs text-muted">
              <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
              {demoMode ? "Demo mode: accounts and your saved data stay in this browser only." : "Your password is handled by Firebase Authentication. Your profile and saved data are stored in the e.sos database."}
            </p>
          </>
        )}
      </Card>
    </div>
  );
}
