import { useRef, useState } from "react";
import { Alert, Card } from "../../components/ui/Display";
import { Button } from "../../components/ui/Button";
import { Input, Select, Textarea } from "../../components/ui/Field";
import { AVAILABILITY, VOLUNTEER_ROLES } from "../../data/volunteer";
import { cn } from "../../lib/utils";
import { api } from "../../lib/api";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function VolunteerFlow() {
  const [role, setRole] = useState(VOLUNTEER_ROLES[0].name);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [times, setTimes] = useState<string[]>([]);
  const [motivation, setMotivation] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [done, setDone] = useState(false);
  const form = useRef<HTMLDivElement>(null);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!name.trim()) next.name = "Enter your full name.";
    if (!EMAIL.test(email.trim())) next.email = "Enter a valid email address.";
    if (!times.length) next.times = "Select at least one time you're available.";
    if (motivation.trim().length < 20) next.motivation = "Please write at least 20 characters.";
    setErrors(next);
    if (Object.keys(next).length) return;
    api("/volunteers", { method: "POST", body: { name: name.trim(), email: email.trim(), phone: phone.trim(), role, availability: times, motivation: motivation.trim() } }).catch(() => undefined);
    setDone(true);
  };

  if (done) {
    return (
      <div className="mx-auto max-w-xl">
        <Alert tone="success">
          <p className="font-bold">Thank you, {name}!</p>
          <p className="mt-1">We've noted your interest in "{role}". A screening officer will contact you at {email} within 3 working days.</p>
          <Button variant="secondary" size="sm" className="mt-4" onClick={() => { setDone(false); setName(""); setEmail(""); setPhone(""); setTimes([]); setMotivation(""); }}>Submit another application</Button>
        </Alert>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      <section>
        <h2 className="mb-5 text-2xl">Ways to volunteer</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {VOLUNTEER_ROLES.map((r) => (
            <Card key={r.name} className="flex flex-col !p-5">
              <h3 className="text-lg">{r.name}</h3>
              <p className="mt-1 flex-1 text-sm text-muted">{r.desc}</p>
              <Button variant={role === r.name ? "primary" : "secondary"} size="sm" className="mt-4" aria-pressed={role === r.name}
                onClick={() => { setRole(r.name); form.current?.scrollIntoView({ behavior: "smooth" }); }}>
                {role === r.name ? "Selected" : "Choose this role"}
              </Button>
            </Card>
          ))}
        </div>
      </section>

      <div ref={form} className="mx-auto max-w-2xl scroll-mt-24">
        <Card>
          <h2 className="text-2xl">Volunteer application</h2>
          <form onSubmit={submit} className="mt-6 space-y-5" noValidate>
            <Select label="Role" value={role} onChange={(e) => setRole(e.target.value)}>
              {VOLUNTEER_ROLES.map((r) => <option key={r.name}>{r.name}</option>)}
            </Select>
            <div className="grid gap-5 sm:grid-cols-2">
              <Input label="Full name" value={name} onChange={(e) => setName(e.target.value)} error={errors.name} autoComplete="name" />
              <Input label="Email address" type="email" value={email} onChange={(e) => setEmail(e.target.value)} error={errors.email} autoComplete="email" />
            </div>
            <Input label="Mobile number" optional type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+27 …" autoComplete="tel" />
            <fieldset>
              <legend className="mb-2 text-sm font-semibold text-brand-900">When are you available?</legend>
              <div className="flex flex-wrap gap-2">
                {AVAILABILITY.map((t) => {
                  const on = times.includes(t);
                  return (
                    <button key={t} type="button" aria-pressed={on} onClick={() => setTimes((x) => (on ? x.filter((i) => i !== t) : [...x, t]))}
                      className={cn("min-h-11 rounded-xl border-2 px-4 font-semibold", on ? "border-brand-700 bg-brand-700 text-white" : "border-line bg-white text-brand-900 hover:border-brand-300")}>
                      {t}
                    </button>
                  );
                })}
              </div>
              {errors.times && <p role="alert" className="mt-1.5 text-sm font-medium text-danger-700">{errors.times}</p>}
            </fieldset>
            <Textarea label="Why do you want to volunteer?" value={motivation} onChange={(e) => setMotivation(e.target.value)} error={errors.motivation} />
            <Button type="submit" size="lg" className="w-full">Submit application</Button>
          </form>
        </Card>
      </div>
    </div>
  );
}
