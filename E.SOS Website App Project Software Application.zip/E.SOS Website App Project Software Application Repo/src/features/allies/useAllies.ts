import { useEffect } from "react";
import { useAuth } from "../../context/AuthContext";
import { useLocalStorage } from "../../hooks/useLocalStorage";
import { uid } from "../../lib/utils";
import { api, syncCollection, syncQuietly } from "../../lib/api";
import type { Ally } from "../../types";

export function useAllies() {
  const { user } = useAuth();
  const [allies, setAllies] = useLocalStorage<Ally[]>(user ? `esos_allies_${user.id}` : "esos_guest_allies", []);

  useEffect(() => {
    if (!user) return;
    void syncQuietly(async () => setAllies(await syncCollection("/allies", allies)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const add = (a: Omit<Ally, "id">) => {
    const ally = { ...a, id: uid("ally") };
    setAllies((prev) => [...prev, ally]);
    void syncQuietly(() => api("/allies", { method: "POST", body: ally, signedIn: true }));
  };
  const remove = (id: string) => {
    setAllies((prev) => prev.filter((a) => a.id !== id));
    void syncQuietly(() => api(`/allies/${id}`, { method: "DELETE", signedIn: true }));
  };
  return { allies, add, remove };
}

export function alertLink(phone: string, coords?: { lat: number; lng: number } | null) {
  const where = coords ? ` My location: https://maps.google.com/?q=${coords.lat},${coords.lng}` : "";
  const body = `I need help urgently. Please call me or contact the police (10111).${where}`;
  return `sms:${phone.replace(/\s/g, "")}?body=${encodeURIComponent(body)}`;
}
