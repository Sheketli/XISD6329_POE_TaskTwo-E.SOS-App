import { useState } from "react";
import { MessageSquareWarning, Phone, Trash2, UserPlus } from "lucide-react";
import { alertLink, useAllies } from "./useAllies";
import { Alert, Card, EmptyState } from "../../components/ui/Display";
import { Button, ButtonAnchor } from "../../components/ui/Button";
import { Input, Select } from "../../components/ui/Field";

const RELATIONS = ["Friend", "Family member", "Counselor", "Advocate", "Neighbour", "Colleague"];

export function AlliesBook() {
  const { allies, add, remove } = useAllies();
  const [name, setName] = useState("");
  const [relationship, setRelationship] = useState(RELATIONS[0]);
  const [phone, setPhone] = useState("");
  const [errors, setErrors] = useState<{ name?: string; phone?: string }>({});

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: typeof errors = {};
    if (!name.trim()) next.name = "Enter a name.";
    if (!/^[+\d][\d\s-]{6,}$/.test(phone.trim())) next.phone = "Enter a valid phone number.";
    setErrors(next);
    if (Object.keys(next).length) return;
    add({ name: name.trim(), relationship, phone: phone.trim() });
    setName("");
    setPhone("");
  };

  return (
    <div className="grid gap-8 lg:grid-cols-[360px_1fr]">
      <Card>
        <h2 className="flex items-center gap-2 text-xl"><UserPlus className="h-5 w-5" aria-hidden /> Add an ally</h2>
        <p className="mt-1 text-sm text-muted">Someone you trust who can help if you need them.</p>
        <form onSubmit={submit} className="mt-5 space-y-4" noValidate>
          <Input label="Name" value={name} onChange={(e) => setName(e.target.value)} error={errors.name} autoComplete="off" />
          <Select label="Relationship" value={relationship} onChange={(e) => setRelationship(e.target.value)}>
            {RELATIONS.map((r) => <option key={r}>{r}</option>)}
          </Select>
          <Input label="Phone number" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} error={errors.phone} placeholder="082 123 4567" autoComplete="off" />
          <Button type="submit" className="w-full">Save ally</Button>
        </form>
      </Card>

      <div>
        <h2 className="mb-4 text-xl">Your allies ({allies.length})</h2>
        {allies.length === 0 ? (
          <EmptyState title="No allies saved yet" text="Add at least one person you trust. They'll appear here and on the Panic page." />
        ) : (
          <ul className="space-y-3">
            {allies.map((a) => (
              <li key={a.id}>
                <Card className="flex flex-wrap items-center justify-between gap-4 !p-5">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">{a.relationship}</p>
                    <p className="text-lg font-semibold text-brand-900">{a.name}</p>
                    <p className="text-sm text-muted">{a.phone}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <ButtonAnchor href={`tel:${a.phone.replace(/\s/g, "")}`} variant="secondary" size="sm"><Phone className="h-4 w-4" aria-hidden /> Call</ButtonAnchor>
                    <ButtonAnchor href={alertLink(a.phone)} variant="danger" size="sm"><MessageSquareWarning className="h-4 w-4" aria-hidden /> Send alert SMS</ButtonAnchor>
                    <Button variant="ghost" size="sm" onClick={() => remove(a.id)} aria-label={`Remove ${a.name}`}><Trash2 className="h-4 w-4" aria-hidden /></Button>
                  </div>
                </Card>
              </li>
            ))}
          </ul>
        )}
        <Alert className="mt-6">
          "Send alert SMS" opens your phone's messaging app with a ready-written message. Nothing is sent until you press send. Saved to your account and cached on this device.
        </Alert>
      </div>
    </div>
  );
}
