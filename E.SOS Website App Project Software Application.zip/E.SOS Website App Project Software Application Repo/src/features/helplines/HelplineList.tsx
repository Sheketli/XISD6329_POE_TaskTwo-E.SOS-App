import { useMemo, useState } from "react";
import { Phone, Search } from "lucide-react";
import { HELPLINES as FALLBACK } from "../../data/helplines";
import { useApiData } from "../../lib/api";
import type { Helpline } from "../../types";
import { Card, EmptyState } from "../../components/ui/Display";
import { Input } from "../../components/ui/Field";
import { ButtonAnchor } from "../../components/ui/Button";

export function HelplineList() {
  const HELPLINES = useApiData<Helpline[]>("/helplines", FALLBACK);
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return HELPLINES.filter((h) => !s || `${h.name} ${h.category} ${h.details}`.toLowerCase().includes(s));
  }, [HELPLINES, q]);

  return (
    <div className="mx-auto max-w-3xl">
      <div className="relative mb-6">
        <Input label="Search helplines" type="search" placeholder="e.g. police, children, legal" value={q} onChange={(e) => setQ(e.target.value)} className="pl-10" />
        <Search className="pointer-events-none absolute bottom-3.5 left-3 h-5 w-5 text-muted" aria-hidden />
      </div>
      {list.length === 0 ? (
        <EmptyState title="No helplines match your search" />
      ) : (
        <ul className="space-y-3">
          {list.map((h) => (
            <li key={h.name}>
              <Card className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">{h.category}</p>
                  <h2 className="text-lg">{h.name}</h2>
                  <p className="text-sm text-muted">{h.details}</p>
                </div>
                <ButtonAnchor href={`tel:${h.dial}`} className="shrink-0">
                  <Phone className="h-4 w-4" aria-hidden /> {h.phone}
                </ButtonAnchor>
              </Card>
            </li>
          ))}
        </ul>
      )}
      <p className="mt-6 text-sm text-muted">
        Calls appear in your phone's call history. Delete them afterwards if someone checks your phone. Free numbers do not use airtime.
      </p>
    </div>
  );
}
