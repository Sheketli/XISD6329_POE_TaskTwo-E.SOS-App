import { useMemo, useState } from "react";
import { Phone, Search, ShieldCheck } from "lucide-react";
import { SHELTERS as FALLBACK } from "../../data/shelters";
import { useApiData } from "../../lib/api";
import { Alert, Badge, Card, EmptyState } from "../../components/ui/Display";
import { Input, Select } from "../../components/ui/Field";
import { ButtonAnchor } from "../../components/ui/Button";
import type { Capacity, Shelter } from "../../types";

const tone: Record<Capacity, "ok" | "warn" | "danger"> = { Available: "ok", Limited: "warn", Full: "danger" };

export function ShelterFinder() {
  const SHELTERS = useApiData<Shelter[]>("/shelters", FALLBACK);
  const PROVINCES = useMemo(() => Array.from(new Set(SHELTERS.map((s) => s.province))), [SHELTERS]);
  const SERVICES = useMemo(() => Array.from(new Set(SHELTERS.flatMap((s) => s.services))).sort(), [SHELTERS]);
  const [query, setQuery] = useState("");
  const [province, setProvince] = useState("");
  const [service, setService] = useState("");

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return SHELTERS.filter(
      (s) =>
        (!q || s.name.toLowerCase().includes(q) || s.location.toLowerCase().includes(q)) &&
        (!province || s.province === province) &&
        (!service || s.services.includes(service)),
    );
  }, [SHELTERS, query, province, service]);

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
      <div>
        <Card className="mb-6">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="relative">
              <Input label="Search" type="search" placeholder="Name, city or suburb" value={query} onChange={(e) => setQuery(e.target.value)} className="pl-10" />
              <Search className="pointer-events-none absolute bottom-3.5 left-3 h-5 w-5 text-muted" aria-hidden />
            </div>
            <Select label="Province" value={province} onChange={(e) => setProvince(e.target.value)}>
              <option value="">All provinces</option>
              {PROVINCES.map((p) => <option key={p}>{p}</option>)}
            </Select>
            <Select label="Service" value={service} onChange={(e) => setService(e.target.value)}>
              <option value="">All services</option>
              {SERVICES.map((s) => <option key={s}>{s}</option>)}
            </Select>
          </div>
        </Card>

        <p className="mb-3 text-sm text-muted" aria-live="polite">{results.length} shelter{results.length === 1 ? "" : "s"} found</p>

        {results.length === 0 ? (
          <EmptyState title="No shelters match your search" text="Try a different province or service, or call the GBV Command Centre on 0800 428 428." />
        ) : (
          <ul className="space-y-4">
            {results.map((s) => (
              <li key={s.id}>
                <Card>
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="text-sm text-muted">{s.location} · {s.province}</p>
                      <h2 className="text-xl">{s.name}</h2>
                    </div>
                    <Badge tone={tone[s.capacity]}>{s.capacity === "Full" ? "Currently full" : `${s.capacity} space`}</Badge>
                  </div>
                  <ul className="mt-4 flex flex-wrap gap-2">
                    {s.services.map((x) => (
                      <li key={x} className="rounded-full bg-surface px-3 py-1 text-sm text-ink ring-1 ring-line">{x}</li>
                    ))}
                  </ul>
                  <div className="mt-5">
                    <ButtonAnchor href={`tel:${s.phone.replace(/\s/g, "")}`}>
                      <Phone className="h-4 w-4" aria-hidden /> Call {s.phone}
                    </ButtonAnchor>
                  </div>
                </Card>
              </li>
            ))}
          </ul>
        )}
      </div>

      <aside className="space-y-4">
        <Alert tone="info">
          <p className="flex items-center gap-1.5 font-semibold"><ShieldCheck className="h-4 w-4" aria-hidden /> Your privacy</p>
          <p className="mt-1">Exact shelter addresses are not published. When you call, staff will arrange a safe meeting point or transport.</p>
        </Alert>
        <Card>
          <h2 className="text-lg">If you're leaving now</h2>
          <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm text-muted">
            <li>If you are in danger, call 10111.</li>
            <li>Call a shelter and ask about space.</li>
            <li>Tell one trusted person where you are going.</li>
            <li>Take ID, medication and your phone charger if you can.</li>
          </ol>
        </Card>
        <Card>
          <h2 className="text-lg">Need an escort?</h2>
          <p className="mt-1 text-sm text-muted">The GBV Command Centre can arrange discreet help to reach a shelter.</p>
          <ButtonAnchor href="tel:0800428428" variant="secondary" className="mt-3 w-full">Call 0800 428 428</ButtonAnchor>
        </Card>
      </aside>
    </div>
  );
}
