import { useEffect, useRef, useState } from "react";
import { EyeOff, Send, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { CHAT_SHORTCUTS, botReply } from "../../data/chat";
import { useAuth } from "../../context/AuthContext";
import { Alert, Card } from "../../components/ui/Display";
import { Button } from "../../components/ui/Button";
import { cn, timeNow, uid } from "../../lib/utils";
import type { ChatMessage } from "../../types";

export function CounselorChat() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: uid("m"),
      sender: "bot",
      time: timeNow(),
      text: `Hello ${user?.username ?? "there"}, I'm Nomvula, an automated assistant. I can share information on safety planning, legal options and shelters. I'm not a person, and for urgent help please call 0800 428 428. Nothing you type here is stored or sent anywhere.`,
    },
  ]);
  const [draft, setDraft] = useState("");
  const [typing, setTyping] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  const timer = useRef<number>(undefined);

  useEffect(() => {
    end.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [messages, typing]);
  useEffect(() => () => window.clearTimeout(timer.current), []);

  const send = (text: string, canned?: string) => {
    const clean = text.trim();
    if (!clean) return;
    setMessages((m) => [...m, { id: uid("m"), sender: "user", text: clean, time: timeNow() }]);
    setDraft("");
    setTyping(true);
    timer.current = window.setTimeout(() => {
      setMessages((m) => [...m, { id: uid("m"), sender: "bot", text: canned ?? botReply(clean), time: timeNow() }]);
      setTyping(false);
    }, 900);
  };

  const clear = () => {
    window.clearTimeout(timer.current);
    setTyping(false);
    setMessages([{ id: uid("m"), sender: "system", text: "Conversation cleared.", time: timeNow() }]);
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
      <div className="space-y-4">
        <Card>
          <h2 className="text-lg">Quick topics</h2>
          <div className="mt-3 flex flex-col gap-2">
            {CHAT_SHORTCUTS.map((s) => (
              <Button key={s.label} variant="secondary" className="justify-start text-left" onClick={() => send(s.label, s.response)}>
                {s.label}
              </Button>
            ))}
          </div>
        </Card>
        <Card>
          <h2 className="text-lg">Someone is coming?</h2>
          <div className="mt-3 flex flex-col gap-2">
            <Button variant="secondary" onClick={clear}><Trash2 className="h-4 w-4" aria-hidden /> Clear conversation</Button>
            <Link to="/cover" className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-line bg-white px-5 font-semibold text-brand-800 hover:bg-brand-50">
              <EyeOff className="h-4 w-4" aria-hidden /> Show cover page
            </Link>
          </div>
        </Card>
      </div>

      <Card className="flex h-[70vh] min-h-[480px] flex-col !p-0">
        <div className="border-b border-line px-5 py-3">
          <p className="font-semibold text-brand-900">Nomvula · automated assistant</p>
          <p className="text-xs text-muted">Messages stay on this page only</p>
        </div>
        <div className="flex-1 space-y-4 overflow-y-auto p-5" aria-live="polite">
          {messages.map((m) =>
            m.sender === "system" ? (
              <p key={m.id} className="text-center text-sm text-muted">{m.text}</p>
            ) : (
              <div key={m.id} className={cn("flex", m.sender === "user" && "justify-end")}>
                <div className={cn("max-w-[85%] whitespace-pre-line rounded-2xl px-4 py-3", m.sender === "user" ? "rounded-br-sm bg-brand-700 text-white" : "rounded-bl-sm bg-brand-50 text-ink")}>
                  {m.text}
                  <span className={cn("mt-1 block text-xs", m.sender === "user" ? "text-brand-200" : "text-muted")}>{m.time}</span>
                </div>
              </div>
            ),
          )}
          {typing && <p className="text-sm text-muted">Nomvula is typing…</p>}
          <div ref={end} />
        </div>
        <form onSubmit={(e) => { e.preventDefault(); send(draft); }} className="flex gap-2 border-t border-line p-4">
          <label htmlFor="chat-input" className="sr-only">Your message</label>
          <input id="chat-input" value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Type your message…" className="min-h-11 flex-1 rounded-xl border border-line px-4 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-200" />
          <Button type="submit" disabled={!draft.trim()}><Send className="h-4 w-4" aria-hidden /> Send</Button>
        </form>
      </Card>
      <div className="lg:col-span-2">
        <Alert tone="warning">This assistant gives general information only and is not a replacement for a counselor, lawyer or the police.</Alert>
      </div>
    </div>
  );
}
