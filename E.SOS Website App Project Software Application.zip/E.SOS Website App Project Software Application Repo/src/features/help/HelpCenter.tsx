import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ChevronDown, Phone, Search } from "lucide-react";
import { Alert, Badge, Card } from "../../components/ui/Display";
import { FAQS, GUIDES } from "../../data/help";
import { SITE } from "../../config/site";

const QUICK_START = [
  { n: "1", title: "Get help now", text: "Find helplines and shelters without an account.", to: "/helplines" },
  { n: "2", title: "Sign in with Google", text: "Unlock the Evidence vault, allies sync and Settings.", to: "/login" },
  { n: "3", title: "Plan your safety", text: "Add trusted allies and learn the panic button.", to: "/allies" },
];

export function HelpCenter() {
  const [query, setQuery] = useState("");
  const q = query.trim().toLowerCase();

  const guides = useMemo(
    () => GUIDES.filter((g) => !q || [g.title, g.summary, ...g.steps].join(" ").toLowerCase().includes(q)),
    [q],
  );
  const faqs = useMemo(
    () =>
      FAQS.map((g) => ({ ...g, items: g.items.filter((i) => !q || `${i.q} ${i.a}`.toLowerCase().includes(q)) })).filter((g) => g.items.length),
    [q],
  );

  return (
    <div className="space-y-12">
      <Alert tone="danger">
        <strong>In danger right now?</strong> Call <a className="font-bold underline" href="tel:10111">Police 10111</a> or the GBV Command Centre{" "}
        <a className="font-bold underline" href="tel:0800428428">0800 428 428</a> (free, 24/7). Use Quick exit to leave this site instantly.
      </Alert>

      <div className="relative max-w-xl">
        <label htmlFor="help-search" className="sr-only">Search help</label>
        <Search className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted" aria-hidden />
        <input
          id="help-search"
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search help, e.g. password, shelter, report"
          className="min-h-12 w-full rounded-xl border border-line bg-white pl-10 pr-4 text-base"
        />
      </div>

      {!q && (
        <section aria-labelledby="quick-start">
          <h2 id="quick-start" className="text-2xl">Quick start</h2>
          <ol className="mt-4 grid gap-4 md:grid-cols-3">
            {QUICK_START.map((s) => (
              <li key={s.n}>
                <Link to={s.to} className="block h-full rounded-2xl border border-line bg-white p-5 shadow-sm hover:border-brand-300">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-700 font-bold text-white">{s.n}</span>
                  <span className="mt-3 block font-bold text-brand-900">{s.title}</span>
                  <span className="block text-sm text-muted">{s.text}</span>
                </Link>
              </li>
            ))}
          </ol>
        </section>
      )}

      <section aria-labelledby="guides">
        <h2 id="guides" className="text-2xl">Step-by-step guides</h2>
        {guides.length === 0 && <p className="mt-4 text-muted">No guides match "{query}".</p>}
        <div className="mt-4 space-y-3">
          {guides.map((g) => (
            <details key={g.id} className="group rounded-2xl border border-line bg-white shadow-sm">
              <summary className="flex min-h-14 cursor-pointer list-none items-center justify-between gap-3 p-4">
                <span>
                  <span className="block font-bold text-brand-900">
                    {g.title} {g.needsLogin && <Badge>Login required</Badge>}
                  </span>
                  <span className="block text-sm text-muted">{g.summary}</span>
                </span>
                <ChevronDown className="h-5 w-5 shrink-0 transition-transform group-open:rotate-180" aria-hidden />
              </summary>
              <div className="border-t border-line p-4">
                <ol className="list-decimal space-y-2 pl-5">
                  {g.steps.map((s) => (
                    <li key={s}>{s}</li>
                  ))}
                </ol>
                <Link to={g.to} className="mt-4 inline-flex min-h-11 items-center font-semibold text-brand-700 underline">Go to this page</Link>
              </div>
            </details>
          ))}
        </div>
      </section>

      <section aria-labelledby="faq">
        <h2 id="faq" className="text-2xl">Frequently asked questions</h2>
        {faqs.length === 0 && <p className="mt-4 text-muted">No questions match "{query}".</p>}
        <div className="mt-4 space-y-8">
          {faqs.map((g) => (
            <div key={g.group}>
              <h3 className="mb-2 text-sm font-bold uppercase tracking-wider text-muted">{g.group}</h3>
              <div className="space-y-2">
                {g.items.map((i) => (
                  <details key={i.q} className="group rounded-xl border border-line bg-white">
                    <summary className="flex min-h-12 cursor-pointer list-none items-center justify-between gap-3 px-4 py-2 font-semibold text-brand-900">
                      {i.q}
                      <ChevronDown className="h-5 w-5 shrink-0 transition-transform group-open:rotate-180" aria-hidden />
                    </summary>
                    <p className="border-t border-line px-4 py-3 text-ink">{i.a}</p>
                  </details>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <Card className="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl">Still need help?</h2>
          <p className="text-muted">Call our office or talk to a counselor.</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <a href={`tel:${SITE.phone.replace(/\s/g, "")}`} className="inline-flex min-h-11 items-center gap-2 font-semibold text-brand-700 underline">
            <Phone className="h-4 w-4" aria-hidden /> {SITE.phone}
          </a>
          <Link to="/chat" className="inline-flex min-h-11 items-center font-semibold text-brand-700 underline">Counselor chat</Link>
        </div>
      </Card>
    </div>
  );
}
