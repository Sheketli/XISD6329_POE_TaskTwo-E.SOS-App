import { Link } from "react-router-dom";
import { ArrowRight, BookOpen, Home, MessageCircleHeart, Phone, Scale, ShieldAlert, ShieldCheck, Users, HeartHandshake } from "lucide-react";
import { ButtonLink } from "../../components/ui/Button";
import { Card } from "../../components/ui/Display";
import { HELPLINES, TOP_HELPLINES } from "../../data/helplines";
import { SITE } from "../../config/site";

export function Hero() {
  return (
    <section className="bg-gradient-to-b from-brand-50 to-surface">
      <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-2 lg:py-20">
        <div>
          <p className="mb-4 inline-block rounded-full bg-brand-100 px-3 py-1 text-sm font-semibold text-brand-800">
            Free, confidential support across South Africa
          </p>
          <h1 className="text-4xl sm:text-5xl">You are not alone. Help is here when you are ready.</h1>
          <p className="mt-5 max-w-xl text-lg text-muted">
            {SITE.name} is a feminist organisation that supports survivors of gender-based violence with shelter, counseling and legal advice, and fights for women's rights. {SITE.tagline}
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <ButtonLink to="/panic" variant="danger" size="lg">
              <ShieldAlert className="h-5 w-5" aria-hidden /> I need help now
            </ButtonLink>
            <ButtonLink to="/shelters" variant="secondary" size="lg">
              <Home className="h-5 w-5" aria-hidden /> Find a shelter
            </ButtonLink>
          </div>
          <p className="mt-5 text-sm text-muted">
            Worried someone is watching? Use the <strong>Quick exit</strong> button (or press <kbd className="rounded border border-line bg-white px-1.5">Esc</kbd> twice) at any time.
          </p>
        </div>
        <Card className="space-y-4 bg-white">
          <h2 className="text-xl">Call a free helpline</h2>
          {TOP_HELPLINES.map((name) => {
            const h = HELPLINES.find((x) => x.name === name)!;
            return (
              <a key={h.name} href={`tel:${h.dial}`} className="flex items-center justify-between gap-4 rounded-xl border border-line p-4 hover:border-brand-300 hover:bg-brand-50">
                <span>
                  <span className="block font-semibold text-brand-900">{h.name}</span>
                  <span className="block text-sm text-muted">{h.details}</span>
                </span>
                <span className="flex shrink-0 items-center gap-2 text-lg font-bold text-brand-700">
                  <Phone className="h-5 w-5" aria-hidden /> {h.phone}
                </span>
              </a>
            );
          })}
          <Link to="/helplines" className="inline-flex items-center gap-1 text-sm font-semibold text-brand-700 hover:underline">
            See all helplines <ArrowRight className="h-4 w-4" aria-hidden />
          </Link>
        </Card>
      </div>
    </section>
  );
}

const SERVICES = [
  { to: "/shelters", icon: Home, title: "Find a shelter", text: "Search safe houses by province and service." },
  { to: "/chat", icon: MessageCircleHeart, title: "Talk to a counselor", text: "Private guidance, safety planning and calming exercises." },
  { to: "/vault", icon: ShieldCheck, title: "Evidence vault", text: "Record incidents with dates and notes for a protection order." },
  { to: "/allies", icon: Users, title: "Trusted allies", text: "Keep key contacts ready and message them quickly." },
];

export function Services() {
  return (
    <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
      <h2 className="text-3xl">How we can help</h2>
      <p className="mt-2 max-w-2xl text-muted">Choose what you need. Everything here is private to your device.</p>
      <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {SERVICES.map(({ to, icon: Icon, title, text }) => (
          <Link key={to} to={to} className="group rounded-2xl border border-line bg-white p-6 shadow-sm transition hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-md">
            <span className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-brand-100 text-brand-700">
              <Icon className="h-6 w-6" aria-hidden />
            </span>
            <h3 className="text-lg">{title}</h3>
            <p className="mt-1 text-sm text-muted">{text}</p>
            <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-brand-700">
              Open <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" aria-hidden />
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
}

const RESOURCES = [
  { icon: Scale, title: "Know your rights", text: "Under the Domestic Violence Act you can apply for a free protection order at any magistrate's court, and police must help you." },
  { icon: BookOpen, title: "Signs of abuse", text: "Abuse can be physical, emotional, financial or digital: controlling money, tracking your phone, isolating you from friends or threatening you." },
  { icon: Scale, title: "Legal aid", text: "Legal Aid SA offers free advice and representation. Call 0800 110 110 or ask a social worker to go with you." },
  { icon: Home, title: "Safe shelters", text: "Shelters offer a secure place to stay, counseling and help for children. Call ahead to ask about space." },
];

export function Resources() {
  return (
    <section className="bg-white">
      <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
        <h2 className="text-3xl">Know your options</h2>
        <div className="mt-8 grid gap-5 sm:grid-cols-2">
          {RESOURCES.map(({ icon: Icon, title, text }) => (
            <div key={title} className="flex gap-4 rounded-2xl border border-line bg-surface p-6">
              <Icon className="mt-1 h-6 w-6 shrink-0 text-brand-600" aria-hidden />
              <div>
                <h3 className="text-lg">{title}</h3>
                <p className="mt-1 text-muted">{text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Mission() {
  return (
    <section className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
      <div className="grid gap-5 md:grid-cols-2">
        <Card>
          <h3 className="text-xl">Our vision</h3>
          <p className="mt-2 text-muted">A society free from gender-based violence, where women enjoy their rights and live in dignity.</p>
        </Card>
        <Card>
          <h3 className="text-xl">Our mission</h3>
          <p className="mt-2 text-muted">High-quality services to survivors of gender-based violence and direct advocacy for law reform.</p>
        </Card>
      </div>
    </section>
  );
}

export function GetInvolved() {
  return (
    <section className="px-4 pb-4 sm:px-6">
      <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 rounded-3xl bg-brand-800 p-8 text-white sm:p-12 md:flex-row md:items-center">
        <div>
          <h2 className="text-3xl !text-white">Help us rebuild lives</h2>
          <p className="mt-2 max-w-xl text-brand-100">Your donation or time funds shelter, counseling and legal support for survivors.</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <ButtonLink to="/donate" variant="accent" size="lg">
            <HeartHandshake className="h-5 w-5" aria-hidden /> Donate
          </ButtonLink>
          <ButtonLink to="/volunteer" variant="secondary" size="lg">Volunteer</ButtonLink>
        </div>
      </div>
    </section>
  );
}
