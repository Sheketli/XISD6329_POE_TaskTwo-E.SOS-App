import { useEffect, useRef, useState } from "react";
import { Download, FileText, Lock, Trash2, UploadCloud } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { useLocalStorage } from "../../hooks/useLocalStorage";
import { Alert, Badge, Card, EmptyState } from "../../components/ui/Display";
import { Button } from "../../components/ui/Button";
import { Input, Select, Textarea } from "../../components/ui/Field";
import { uid } from "../../lib/utils";
import { api, canSync, syncCollection, syncQuietly } from "../../lib/api";
import type { IncidentReport } from "../../types";

const TYPES = ["Physical abuse", "Psychological abuse", "Economic control", "Emotional abuse", "Stalking or tracking", "Other"];
const today = () => new Date().toISOString().slice(0, 10);

export function EvidenceVault() {
  const { user } = useAuth();
  const [reports, setReports] = useLocalStorage<IncidentReport[]>(`esos_reports_${user?.id}`, []);
  const [title, setTitle] = useState("");
  const [type, setType] = useState(TYPES[0]);
  const [date, setDate] = useState(today());
  const [time, setTime] = useState("12:00");
  const [description, setDescription] = useState("");
  const [files, setFiles] = useState<string[]>([]);
  const [errors, setErrors] = useState<{ title?: string; description?: string }>({});
  const [saved, setSaved] = useState(false);
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) return;
    void syncQuietly(async () => setReports(await syncCollection("/reports", reports)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const remove = (id: string, label: string) => {
    if (!window.confirm(`Delete "${label}"? This cannot be undone.`)) return;
    setReports((x) => x.filter((i) => i.id !== id));
    void syncQuietly(() => api(`/reports/${id}`, { method: "DELETE", signedIn: true }));
  };

  const addFiles = (list: FileList | null) => list && setFiles((f) => [...f, ...Array.from(list).map((x) => x.name)]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: typeof errors = {};
    if (!title.trim()) next.title = "Give the incident a short title.";
    if (description.trim().length < 10) next.description = "Describe what happened (at least 10 characters).";
    setErrors(next);
    if (Object.keys(next).length) return;
    const report: IncidentReport = { id: uid("rep"), title: title.trim(), type, date, time, description: description.trim(), confidentiality: canSync ? "private" : "device", attachments: files, createdAt: new Date().toISOString() };
    setReports((r) => [report, ...r]);
    void syncQuietly(() => api("/reports", { method: "POST", body: report, signedIn: true }));
    setTitle("");
    setDescription("");
    setFiles([]);
    setSaved(true);
    window.setTimeout(() => setSaved(false), 4000);
  };

  const exportJson = () => {
    const url = URL.createObjectURL(new Blob([JSON.stringify(reports, null, 2)], { type: "application/json" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "esos-incident-log.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <Card>
        <h2 className="text-xl">Log a new incident</h2>
        <form onSubmit={submit} className="mt-5 space-y-4" noValidate>
          <Input label="Short title" value={title} onChange={(e) => setTitle(e.target.value)} error={errors.title} placeholder="e.g. Threatening phone calls" />
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label="Date" type="date" value={date} max={today()} onChange={(e) => setDate(e.target.value)} />
            <Input label="Approximate time" type="time" value={time} onChange={(e) => setTime(e.target.value)} />
          </div>
          <Select label="Type of abuse" value={type} onChange={(e) => setType(e.target.value)}>
            {TYPES.map((t) => <option key={t}>{t}</option>)}
          </Select>
          <Textarea label="What happened?" value={description} onChange={(e) => setDescription(e.target.value)} error={errors.description} hint="Include who, where, and anything said. Details help in court." rows={5} />
          <div>
            <p className="mb-1.5 text-sm font-semibold text-brand-900">Evidence files <span className="font-normal text-muted">(optional)</span></p>
            <button
              type="button"
              onClick={() => input.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => { e.preventDefault(); addFiles(e.dataTransfer.files); }}
              className="flex w-full flex-col items-center gap-1 rounded-xl border-2 border-dashed border-line bg-surface p-6 text-sm text-muted hover:border-brand-300"
            >
              <UploadCloud className="h-6 w-6 text-brand-600" aria-hidden />
              Drop files here or click to choose
            </button>
            <input ref={input} type="file" multiple className="sr-only" tabIndex={-1} onChange={(e) => { addFiles(e.target.files); e.target.value = ""; }} />
            {files.length > 0 && (
              <ul className="mt-2 space-y-1 text-sm">
                {files.map((f, i) => (
                  <li key={`${f}-${i}`} className="flex items-center justify-between rounded-lg bg-surface px-3 py-1.5">
                    <span className="flex items-center gap-2"><FileText className="h-4 w-4" aria-hidden /> {f}</span>
                    <button type="button" className="font-semibold text-danger-700" onClick={() => setFiles((x) => x.filter((_, j) => j !== i))}>Remove</button>
                  </li>
                ))}
              </ul>
            )}
            <p className="mt-1.5 text-xs text-muted">Only file names are recorded. Keep the original files somewhere safe.</p>
          </div>
          {saved && <Alert tone="success">Incident saved to your vault.</Alert>}
          <Button type="submit" size="lg" className="w-full">Save incident</Button>
        </form>
      </Card>

      <div>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h2 className="flex items-center gap-2 text-xl"><Lock className="h-5 w-5" aria-hidden /> Your timeline ({reports.length})</h2>
          {reports.length > 0 && <Button variant="secondary" size="sm" onClick={exportJson}><Download className="h-4 w-4" aria-hidden /> Export</Button>}
        </div>
        {reports.length === 0 ? (
          <EmptyState title="No incidents recorded" text="Entries you save will appear here in a timeline." />
        ) : (
          <ul className="space-y-3">
            {[...reports].sort((a, b) => `${b.date}${b.time}`.localeCompare(`${a.date}${a.time}`)).map((r) => (
              <li key={r.id}>
                <Card className="!p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <Badge>{r.type}</Badge>
                      <h3 className="mt-2 text-lg">{r.title}</h3>
                      <p className="text-xs text-muted">{r.date} at {r.time}</p>
                    </div>
                    <Button variant="ghost" size="sm" aria-label={`Delete ${r.title}`} onClick={() => remove(r.id, r.title)}>
                      <Trash2 className="h-4 w-4" aria-hidden />
                    </Button>
                  </div>
                  <p className="mt-3 whitespace-pre-line text-sm text-ink">{r.description}</p>
                  {r.attachments.length > 0 && <p className="mt-2 text-xs text-muted">Files: {r.attachments.join(", ")}</p>}
                </Card>
              </li>
            ))}
          </ul>
        )}
        <Alert className="mt-6">{canSync ? "Entries are saved to your account database and cached on this device, so they follow you to other devices. Export a copy regularly." : "Entries are stored only in this browser. Clearing browser data or using another device will not show them, so export a copy regularly."}</Alert>
      </div>
    </div>
  );
}
