import { useEffect, useState } from "react";
import { auth } from "../config/firebase";

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

/** True when requests that need a signed-in user can be made (Firebase mode). */
export const canSync = Boolean(auth);

// Per-user data endpoints wait for the profile row to exist in the database.
let profileReady: Promise<unknown> = Promise.resolve();
export const setProfileReady = (p: Promise<unknown>) => {
  profileReady = p.catch(() => undefined);
};

interface Options {
  method?: "GET" | "POST" | "PUT" | "DELETE";
  body?: unknown;
  signedIn?: boolean;
}

export async function api<T = void>(path: string, { method = "GET", body, signedIn = false }: Options = {}): Promise<T> {
  const headers: Record<string, string> = {};
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (signedIn) {
    if (!auth?.currentUser) throw new ApiError(401, "Not signed in.");
    if (/^\/(reports|allies)/.test(path)) await profileReady;
    headers.Authorization = `Bearer ${await auth.currentUser.getIdToken()}`;
  }
  const res = await fetch(`/api${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  if (res.status === 204) return undefined as T;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, (data as { error?: string }).error ?? "Request failed.");
  return data as T;
}

/** Runs a background database sync; failures never block the user (data is also kept on the device). */
export async function syncQuietly(task: () => Promise<unknown>) {
  if (!canSync) return;
  try {
    await task();
  } catch (e) {
    console.warn("Database sync skipped:", e instanceof Error ? e.message : e);
  }
}

/** Uploads items that only exist locally and returns the merged list. */
export async function syncCollection<T extends { id: string }>(path: string, local: T[]): Promise<T[]> {
  const server = await api<T[]>(path, { signedIn: true });
  const known = new Set(server.map((x) => x.id));
  const missing = local.filter((x) => !known.has(x.id));
  await Promise.all(missing.map((x) => api(path, { method: "POST", body: x, signedIn: true })));
  return [...missing, ...server];
}

/** Loads public data from the API, falling back to the bundled copy if the API is unreachable. */
export function useApiData<T>(path: string, fallback: T): T {
  const [data, setData] = useState<T>(fallback);
  useEffect(() => {
    let live = true;
    api<T>(path)
      .then((d) => live && Array.isArray(d) && d.length && setData(d))
      .catch(() => undefined);
    return () => {
      live = false;
    };
  }, [path]);
  return data;
}
