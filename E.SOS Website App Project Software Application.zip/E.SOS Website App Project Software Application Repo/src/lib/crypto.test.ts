import { describe, expect, it } from "vitest";
import { hashSecret, needsRehash, verifySecret } from "./crypto";
import { sha256 } from "./utils";

describe("crypto", () => {
  it("hashes with salt and verifies", async () => {
    const a = await hashSecret("secret-1");
    const b = await hashSecret("secret-1");
    expect(a.startsWith("pbkdf2$")).toBe(true);
    expect(a).not.toBe(b);
    expect(await verifySecret("secret-1", a, "k")).toBe(true);
    expect(await verifySecret("wrong", a, "k")).toBe(false);
    expect(needsRehash(a)).toBe(false);
  });

  it("verifies legacy sha256 hashes and flags them for rehash", async () => {
    const legacy = await sha256("key:secret");
    expect(await verifySecret("secret", legacy, "key")).toBe(true);
    expect(await verifySecret("nope", legacy, "key")).toBe(false);
    expect(needsRehash(legacy)).toBe(true);
  });
});
