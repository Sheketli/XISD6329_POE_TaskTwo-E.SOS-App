import { beforeEach, describe, expect, it } from "vitest";
import { cn, read, remove, sha256, write } from "./utils";

beforeEach(() => localStorage.clear());

describe("cn", () => {
  it("joins truthy parts only", () => expect(cn("a", false, null, undefined, "b")).toBe("a b"));
});

describe("storage helpers", () => {
  it("round-trips JSON", () => {
    write("k", { a: 1 });
    expect(read("k", null)).toEqual({ a: 1 });
  });
  it("returns fallback when missing or corrupt", () => {
    expect(read("missing", 5)).toBe(5);
    localStorage.setItem("bad", "{not json");
    expect(read("bad", "fb")).toBe("fb");
  });
  it("removes keys", () => {
    write("k", 1);
    remove("k");
    expect(read("k", 0)).toBe(0);
  });
});

describe("sha256", () => {
  it("matches known digest", async () => {
    expect(await sha256("abc")).toBe("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  });
});
