export type AuthMode = "login" | "signup";

export const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const isValidEmail = (email: string) => EMAIL.test(email.trim());

export interface AuthFields {
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
  decoy: string;
}

export function validateAuth(mode: AuthMode, f: AuthFields): Record<string, string> {
  const next: Record<string, string> = {};
  if (mode === "signup" && !f.username.trim()) next.username = "Choose a username.";
  if (!isValidEmail(f.email)) next.email = "Enter a valid email address.";
  if (mode === "signup" ? f.password.length < 8 : !f.password) next.password = mode === "signup" ? "Use at least 8 characters." : "Enter your password.";
  if (mode === "signup" && !f.confirmPassword) next.confirmPassword = "Confirm your password.";
  else if (mode === "signup" && f.confirmPassword !== f.password) next.confirmPassword = "Passwords do not match.";
  if (f.decoy && f.decoy === f.password) next.decoy = "The decoy password must be different from your real password.";
  return next;
}

export function validatePasswordReset(email: string, password: string, confirmPassword: string, requiresNewPassword: boolean): Record<string, string> {
  const next: Record<string, string> = {};
  if (!isValidEmail(email)) next.email = "Enter a valid email address.";
  if (requiresNewPassword && password.length < 8) next.recoveryPassword = "Use at least 8 characters.";
  if (requiresNewPassword && !confirmPassword) next.confirmRecoveryPassword = "Confirm your new password.";
  else if (requiresNewPassword && confirmPassword !== password) next.confirmRecoveryPassword = "Passwords do not match.";
  return next;
}
