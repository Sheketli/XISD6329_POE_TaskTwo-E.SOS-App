import { sha256 } from "./utils";

const ITERATIONS = 210_000;
const PREFIX = "pbkdf2";

const toHex = (buf: ArrayBuffer | Uint8Array) =>
  Array.from(buf instanceof Uint8Array ? buf : new Uint8Array(buf), (b) => b.toString(16).padStart(2, "0")).join("");
const fromHex = (hex: string) => new Uint8Array((hex.match(/.{2}/g) ?? []).map((h) => parseInt(h, 16)));

async function derive(secret: string, salt: Uint8Array, iterations: number): Promise<string> {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: salt as BufferSource, iterations }, key, 256);
  return toHex(bits);
}

/** Salted, slow hash (PBKDF2-SHA256). Format: pbkdf2$iterations$salt$hash */
export async function hashSecret(secret: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  return `${PREFIX}$${ITERATIONS}$${toHex(salt)}$${await derive(secret, salt, ITERATIONS)}`;
}

function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export async function verifySecret(secret: string, stored: string, legacyKey: string): Promise<boolean> {
  if (!stored.startsWith(`${PREFIX}$`)) return safeEqual(stored, await sha256(`${legacyKey}:${secret}`));
  const [, iterations, salt, hash] = stored.split("$");
  return safeEqual(hash, await derive(secret, fromHex(salt), Number(iterations)));
}

export const needsRehash = (stored: string) => !stored.startsWith(`${PREFIX}$${ITERATIONS}$`);
