import { describe, expect, it } from "vitest";
import { isValidEmail, validateAuth, validatePasswordReset, type AuthFields } from "./validation";

const ok: AuthFields = { username: "sam", email: "sam@example.com", password: "longenough1", confirmPassword: "longenough1", decoy: "" };

describe("isValidEmail", () => {
  it.each(["a@b.co", "  a@b.co  "])("accepts %s", (e) => expect(isValidEmail(e)).toBe(true));
  it.each(["", "abc", "a@b", "a b@c.de", "@b.co"])("rejects %s", (e) => expect(isValidEmail(e)).toBe(false));
});

describe("validateAuth", () => {
  it("passes valid signup and login", () => {
    expect(validateAuth("signup", ok)).toEqual({});
    expect(validateAuth("login", { ...ok, username: "", confirmPassword: "", password: "x" })).toEqual({});
  });
  it("requires username on signup only", () => {
    expect(validateAuth("signup", { ...ok, username: "  " }).username).toBeDefined();
    expect(validateAuth("login", { ...ok, username: "" }).username).toBeUndefined();
  });
  it("enforces 8 char password on signup", () => {
    expect(validateAuth("signup", { ...ok, password: "short", confirmPassword: "short" }).password).toBe("Use at least 8 characters.");
  });
  it("requires password on login", () => {
    expect(validateAuth("login", { ...ok, password: "" }).password).toBe("Enter your password.");
  });
  it("checks confirm password", () => {
    expect(validateAuth("signup", { ...ok, confirmPassword: "" }).confirmPassword).toBe("Confirm your password.");
    expect(validateAuth("signup", { ...ok, confirmPassword: "different1" }).confirmPassword).toBe("Passwords do not match.");
  });
  it("rejects decoy equal to password", () => {
    expect(validateAuth("signup", { ...ok, decoy: ok.password }).decoy).toBeDefined();
    expect(validateAuth("signup", { ...ok, decoy: "other-pass" }).decoy).toBeUndefined();
  });
  it("flags invalid email", () => {
    expect(validateAuth("login", { ...ok, email: "nope" }).email).toBe("Enter a valid email address.");
  });
});

describe("validatePasswordReset", () => {
  it("validates the email for Firebase password recovery", () => {
    expect(validatePasswordReset("invalid", "", "", false)).toEqual({ email: "Enter a valid email address." });
    expect(validatePasswordReset(ok.email, "", "", false)).toEqual({});
  });

  it("requires a strong matching password for local recovery", () => {
    expect(validatePasswordReset(ok.email, "short", "short", true).recoveryPassword).toBe("Use at least 8 characters.");
    expect(validatePasswordReset(ok.email, "longenough1", "", true).confirmRecoveryPassword).toBe("Confirm your new password.");
    expect(validatePasswordReset(ok.email, "longenough1", "different1", true).confirmRecoveryPassword).toBe("Passwords do not match.");
    expect(validatePasswordReset(ok.email, "longenough1", "longenough1", true)).toEqual({});
  });
});
