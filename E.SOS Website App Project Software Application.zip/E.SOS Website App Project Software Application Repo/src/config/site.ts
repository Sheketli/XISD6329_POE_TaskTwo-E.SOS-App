export const SITE = {
  name: "e.sos",
  tagline: "Protecting women's rights since 1979.",
  npo: "NPO 001-314",
  phone: "011 642 4345",
  city: "Johannesburg, South Africa",
  bank: {
    bank: "Standard Bank South Africa",
    accountName: "e.sos Support Fund (POWA)",
    accountNumber: "012 345 6789",
    branchCode: "051 001",
    reference: "DONATION",
  },
};

export interface NavItem {
  label: string;
  to: string;
  description?: string;
}

export const NAV_GROUPS: { label: string; items: NavItem[] }[] = [
  {
    label: "Get help",
    items: [
      { label: "Find a shelter", to: "/shelters", description: "Safe houses across South Africa" },
      { label: "Helplines", to: "/helplines", description: "Free, confidential numbers" },
      { label: "Talk to a counselor", to: "/chat", description: "Private guidance and safety plans" },
    ],
  },
  {
    label: "My safety",
    items: [
      { label: "Panic button", to: "/panic", description: "Quick alert tools" },
      { label: "Trusted allies", to: "/allies", description: "People who can help you" },
      { label: "Evidence vault", to: "/vault", description: "Record incidents privately" },
    ],
  },
  {
    label: "Get involved",
    items: [
      { label: "Donate", to: "/donate", description: "Fund shelter and counseling" },
      { label: "Volunteer", to: "/volunteer", description: "Give your time and skills" },
    ],
  },
  {
    label: "Support",
    items: [{ label: "Help center", to: "/help", description: "Guides and common questions" }],
  },
];
