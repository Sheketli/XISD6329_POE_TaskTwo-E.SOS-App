import { initializeApp } from "firebase/app";
import {
  browserLocalPersistence,
  browserPopupRedirectResolver,
  indexedDBLocalPersistence,
  initializeAuth,
  type Auth,
} from "firebase/auth";

const env = import.meta.env;

const config = {
  apiKey: env.VITE_FIREBASE_API_KEY as string | undefined,
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN as string | undefined,
  projectId: env.VITE_FIREBASE_PROJECT_ID as string | undefined,
  appId: env.VITE_FIREBASE_APP_ID as string | undefined,
};

export const firebaseEnabled = Boolean(config.apiKey && config.projectId && config.appId);

if (!firebaseEnabled && (config.projectId || config.appId)) {
  console.warn("Firebase is partly configured: set VITE_FIREBASE_API_KEY in .env to enable sign-in.");
}

export const auth: Auth | null = firebaseEnabled
  ? initializeAuth(initializeApp(config), {
      // Session survives reloads and is shared between tabs; the same Firebase project
      // identifies the same user in the mobile app.
      persistence: [indexedDBLocalPersistence, browserLocalPersistence],
      popupRedirectResolver: browserPopupRedirectResolver,
    })
  : null;
