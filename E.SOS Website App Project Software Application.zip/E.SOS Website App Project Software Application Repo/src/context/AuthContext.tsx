import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  EmailAuthProvider,
  GoogleAuthProvider,
  createUserWithEmailAndPassword,
  deleteUser,
  onAuthStateChanged,
  reauthenticateWithCredential,
  reauthenticateWithPopup,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect,
  signOut,
  updatePassword,
  updateProfile,
  verifyBeforeUpdateEmail,
  type AuthProvider as FirebaseProvider,
  type User as FirebaseUser,
} from "firebase/auth";
import { auth, firebaseEnabled } from "../config/firebase";
import type { AuthProvider, User } from "../types";
import { read, remove, uid, write } from "../lib/utils";
import { hashSecret, needsRehash, verifySecret } from "../lib/crypto";
import { api, setProfileReady, syncQuietly } from "../lib/api";

const putProfile = (body: Record<string, unknown>) => api("/users/me", { method: "PUT", body, signedIn: true });

interface StoredAccount {
  id: string;
  email: string;
  username: string;
  createdAt: string;
  provider: AuthProvider;
  passwordHash?: string;
  decoyHash?: string;
}

export type LoginResult = { ok: true } | { ok: false; error: string } | { ok: false; decoy: true };
export type Result = { ok: true; message?: string } | { ok: false; error: string };
export type SsoProvider = "google";

interface AuthState {
  user: User | null;
  ready: boolean;
  demoMode: boolean;
  hasDecoy: boolean;
  login: (email: string, password: string) => Promise<LoginResult>;
  resetPassword: (email: string, newPassword?: string) => Promise<Result>;
  loginWithProvider: () => Promise<Result>;
  signup: (input: { username: string; email: string; password: string; decoy?: string }) => Promise<{ ok: boolean; error?: string }>;
  logout: () => Promise<void>;
  updateUsername: (username: string) => Promise<Result>;
  changeEmail: (newEmail: string, currentPassword?: string) => Promise<Result>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<Result>;
  setDecoy: (decoy: string | null, currentPassword?: string) => Promise<Result>;
  deleteAccount: (currentPassword?: string) => Promise<Result>;
}

const USERS_KEY = "esos_users";
const SESSION_KEY = "esos_active_session";
const WRONG = "That email or password is not correct.";
const BAD_CURRENT = "Your current password is not correct.";
const NOT_LOGGED_IN = "You are not logged in.";
const DECOY_SAME = "The decoy password must be different from your real password.";

const AuthContext = createContext<AuthState | null>(null);

const loadAccounts = () => read<StoredAccount[]>(USERS_KEY, []);
const saveAccounts = (list: StoredAccount[]) => write(USERS_KEY, list);
const byEmail = (email: string) => loadAccounts().find((a) => a.email.toLowerCase() === email.toLowerCase());
const byId = (id: string) => loadAccounts().find((a) => a.id === id);
const patchAccount = (id: string, patch: Partial<StoredAccount>) =>
  saveAccounts(loadAccounts().map((a) => (a.id === id ? { ...a, ...patch } : a)));

const toUser = (a: StoredAccount): User => ({
  id: a.id,
  email: a.email,
  username: a.username,
  createdAt: a.createdAt,
  provider: a.provider ?? "password",
});

const providerOf = (fb: FirebaseUser): AuthProvider => {
  const id = fb.providerData[0]?.providerId;
  return id === "google.com" ? "google" : "password";
};

const buildProvider = (): FirebaseProvider => {
  const p = new GoogleAuthProvider();
  p.setCustomParameters({ prompt: "select_account" });
  return p;
};

const errorCode = (e: unknown) => (e as { code?: string }).code ?? "";

function friendlyError(e: unknown): string {
  switch (errorCode(e)) {
    case "auth/wrong-password":
    case "auth/invalid-credential":
      return BAD_CURRENT;
    case "auth/weak-password":
      return "Choose a stronger password (at least 8 characters).";
    case "auth/invalid-email":
      return "Enter a valid email address.";
    case "auth/user-not-found":
      return "No account was found with that email address.";
    case "auth/email-already-in-use":
      return "That email is already in use.";
    case "auth/too-many-requests":
      return "Too many attempts. Please wait a few minutes and try again.";
    case "auth/requires-recent-login":
      return "For your security, please log out and log in again, then retry.";
    case "auth/popup-closed-by-user":
    case "auth/cancelled-popup-request":
      return "Sign-in was cancelled.";
    case "auth/account-exists-with-different-credential":
      return "An account with this email already exists using a different sign-in method.";
    case "auth/operation-not-allowed":
      return "This sign-in method is not enabled yet. Please contact the site administrator.";
    case "auth/unauthorized-domain":
      if (/^[\d.]+$|^\[.*\]$/.test(window.location.hostname)) {
        return "Google sign-in can't run from an IP address. Open the site at http://localhost:3000 instead.";
      }
      return `This website's address (${window.location.hostname}) is not authorised for sign-in. Add it under Firebase Console > Authentication > Settings > Authorized domains.`;
    case "auth/configuration-not-found":
      return "Authentication is not set up for this Firebase project. Enable it in Firebase Console > Authentication.";
    case "auth/api-key-not-valid.-please-pass-a-valid-api-key.":
    case "auth/invalid-api-key":
      return "The Firebase API key is invalid. Check VITE_FIREBASE_API_KEY in .env and restart the dev server.";
    case "auth/network-request-failed":
      return "Network error. Check your connection and try again.";
    case "auth/popup-blocked":
      return "Your browser blocked the sign-in popup. Please allow popups and try again.";
    default: {
      const code = errorCode(e);
      console.error("Auth error:", e);
      return `Something went wrong. Please try again.${code ? ` (${code})` : ""}`;
    }
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [ready, setReady] = useState(false);
  const [decoyVersion, setDecoyVersion] = useState(0);

  useEffect(() => {
    if (!auth) {
      const session = read<User | null>(SESSION_KEY, null);
      setUser(session && byId(session.id) ? session : null);
      setReady(true);
      return;
    }
    return onAuthStateChanged(auth, (fb) => {
      if (!fb) {
        setUser(null);
        setReady(true);
        return;
      }
      const email = fb.email ?? "";
      let account = byId(fb.uid) ?? byEmail(email);
      if (!account) {
        account = {
          id: fb.uid,
          email,
          username: fb.displayName ?? (email.split("@")[0] || "Member"),
          createdAt: fb.metadata.creationTime ?? new Date().toISOString(),
          provider: providerOf(fb),
        };
        saveAccounts([...loadAccounts(), account]);
      } else if (account.id !== fb.uid || account.email !== email) {
        patchAccount(account.id, { id: fb.uid, email });
        account = { ...account, id: fb.uid, email };
      }
      setUser({ ...toUser(account), provider: providerOf(fb) });
      setProfileReady(syncQuietly(() => putProfile({ username: account.username })));
      setReady(true);
    });
  }, []);

  const login: AuthState["login"] = useCallback(async (email, password) => {
    const account = byEmail(email);
    if (account?.decoyHash && (await verifySecret(password, account.decoyHash, email.toLowerCase()))) {
      return { ok: false, decoy: true };
    }
    if (auth) {
      try {
        await signInWithEmailAndPassword(auth, email, password);
        return { ok: true };
      } catch (e) {
        return { ok: false, error: errorCode(e) === "auth/too-many-requests" ? friendlyError(e) : WRONG };
      }
    }
    if (account?.passwordHash && (await verifySecret(password, account.passwordHash, email.toLowerCase()))) {
      if (needsRehash(account.passwordHash)) patchAccount(account.id, { passwordHash: await hashSecret(password) });
      const u = toUser(account);
      write(SESSION_KEY, u);
      setUser(u);
      return { ok: true };
    }
    return { ok: false, error: WRONG };
  }, []);

  const resetPassword: AuthState["resetPassword"] = useCallback(async (email, newPassword) => {
    const normalizedEmail = email.trim();
    if (auth) {
      try {
        await sendPasswordResetEmail(auth, normalizedEmail);
        return { ok: true, message: "If an account exists for this email, a password reset email has been sent." };
      } catch (e) {
        return { ok: false, error: friendlyError(e) };
      }
    }

    const account = byEmail(normalizedEmail);
    if (!account) return { ok: false, error: "No local account was found with that email address." };
    if (!newPassword) return { ok: false, error: "Enter a new password." };
    if (newPassword.length < 8) return { ok: false, error: "Use at least 8 characters for your new password." };
    try {
      if (account.decoyHash && (await verifySecret(newPassword, account.decoyHash, account.email.toLowerCase()))) {
        return { ok: false, error: DECOY_SAME };
      }

      const passwordHash = await hashSecret(newPassword);
      patchAccount(account.id, { passwordHash });
      if (byId(account.id)?.passwordHash !== passwordHash) {
        return { ok: false, error: "Could not save the new password in this browser. Check browser storage and try again." };
      }
    } catch (e) {
      console.error("Local password reset failed:", e);
      return { ok: false, error: "Could not update your password in this browser. Please try again." };
    }

    return { ok: true, message: "Your password has been updated. You can now log in with your new password." };
  }, []);

  const loginWithProvider: AuthState["loginWithProvider"] = useCallback(async () => {
    if (!auth) return { ok: false, error: "Single sign-on needs the site to be connected to Firebase (see README)." };
    // Firebase rejects raw IP hosts, so move to localhost (works when the browser runs on the dev machine).
    if (/^\d+(\.\d+){3}$/.test(window.location.hostname)) {
      const { port, pathname, search } = window.location;
      window.location.replace(`http://localhost${port ? `:${port}` : ""}${pathname}${search}`);
      return { ok: false, error: "Switching to localhost for Google sign-in. Please click the button again." };
    }
    const provider = buildProvider();
    try {
      await signInWithPopup(auth, provider);
      return { ok: true };
    } catch (e) {
      const code = errorCode(e);
      if (code === "auth/popup-blocked" || code === "auth/operation-not-supported-in-this-environment") {
        try {
          await signInWithRedirect(auth, provider);
          return { ok: true };
        } catch (re) {
          return { ok: false, error: friendlyError(re) };
        }
      }
      return { ok: false, error: friendlyError(e) };
    }
  }, []);

  const signup: AuthState["signup"] = useCallback(async ({ username, email, password, decoy }) => {
    if (byEmail(email)) return { ok: false, error: "This email is already registered. Please log in." };
    let id = uid("local");
    if (auth) {
      try {
        const cred = await createUserWithEmailAndPassword(auth, email, password);
        id = cred.user.uid;
        await updateProfile(cred.user, { displayName: username });
        // Only one-way hashes are sent; Firebase remains the authority for sign-in.
        const [passwordHash, decoyHash] = await Promise.all([hashSecret(password), decoy ? hashSecret(decoy) : null]);
        await syncQuietly(() => putProfile({ username, passwordHash, decoyHash }));
      } catch (e) {
        return { ok: false, error: friendlyError(e) };
      }
    }
    saveAccounts([
      ...loadAccounts(),
      {
        id,
        email,
        username,
        createdAt: new Date().toISOString(),
        provider: "password",
        passwordHash: auth ? undefined : await hashSecret(password),
        decoyHash: decoy ? await hashSecret(decoy) : undefined,
      },
    ]);
    if (auth) await signOut(auth);
    return { ok: true };
  }, []);

  const logout = useCallback(async () => {
    if (auth) await signOut(auth).catch(() => undefined);
    remove(SESSION_KEY);
    setUser(null);
  }, []);

  const reauth = useCallback(async (fb: FirebaseUser, password?: string) => {
    const provider = providerOf(fb);
    if (provider === "password") {
      if (!password || !fb.email) throw Object.assign(new Error("password"), { code: "auth/wrong-password" });
      await reauthenticateWithCredential(fb, EmailAuthProvider.credential(fb.email, password));
    } else {
      await reauthenticateWithPopup(fb, buildProvider());
    }
  }, []);

  const checkLocalPassword = useCallback(async (id: string, password?: string) => {
    const account = byId(id);
    if (!account?.passwordHash || !password) return false;
    return verifySecret(password, account.passwordHash, account.email.toLowerCase());
  }, []);

  const updateUsername: AuthState["updateUsername"] = useCallback(
    async (username) => {
      if (!user) return { ok: false, error: NOT_LOGGED_IN };
      const name = username.trim();
      if (!name) return { ok: false, error: "Username can't be empty." };
      try {
        if (auth?.currentUser) await updateProfile(auth.currentUser, { displayName: name });
      } catch (e) {
        return { ok: false, error: friendlyError(e) };
      }
      patchAccount(user.id, { username: name });
      await syncQuietly(() => putProfile({ username: name }));
      const next = { ...user, username: name };
      setUser(next);
      if (!auth) write(SESSION_KEY, next);
      return { ok: true, message: "Profile updated." };
    },
    [user],
  );

  const changeEmail: AuthState["changeEmail"] = useCallback(
    async (newEmail, currentPassword) => {
      if (!user) return { ok: false, error: NOT_LOGGED_IN };
      const email = newEmail.trim();
      const taken = byEmail(email);
      if (taken && taken.id !== user.id) return { ok: false, error: "That email is already in use." };
      if (auth?.currentUser) {
        try {
          await reauth(auth.currentUser, currentPassword);
          await verifyBeforeUpdateEmail(auth.currentUser, email);
        } catch (e) {
          return { ok: false, error: friendlyError(e) };
        }
        return { ok: true, message: `We sent a verification link to ${email}. Your email changes once you open it.` };
      }
      if (!(await checkLocalPassword(user.id, currentPassword))) return { ok: false, error: BAD_CURRENT };
      patchAccount(user.id, { email });
      const next = { ...user, email };
      setUser(next);
      write(SESSION_KEY, next);
      return { ok: true, message: "Email updated." };
    },
    [user, reauth, checkLocalPassword],
  );

  const changePassword: AuthState["changePassword"] = useCallback(
    async (currentPassword, newPassword) => {
      if (!user) return { ok: false, error: NOT_LOGGED_IN };
      if (newPassword.length < 8) return { ok: false, error: "Use at least 8 characters for your new password." };
      if (newPassword === currentPassword) return { ok: false, error: "Your new password must be different from the current one." };
      const account = byId(user.id);
      if (account?.decoyHash && (await verifySecret(newPassword, account.decoyHash, user.email.toLowerCase()))) {
        return { ok: false, error: "Your password can't be the same as your decoy password." };
      }
      if (auth?.currentUser) {
        try {
          await reauth(auth.currentUser, currentPassword);
          await updatePassword(auth.currentUser, newPassword);
        } catch (e) {
          return { ok: false, error: friendlyError(e) };
        }
        const passwordHash = await hashSecret(newPassword);
        await syncQuietly(() => putProfile({ passwordHash }));
      } else {
        if (!(await checkLocalPassword(user.id, currentPassword))) return { ok: false, error: BAD_CURRENT };
        patchAccount(user.id, { passwordHash: await hashSecret(newPassword) });
      }
      return { ok: true, message: "Password changed." };
    },
    [user, reauth, checkLocalPassword],
  );

  const setDecoy: AuthState["setDecoy"] = useCallback(
    async (decoy, currentPassword) => {
      if (!user) return { ok: false, error: NOT_LOGGED_IN };
      if (decoy) {
        if (decoy.length < 6) return { ok: false, error: "Use at least 6 characters for the decoy password." };
        if (decoy === currentPassword) return { ok: false, error: DECOY_SAME };
        if (auth?.currentUser) {
          try {
            await reauth(auth.currentUser, currentPassword);
          } catch (e) {
            return { ok: false, error: friendlyError(e) };
          }
        } else if (!(await checkLocalPassword(user.id, currentPassword))) {
          return { ok: false, error: BAD_CURRENT };
        }
      }
      const decoyHash = decoy ? await hashSecret(decoy) : undefined;
      patchAccount(user.id, { decoyHash });
      await syncQuietly(() => putProfile({ decoyHash: decoyHash ?? null }));
      setDecoyVersion((v) => v + 1);
      return { ok: true, message: decoy ? "Decoy password saved." : "Decoy password removed." };
    },
    [user, reauth, checkLocalPassword],
  );

  const deleteAccount: AuthState["deleteAccount"] = useCallback(
    async (currentPassword) => {
      if (!user) return { ok: false, error: NOT_LOGGED_IN };
      if (auth?.currentUser) {
        try {
          await reauth(auth.currentUser, currentPassword);
          await syncQuietly(() => api("/users/me", { method: "DELETE", signedIn: true }));
          await deleteUser(auth.currentUser);
        } catch (e) {
          return { ok: false, error: friendlyError(e) };
        }
      } else if (!(await checkLocalPassword(user.id, currentPassword))) {
        return { ok: false, error: BAD_CURRENT };
      }
      saveAccounts(loadAccounts().filter((a) => a.id !== user.id));
      ["esos_reports_", "esos_allies_"].forEach((p) => remove(`${p}${user.id}`));
      remove(SESSION_KEY);
      setUser(null);
      return { ok: true };
    },
    [user, reauth, checkLocalPassword],
  );

  // decoyVersion forces a re-read after the decoy password changes
  const hasDecoy = useMemo(() => Boolean(user && byId(user.id)?.decoyHash) && decoyVersion >= 0, [user, decoyVersion]);

  const value = useMemo(
    () => ({
      user,
      ready,
      demoMode: !firebaseEnabled,
      hasDecoy,
      login,
      resetPassword,
      loginWithProvider,
      signup,
      logout,
      updateUsername,
      changeEmail,
      changePassword,
      setDecoy,
      deleteAccount,
    }),
    [user, ready, hasDecoy, login, resetPassword, loginWithProvider, signup, logout, updateUsername, changeEmail, changePassword, setDecoy, deleteAccount],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
