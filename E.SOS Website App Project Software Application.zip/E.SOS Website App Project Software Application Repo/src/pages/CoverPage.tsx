import { Link } from "react-router-dom";

const CITIES = [
  { name: "Johannesburg", temp: "19°C", sky: "Partly cloudy" },
  { name: "Cape Town", temp: "14°C", sky: "Light rain" },
  { name: "Durban", temp: "24°C", sky: "Humid" },
];

export default function CoverPage() {
  return (
    <div className="mx-auto min-h-screen max-w-3xl bg-white px-6 py-10 font-sans">
      <div className="mb-8 flex items-center justify-between">
        <h1 className="text-2xl">Regional weather forecast</h1>
        <Link to="/" className="text-sm text-muted underline">Back</Link>
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        {CITIES.map((c) => (
          <div key={c.name} className="rounded-xl border border-line p-5 text-center">
            <p className="font-semibold">{c.name}</p>
            <p className="my-2 text-3xl font-bold">{c.temp}</p>
            <p className="text-sm text-muted">{c.sky}</p>
          </div>
        ))}
      </div>
      <p className="mt-8 text-muted">
        A weak cold front is moving across the eastern coast, bringing scattered light showers. Moderate south-westerly winds will persist overnight, lowering temperatures slightly over the Highveld.
      </p>
    </div>
  );
}
