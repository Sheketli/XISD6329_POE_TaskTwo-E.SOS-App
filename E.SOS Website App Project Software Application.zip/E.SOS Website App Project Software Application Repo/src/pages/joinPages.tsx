import { HeartHandshake, UserRound, Users } from "lucide-react";
import { Container, PageHeader } from "../components/ui/Display";
import { AuthForm } from "../features/auth/AuthForm";
import { DonateFlow } from "../features/donate/DonateFlow";
import { VolunteerFlow } from "../features/volunteer/VolunteerFlow";
import { useDocumentTitle } from "../hooks/useDocumentTitle";

export function LoginPage() {
  useDocumentTitle("Log in");
  return (
    <>
      <PageHeader icon={<UserRound />} title="Your private account" intro="Log in to use your evidence vault and dashboard." />
      <Container><AuthForm /></Container>
    </>
  );
}

export function DonatePage() {
  useDocumentTitle("Donate");
  return (
    <>
      <PageHeader icon={<HeartHandshake />} title="Rebuild lives" intro="Your gift funds shelter, counseling and legal support for survivors." />
      <Container><DonateFlow /></Container>
    </>
  );
}

export function VolunteerPage() {
  useDocumentTitle("Volunteer");
  return (
    <>
      <PageHeader icon={<Users />} title="Join the movement" intro="Give your time and skills to support survivors and drive change." />
      <Container><VolunteerFlow /></Container>
    </>
  );
}
