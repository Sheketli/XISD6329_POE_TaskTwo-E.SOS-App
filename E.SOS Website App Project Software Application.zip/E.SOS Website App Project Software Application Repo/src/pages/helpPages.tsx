import { Home, LifeBuoy, MessageCircleHeart, Phone } from "lucide-react";
import { HelpCenter } from "../features/help/HelpCenter";
import { Container, PageHeader } from "../components/ui/Display";
import { ShelterFinder } from "../features/shelters/ShelterFinder";
import { HelplineList } from "../features/helplines/HelplineList";
import { CounselorChat } from "../features/chat/CounselorChat";
import { useDocumentTitle } from "../hooks/useDocumentTitle";

export function HelpPage() {
  useDocumentTitle("Help center");
  return (
    <>
      <PageHeader icon={<LifeBuoy />} title="Help center" intro="Step-by-step guides and answers to common questions about using e.sos." />
      <Container><HelpCenter /></Container>
    </>
  );
}

export function SheltersPage() {
  useDocumentTitle("Find a shelter");
  return (
    <>
      <PageHeader icon={<Home />} title="Find a safe shelter" intro="Partner shelters and crisis homes across South Africa. Call to check space and arrange safe arrival." />
      <Container><ShelterFinder /></Container>
    </>
  );
}

export function HelplinesPage() {
  useDocumentTitle("Helplines");
  return (
    <>
      <PageHeader icon={<Phone />} title="Emergency helplines" intro="Tap a number to call. These services are confidential and most are free." />
      <Container><HelplineList /></Container>
    </>
  );
}

export function ChatPage() {
  useDocumentTitle("Talk to a counselor");
  return (
    <>
      <PageHeader icon={<MessageCircleHeart />} title="Talk to a counselor" intro="Private safety guidance, available any time." />
      <Container><CounselorChat /></Container>
    </>
  );
}
