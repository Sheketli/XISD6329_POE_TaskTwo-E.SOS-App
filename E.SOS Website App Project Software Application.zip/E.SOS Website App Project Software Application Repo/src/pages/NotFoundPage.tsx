import { Link } from "react-router-dom";
import { Container } from "../components/ui/Display";
import { ButtonLink } from "../components/ui/Button";

export default function NotFoundPage() {
  return (
    <Container className="text-center">
      <h1 className="text-4xl">Page not found</h1>
      <p className="mt-3 text-muted">The page you're looking for doesn't exist or has moved.</p>
      <div className="mt-6 flex justify-center gap-3">
        <ButtonLink to="/">Go to home</ButtonLink>
        <Link to="/helplines" className="inline-flex min-h-11 items-center font-semibold text-brand-700 underline">Helplines</Link>
      </div>
    </Container>
  );
}
