import { Hero, Services, Resources, Mission, GetInvolved } from "../features/home/HomeSections";
import { useDocumentTitle } from "../hooks/useDocumentTitle";

export default function HomePage() {
  useDocumentTitle("Support for survivors of gender-based violence");
  return (
    <>
      <Hero />
      <Services />
      <Resources />
      <Mission />
      <GetInvolved />
    </>
  );
}
