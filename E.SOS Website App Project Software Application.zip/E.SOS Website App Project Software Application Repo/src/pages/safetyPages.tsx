import { FileLock2, LayoutDashboard, Settings, ShieldAlert, Users } from "lucide-react";
import { Container, PageHeader } from "../components/ui/Display";
import { PanicConsole } from "../features/panic/PanicConsole";
import { AlliesBook } from "../features/allies/AlliesBook";
import { EvidenceVault } from "../features/vault/EvidenceVault";
import { SettingsPanel } from "../features/settings/SettingsPanel";
import { Dashboard } from "../features/dashboard/Dashboard";
import { useAuth } from "../context/AuthContext";
import { useDocumentTitle } from "../hooks/useDocumentTitle";

export function PanicPage() {
  useDocumentTitle("Panic button");
  return (
    <>
      <PageHeader icon={<ShieldAlert />} title="Panic button" intro="Start a loud alarm and quickly reach the people who can help." />
      <Container><PanicConsole /></Container>
    </>
  );
}

export function AlliesPage() {
  useDocumentTitle("Trusted allies");
  return (
    <>
      <PageHeader icon={<Users />} title="Trusted allies" intro="Keep the people you trust one tap away." />
      <Container><AlliesBook /></Container>
    </>
  );
}

export function VaultPage() {
  useDocumentTitle("Evidence vault");
  return (
    <>
      <PageHeader icon={<FileLock2 />} title="Evidence vault" intro="Record incidents privately with dates and details, useful when applying for a protection order." />
      <Container><EvidenceVault /></Container>
    </>
  );
}

export function DashboardPage() {
  const { user } = useAuth();
  useDocumentTitle("My dashboard");
  return (
    <>
      <PageHeader icon={<LayoutDashboard />} title={`Welcome back, ${user?.username ?? ""}`} intro="Your private space for safety tools and support." />
      <Container><Dashboard /></Container>
    </>
  );
}

export function SettingsPage() {
  useDocumentTitle("Settings");
  return (
    <>
      <PageHeader icon={<Settings />} title="Settings" intro="Manage your account, password and privacy options." />
      <Container><SettingsPanel /></Container>
    </>
  );
}
