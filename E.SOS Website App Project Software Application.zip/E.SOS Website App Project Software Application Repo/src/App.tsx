import { lazy, type ReactElement } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { Layout } from "./components/layout/Layout";
import { useAuth } from "./context/AuthContext";
import HomePage from "./pages/HomePage";

const Shelters = lazy(() => import("./pages/helpPages").then((x) => ({ default: x.SheltersPage })));
const Helplines = lazy(() => import("./pages/helpPages").then((x) => ({ default: x.HelplinesPage })));
const Help = lazy(() => import("./pages/helpPages").then((x) => ({ default: x.HelpPage })));
const Chat = lazy(() => import("./pages/helpPages").then((x) => ({ default: x.ChatPage })));
const Panic = lazy(() => import("./pages/safetyPages").then((x) => ({ default: x.PanicPage })));
const Allies = lazy(() => import("./pages/safetyPages").then((x) => ({ default: x.AlliesPage })));
const Vault = lazy(() => import("./pages/safetyPages").then((x) => ({ default: x.VaultPage })));
const Dashboard = lazy(() => import("./pages/safetyPages").then((x) => ({ default: x.DashboardPage })));
const Settings = lazy(() => import("./pages/safetyPages").then((x) => ({ default: x.SettingsPage })));
const Login = lazy(() => import("./pages/joinPages").then((x) => ({ default: x.LoginPage })));
const Donate = lazy(() => import("./pages/joinPages").then((x) => ({ default: x.DonatePage })));
const Volunteer = lazy(() => import("./pages/joinPages").then((x) => ({ default: x.VolunteerPage })));
const Cover = lazy(() => import("./pages/CoverPage"));
const NotFound = lazy(() => import("./pages/NotFoundPage"));

function RequireAuth({ children }: { children: ReactElement }) {
  const { user, ready } = useAuth();
  if (!ready) return null;
  return user ? children : <Navigate to="/login" replace />;
}

export function App() {
  return (
    <Routes>
      <Route path="/cover" element={<Cover />} />
      <Route element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="shelters" element={<Shelters />} />
        <Route path="helplines" element={<Helplines />} />
        <Route path="help" element={<Help />} />
        <Route path="chat" element={<Chat />} />
        <Route path="panic" element={<Panic />} />
        <Route path="allies" element={<Allies />} />
        <Route path="vault" element={<RequireAuth><Vault /></RequireAuth>} />
        <Route path="dashboard" element={<RequireAuth><Dashboard /></RequireAuth>} />
        <Route path="settings" element={<RequireAuth><Settings /></RequireAuth>} />
        <Route path="login" element={<Login />} />
        <Route path="donate" element={<Donate />} />
        <Route path="volunteer" element={<Volunteer />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}

