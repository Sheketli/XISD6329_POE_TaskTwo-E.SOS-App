export type AuthProvider = "password" | "google";

export interface User {
  id: string;
  email: string;
  username: string;
  createdAt: string;
  provider: AuthProvider;
}

export interface Helpline {
  name: string;
  phone: string;
  dial: string;
  category: string;
  details: string;
}

export type Capacity = "Available" | "Limited" | "Full";

export interface Shelter {
  id: string;
  name: string;
  location: string;
  province: string;
  phone: string;
  services: string[];
  capacity: Capacity;
}

export interface Ally {
  id: string;
  name: string;
  relationship: string;
  phone: string;
}

export interface IncidentReport {
  id: string;
  title: string;
  type: string;
  date: string;
  time: string;
  description: string;
  confidentiality: string;
  attachments: string[];
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  sender: "user" | "bot" | "system";
  text: string;
  time: string;
}
