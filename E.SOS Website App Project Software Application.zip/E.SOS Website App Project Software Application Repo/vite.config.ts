import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  test: { environment: "jsdom", include: ["src/**/*.test.ts"] },
  server: { host: "localhost", port: 3000, strictPort: true, proxy: { "/api": "http://localhost:3001" } },
});
